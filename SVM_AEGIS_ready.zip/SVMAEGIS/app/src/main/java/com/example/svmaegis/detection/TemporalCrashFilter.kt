package com.example.svmaegis.detection

import android.util.Log
import com.example.svmaegis.ml.AdvancedFeatures
import kotlin.math.sqrt

class TemporalCrashFilter {

    companion object {

        private const val TAG = "SVM_AEGIS"

        /*
         * =========================================================
         * ML THRESHOLDS
         * =========================================================
         *
         * ML probability is supporting evidence.
         * It is NEVER sufficient by itself.
         */

        private const val STRONG_ML_THRESHOLD = 0.78f
        private const val SUPPORTING_ML_THRESHOLD = 0.68f

        /*
         * =========================================================
         * PHYSICAL IMPACT THRESHOLDS
         * =========================================================
         *
         * These are deliberately higher than the previous version
         * to reduce false positives from small movements.
         */

        private const val STRONG_ACCELERATION_CHANGE = 4.5f
        private const val VERY_STRONG_ACCELERATION_CHANGE = 6.0f

        private const val STRONG_GYRO_CHANGE = 1.5f
        private const val VERY_STRONG_GYRO_CHANGE = 2.5f

        /*
         * =========================================================
         * ADVANCED EVENT THRESHOLDS
         * =========================================================
         */

        private const val STRONG_JERK = 25.0f
        private const val VERY_STRONG_JERK = 40.0f

        private const val STRONG_ORIENTATION_CHANGE = 20.0f
        private const val VERY_STRONG_ORIENTATION_CHANGE = 35.0f

        private const val STRONG_SPEED_CHANGE = 15.0f
        private const val VERY_STRONG_SPEED_CHANGE = 25.0f

        /*
         * =========================================================
         * STATIONARY THRESHOLDS
         * =========================================================
         */

        private const val STATIONARY_ACCELERATION_CHANGE = 0.35f

        private const val STATIONARY_GYRO_CHANGE = 0.40f

        private const val STATIONARY_GYRO_MAGNITUDE = 0.80f

        /*
         * =========================================================
         * TIMING
         * =========================================================
         *
         * After a possible impact:
         *
         * impact
         *   ↓
         * settling
         *   ↓
         * immobility check
         *   ↓
         * confirmed crash
         */

        private const val SETTLING_WINDOW_MS = 800L

        private const val REQUIRED_IMMOBILITY_MS = 2500L

        private const val MAX_IMPACT_WINDOW_MS = 7000L

        private const val MIN_STATIONARY_SAMPLES = 8

        private const val MOVEMENT_CONFIRMATION_SAMPLES = 4

        /*
         * =========================================================
         * SENSOR NOISE MARGIN
         * =========================================================
         */

        private const val ACCELERATION_NOISE_MARGIN = 0.20f

        private const val GYRO_NOISE_MARGIN = 0.15f
    }

    /*
     * =============================================================
     * STATE
     * =============================================================
     */

    private var status =
        TemporalStatus.NORMAL

    private var possibleImpactTime =
        0L

    private var settlingStartTime =
        0L

    private var stationaryStartTime =
        0L

    private var stationarySamples =
        0

    private var movementSamplesAfterImpact =
        0

    /*
     * =============================================================
     * PEAK EVIDENCE
     * =============================================================
     */

    private var strongestAccelerationChange =
        0f

    private var strongestGyroChange =
        0f

    private var strongestJerk =
        0f

    private var strongestOrientationChange =
        0f

    private var strongestSpeedChange =
        0f

    private var highestEnsembleProbability =
        0f

    private var lastUpdateTime =
        0L

    /*
     * =============================================================
     * MAIN UPDATE
     * =============================================================
     */

    fun update(
        ensembleProbability: Float,
        features: AdvancedFeatures
    ): TemporalResult {

        val now =
            System.currentTimeMillis()

        val probability =
            ensembleProbability
                .coerceIn(0f, 1f)

        val accelerationChange =
            features.accelerationChange
                .coerceAtLeast(0f)

        val gyroChange =
            features.gyroChange
                .coerceAtLeast(0f)

        val gyroMagnitude =
            features.gyroMagnitude
                .coerceAtLeast(0f)

        val jerk =
            features.jerk
                .coerceAtLeast(0f)

        val orientationChange =
            features.orientationChange
                .coerceAtLeast(0f)

        val speedChange =
            features.speedChange
                .coerceAtLeast(0f)

        /*
         * ---------------------------------------------------------
         * TRACK PEAK VALUES
         * ---------------------------------------------------------
         */

        highestEnsembleProbability =
            maxOf(
                highestEnsembleProbability,
                probability
            )

        strongestAccelerationChange =
            maxOf(
                strongestAccelerationChange,
                accelerationChange
            )

        strongestGyroChange =
            maxOf(
                strongestGyroChange,
                gyroChange
            )

        strongestJerk =
            maxOf(
                strongestJerk,
                jerk
            )

        strongestOrientationChange =
            maxOf(
                strongestOrientationChange,
                orientationChange
            )

        strongestSpeedChange =
            maxOf(
                strongestSpeedChange,
                speedChange
            )

        lastUpdateTime =
            now

        /*
         * =========================================================
         * NORMAL
         * =========================================================
         */

        if (
            status ==
            TemporalStatus.NORMAL
        ) {

            if (
                isPossibleImpact(
                    probability = probability,
                    features = features
                )
            ) {

                beginImpactWindow(
                    now = now,
                    probability = probability,
                    features = features
                )

                Log.w(
                    TAG,
                    "TEMPORAL: POSSIBLE REAL IMPACT"
                )

                logImpactEvidence(
                    probability,
                    features
                )

                return createResult()
            }

            return createResult()
        }

        /*
         * =========================================================
         * POSSIBLE IMPACT
         * =========================================================
         */

        if (
            status ==
            TemporalStatus.POSSIBLE_IMPACT
        ) {

            val elapsed =
                now -
                        possibleImpactTime

            /*
             * Candidate expired.
             */

            if (
                elapsed >
                MAX_IMPACT_WINDOW_MS
            ) {

                Log.i(
                    TAG,
                    "TEMPORAL: IMPACT CANDIDATE EXPIRED"
                )

                resetInternal()

                return createResult()
            }

            /*
             * Start settling.
             */

            if (
                settlingStartTime == 0L
            ) {

                settlingStartTime =
                    now

                status =
                    TemporalStatus.SETTLING

                Log.i(
                    TAG,
                    "TEMPORAL: SETTLING STARTED"
                )

                return createResult()
            }
        }

        /*
         * =========================================================
         * SETTLING
         * =========================================================
         */

        if (
            status ==
            TemporalStatus.SETTLING
        ) {

            val settlingElapsed =
                now -
                        settlingStartTime

            /*
             * If the device continues to experience strong
             * movement, the event is probably not a crash.
             */

            if (
                isContinuedMovement(
                    features
                )
            ) {

                movementSamplesAfterImpact++

                Log.d(
                    TAG,
                    "TEMPORAL: MOVEMENT DURING SETTLING = " +
                            "$movementSamplesAfterImpact/" +
                            "$MOVEMENT_CONFIRMATION_SAMPLES"
                )

                if (
                    movementSamplesAfterImpact >=
                    MOVEMENT_CONFIRMATION_SAMPLES
                ) {

                    Log.i(
                        TAG,
                        "TEMPORAL: CANDIDATE CANCELLED " +
                                "DUE TO CONTINUED MOVEMENT"
                    )

                    resetInternal()

                    return createResult()
                }

            } else {

                movementSamplesAfterImpact =
                    0
            }

            /*
             * Settling finished.
             */

            if (
                settlingElapsed >=
                SETTLING_WINDOW_MS
            ) {

                status =
                    TemporalStatus.IMMOBILITY_CHECK

                stationaryStartTime =
                    now

                stationarySamples =
                    0

                movementSamplesAfterImpact =
                    0

                Log.i(
                    TAG,
                    "TEMPORAL: IMMOBILITY CHECK STARTED"
                )

                return createResult()
            }

            return createResult()
        }

        /*
         * =========================================================
         * IMMOBILITY CHECK
         * =========================================================
         */

        if (
            status ==
            TemporalStatus.IMMOBILITY_CHECK
        ) {

            val stationary =
                isStationary(
                    features
                )

            if (
                stationary
            ) {

                stationarySamples++

                movementSamplesAfterImpact =
                    0

                val stationaryElapsed =
                    now -
                            stationaryStartTime

                Log.d(
                    TAG,
                    "TEMPORAL: STATIONARY " +
                            "$stationarySamples/" +
                            "$MIN_STATIONARY_SAMPLES" +
                            " | " +
                            stationaryElapsed +
                            "ms"
                )

                /*
                 * -------------------------------------------------
                 * FINAL CRASH CONFIRMATION
                 * -------------------------------------------------
                 *
                 * We require BOTH:
                 *
                 * 1. Enough stationary samples
                 * 2. Enough continuous stationary time
                 */

                if (
                    stationarySamples >=
                    MIN_STATIONARY_SAMPLES &&
                    stationaryElapsed >=
                    REQUIRED_IMMOBILITY_MS
                ) {

                    /*
                     * Final safety check.
                     *
                     * The original impact must also have contained
                     * enough physical evidence.
                     */

                    if (
                        hasStrongFinalCrashEvidence()
                    ) {

                        status =
                            TemporalStatus.CRASH_CONFIRMED

                        Log.w(
                            TAG,
                            "================================"
                        )

                        Log.w(
                            TAG,
                            "TEMPORAL: CRASH CONFIRMED"
                        )

                        Log.w(
                            TAG,
                            "ML PEAK = " +
                                    highestEnsembleProbability
                        )

                        Log.w(
                            TAG,
                            "ACC CHANGE PEAK = " +
                                    strongestAccelerationChange
                        )

                        Log.w(
                            TAG,
                            "GYRO CHANGE PEAK = " +
                                    strongestGyroChange
                        )

                        Log.w(
                            TAG,
                            "JERK PEAK = " +
                                    strongestJerk
                        )

                        Log.w(
                            TAG,
                            "ORIENTATION PEAK = " +
                                    strongestOrientationChange
                        )

                        Log.w(
                            TAG,
                            "SPEED CHANGE PEAK = " +
                                    strongestSpeedChange
                        )

                        Log.w(
                            TAG,
                            "================================"
                        )

                        return createResult()
                    }

                    /*
                     * The phone became stationary, but the original
                     * event was not strong enough to be considered
                     * a crash.
                     */

                    Log.i(
                        TAG,
                        "TEMPORAL: IMMOBILE BUT " +
                                "IMPACT EVIDENCE TOO WEAK"
                    )

                    resetInternal()

                    return createResult()
                }

            } else {

                stationarySamples =
                    0

                movementSamplesAfterImpact++

                Log.d(
                    TAG,
                    "TEMPORAL: MOVEMENT AFTER IMPACT = " +
                            "$movementSamplesAfterImpact/" +
                            "$MOVEMENT_CONFIRMATION_SAMPLES"
                )

                if (
                    movementSamplesAfterImpact >=
                    MOVEMENT_CONFIRMATION_SAMPLES
                ) {

                    Log.i(
                        TAG,
                        "TEMPORAL: IMMOBILITY FAILED"
                    )

                    resetInternal()

                    return createResult()
                }
            }

            return createResult()
        }

        /*
         * =========================================================
         * CRASH CONFIRMED
         * =========================================================
         */

        if (
            status ==
            TemporalStatus.CRASH_CONFIRMED
        ) {

            return createResult()
        }

        return createResult()
    }

    /*
     * =============================================================
     * COMPATIBILITY UPDATE
     * =============================================================
     */

    fun update(
        ensembleProbability: Float,
        accX: Float,
        accY: Float,
        accZ: Float,
        gyroX: Float,
        gyroY: Float,
        gyroZ: Float
    ): TemporalResult {

        val accelerationMagnitude =
            sqrt(
                accX * accX +
                        accY * accY +
                        accZ * accZ
            )

        val gyroMagnitude =
            sqrt(
                gyroX * gyroX +
                        gyroY * gyroY +
                        gyroZ * gyroZ
            )

        val features =
            AdvancedFeatures(

                accelerationMagnitude =
                    accelerationMagnitude,

                gyroMagnitude =
                    gyroMagnitude,

                accelerationChange =
                    0f,

                gyroChange =
                    0f,

                jerk =
                    0f,

                speedChange =
                    0f,

                tiltAngle =
                    0f,

                orientationChange =
                    0f,

                vibration =
                    0f,

                pulseRate =
                    null,

                pulseChange =
                    null,

                sensorConfidence =
                    calculateCompatibilityConfidence(
                        accelerationMagnitude,
                        gyroMagnitude
                    )
            )

        return update(
            ensembleProbability =
                ensembleProbability,
            features =
                features
        )
    }

    /*
     * =============================================================
     * COMPATIBILITY SENSOR CONFIDENCE
     * =============================================================
     */

    private fun calculateCompatibilityConfidence(
        accelerationMagnitude: Float,
        gyroMagnitude: Float
    ): Float {

        var confidence =
            0f

        if (
            accelerationMagnitude.isFinite()
        ) {
            confidence += 0.5f
        }

        if (
            gyroMagnitude.isFinite()
        ) {
            confidence += 0.5f
        }

        return confidence
            .coerceIn(0f, 1f)
    }

    /*
     * =============================================================
     * POSSIBLE IMPACT
     * =============================================================
     *
     * IMPORTANT:
     *
     * Small movement must NOT enter the crash state.
     *
     * ML alone must NOT enter the crash state.
     *
     * A crash candidate requires:
     *
     *     STRONG physical impact
     *
     * plus at least one supporting signal.
     */

    private fun isPossibleImpact(
        probability: Float,
        features: AdvancedFeatures
    ): Boolean {

        val strongAcceleration =
            features.accelerationChange >=
                    STRONG_ACCELERATION_CHANGE

        val veryStrongAcceleration =
            features.accelerationChange >=
                    VERY_STRONG_ACCELERATION_CHANGE

        val strongGyro =
            features.gyroChange >=
                    STRONG_GYRO_CHANGE

        val veryStrongGyro =
            features.gyroChange >=
                    VERY_STRONG_GYRO_CHANGE

        val strongJerk =
            features.jerk >=
                    STRONG_JERK

        val veryStrongJerk =
            features.jerk >=
                    VERY_STRONG_JERK

        val strongOrientation =
            features.orientationChange >=
                    STRONG_ORIENTATION_CHANGE

        val veryStrongOrientation =
            features.orientationChange >=
                    VERY_STRONG_ORIENTATION_CHANGE

        val strongSpeedChange =
            features.speedChange >=
                    STRONG_SPEED_CHANGE

        val veryStrongSpeedChange =
            features.speedChange >=
                    VERY_STRONG_SPEED_CHANGE

        /*
         * ---------------------------------------------------------
         * PHYSICAL IMPACT
         * ---------------------------------------------------------
         */

        val strongPhysicalImpact =
            strongAcceleration ||
                    strongGyro

        val veryStrongPhysicalImpact =
            veryStrongAcceleration ||
                    veryStrongGyro

        /*
         * ---------------------------------------------------------
         * ADVANCED SUPPORT
         * ---------------------------------------------------------
         */

        val strongAdvancedEvidence =
            strongJerk ||
                    strongOrientation ||
                    strongSpeedChange

        val veryStrongAdvancedEvidence =
            veryStrongJerk ||
                    veryStrongOrientation ||
                    veryStrongSpeedChange

        /*
         * ---------------------------------------------------------
         * CASE A
         *
         * Very strong physical impact.
         *
         * Even if ML is not perfect, a very large physical event
         * deserves investigation.
         * ---------------------------------------------------------
         */

        val caseA =
            veryStrongPhysicalImpact &&
                    (
                            probability >=
                                    SUPPORTING_ML_THRESHOLD ||
                                    veryStrongAdvancedEvidence
                            )

        /*
         * ---------------------------------------------------------
         * CASE B
         *
         * Strong physical impact + strong ML.
         * ---------------------------------------------------------
         */

        val caseB =
            strongPhysicalImpact &&
                    probability >=
                    STRONG_ML_THRESHOLD &&
                    strongAdvancedEvidence

        /*
         * ---------------------------------------------------------
         * CASE C
         *
         * Strong physical impact + very strong advanced evidence.
         * ---------------------------------------------------------
         */

        val caseC =
            strongPhysicalImpact &&
                    veryStrongAdvancedEvidence &&
                    probability >=
                    SUPPORTING_ML_THRESHOLD

        val possibleImpact =
            caseA ||
                    caseB ||
                    caseC

        if (
            possibleImpact
        ) {

            Log.d(
                TAG,
                "REAL IMPACT CANDIDATE: " +
                        "ML=$probability " +
                        "ACC=${features.accelerationChange} " +
                        "GYRO=${features.gyroChange} " +
                        "JERK=${features.jerk} " +
                        "ORI=${features.orientationChange} " +
                        "SPEED=${features.speedChange}"
            )
        }

        return possibleImpact
    }

    /*
     * =============================================================
     * FINAL CRASH EVIDENCE
     * =============================================================
     *
     * This is checked only after the phone has remained still.
     */

    private fun hasStrongFinalCrashEvidence(): Boolean {

        val strongPhysical =
            strongestAccelerationChange >=
                    STRONG_ACCELERATION_CHANGE ||
                    strongestGyroChange >=
                    STRONG_GYRO_CHANGE

        val veryStrongPhysical =
            strongestAccelerationChange >=
                    VERY_STRONG_ACCELERATION_CHANGE ||
                    strongestGyroChange >=
                    VERY_STRONG_GYRO_CHANGE

        val strongAdvanced =
            strongestJerk >=
                    STRONG_JERK ||
                    strongestOrientationChange >=
                    STRONG_ORIENTATION_CHANGE ||
                    strongestSpeedChange >=
                    STRONG_SPEED_CHANGE

        val veryStrongAdvanced =
            strongestJerk >=
                    VERY_STRONG_JERK ||
                    strongestOrientationChange >=
                    VERY_STRONG_ORIENTATION_CHANGE ||
                    strongestSpeedChange >=
                    VERY_STRONG_SPEED_CHANGE

        val strongML =
            highestEnsembleProbability >=
                    STRONG_ML_THRESHOLD

        val supportingML =
            highestEnsembleProbability >=
                    SUPPORTING_ML_THRESHOLD

        /*
         * Strong physical + strong ML + advanced evidence.
         */

        val caseA =
            strongPhysical &&
                    strongML &&
                    strongAdvanced

        /*
         * Very strong physical event + supporting ML.
         */

        val caseB =
            veryStrongPhysical &&
                    supportingML

        /*
         * Very strong physical + very strong advanced evidence.
         */

        val caseC =
            veryStrongPhysical &&
                    veryStrongAdvanced

        return caseA ||
                caseB ||
                caseC
    }

    /*
     * =============================================================
     * CONTINUED MOVEMENT
     * =============================================================
     */

    private fun isContinuedMovement(
        features: AdvancedFeatures
    ): Boolean {

        val accelerationMovement =
            features.accelerationChange >
                    (
                            STATIONARY_ACCELERATION_CHANGE +
                                    ACCELERATION_NOISE_MARGIN
                            )

        val gyroMovement =
            features.gyroChange >
                    (
                            STATIONARY_GYRO_CHANGE +
                                    GYRO_NOISE_MARGIN
                            )

        val rotationalMovement =
            features.gyroMagnitude >
                    STATIONARY_GYRO_MAGNITUDE

        val orientationMovement =
            features.orientationChange >
                    STRONG_ORIENTATION_CHANGE

        return accelerationMovement ||
                gyroMovement ||
                rotationalMovement ||
                orientationMovement
    }

    /*
     * =============================================================
     * STATIONARY CHECK
     * =============================================================
     */

    private fun isStationary(
        features: AdvancedFeatures
    ): Boolean {

        val accelerationStable =
            features.accelerationChange <=
                    STATIONARY_ACCELERATION_CHANGE

        val gyroStable =
            features.gyroChange <=
                    STATIONARY_GYRO_CHANGE

        val gyroLow =
            features.gyroMagnitude <=
                    STATIONARY_GYRO_MAGNITUDE

        return accelerationStable &&
                gyroStable &&
                gyroLow
    }

    /*
     * =============================================================
     * BEGIN IMPACT
     * =============================================================
     */

    private fun beginImpactWindow(
        now: Long,
        probability: Float,
        features: AdvancedFeatures
    ) {

        status =
            TemporalStatus.POSSIBLE_IMPACT

        possibleImpactTime =
            now

        settlingStartTime =
            0L

        stationaryStartTime =
            0L

        stationarySamples =
            0

        movementSamplesAfterImpact =
            0

        strongestAccelerationChange =
            features.accelerationChange

        strongestGyroChange =
            features.gyroChange

        strongestJerk =
            features.jerk

        strongestOrientationChange =
            features.orientationChange

        strongestSpeedChange =
            features.speedChange

        highestEnsembleProbability =
            probability
    }

    /*
     * =============================================================
     * LOG IMPACT
     * =============================================================
     */

    private fun logImpactEvidence(
        probability: Float,
        features: AdvancedFeatures
    ) {

        Log.i(
            TAG,
            "---------- IMPACT EVIDENCE ----------"
        )

        Log.i(
            TAG,
            "ML probability: $probability"
        )

        Log.i(
            TAG,
            "Acceleration change: " +
                    features.accelerationChange
        )

        Log.i(
            TAG,
            "Gyro change: " +
                    features.gyroChange
        )

        Log.i(
            TAG,
            "Jerk: " +
                    features.jerk
        )

        Log.i(
            TAG,
            "Orientation change: " +
                    features.orientationChange
        )

        Log.i(
            TAG,
            "Speed change: " +
                    features.speedChange
        )

        Log.i(
            TAG,
            "Gyro magnitude: " +
                    features.gyroMagnitude
        )

        Log.i(
            TAG,
            "Vibration: " +
                    features.vibration
        )

        Log.i(
            TAG,
            "Sensor confidence: " +
                    features.sensorConfidence
        )

        Log.i(
            TAG,
            "--------------------------------------"
        )
    }

    /*
     * =============================================================
     * RESULT
     * =============================================================
     */

    private fun createResult(): TemporalResult {

        return TemporalResult(
            crashConfirmed =
                status ==
                        TemporalStatus.CRASH_CONFIRMED,

            status =
                status
        )
    }

    /*
     * =============================================================
     * SIMULATE CRASH
     * =============================================================
     */

    fun simulateCrash(): TemporalResult {

        status =
            TemporalStatus.CRASH_CONFIRMED

        possibleImpactTime =
            System.currentTimeMillis()

        settlingStartTime =
            0L

        stationaryStartTime =
            0L

        stationarySamples =
            MIN_STATIONARY_SAMPLES

        movementSamplesAfterImpact =
            0

        Log.w(
            TAG,
            "================================"
        )

        Log.w(
            TAG,
            "TEMPORAL: SIMULATED CRASH"
        )

        Log.w(
            TAG,
            "TEMPORAL: CRASH CONFIRMED"
        )

        Log.w(
            TAG,
            "================================"
        )

        return createResult()
    }

    /*
     * =============================================================
     * RESET
     * =============================================================
     */

    fun reset() {

        resetInternal()

        Log.i(
            TAG,
            "TEMPORAL FILTER RESET"
        )
    }

    private fun resetInternal() {

        status =
            TemporalStatus.NORMAL

        possibleImpactTime =
            0L

        settlingStartTime =
            0L

        stationaryStartTime =
            0L

        stationarySamples =
            0

        movementSamplesAfterImpact =
            0

        strongestAccelerationChange =
            0f

        strongestGyroChange =
            0f

        strongestJerk =
            0f

        strongestOrientationChange =
            0f

        strongestSpeedChange =
            0f

        highestEnsembleProbability =
            0f

        lastUpdateTime =
            0L
    }
}