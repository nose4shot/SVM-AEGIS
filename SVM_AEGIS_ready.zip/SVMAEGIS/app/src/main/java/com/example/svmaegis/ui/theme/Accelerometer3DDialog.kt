package com.example.svmaegis.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.ui.window.Dialog
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Accelerometer3DDialog(
    ax: Float,
    ay: Float,
    az: Float,
    onClose: () -> Unit
) {

    Dialog(
        onDismissRequest =
            onClose
    ) {

        Column(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .clip(
                        RoundedCornerShape(
                            30.dp
                        )
                    )
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color(
                                    0xFF103B4C
                                ),

                                Color(
                                    0xFF071E29
                                ),

                                Color(
                                    0xFF04141B
                                )
                            )
                        )
                    )
                    .border(
                        width = 1.dp,
                        brush =
                            Brush.linearGradient(
                                listOf(
                                    Color(
                                        0xFF55D6FF
                                    ).copy(
                                        alpha =
                                            0.65f
                                    ),

                                    Color(
                                        0xFF43E68B
                                    ).copy(
                                        alpha =
                                            0.30f
                                    ),

                                    Color(
                                        0xFF7C8CFF
                                    ).copy(
                                        alpha =
                                            0.35f
                                    )
                                )
                            ),
                        shape =
                            RoundedCornerShape(
                                30.dp
                            )
                    )
                    .padding(
                        16.dp
                    )
        ) {

            Row(
                modifier =
                    Modifier.fillMaxWidth(),

                verticalAlignment =
                    Alignment.CenterVertically,

                horizontalArrangement =
                    Arrangement.SpaceBetween
            ) {

                Column {

                    Text(
                        text =
                            "ACCELEROMETER 3D",

                        color =
                            Color.White,

                        fontSize =
                            19.sp
                    )

                    Text(
                        text =
                            "Live motion visualization",

                        color =
                            Color.White.copy(
                                alpha =
                                    0.55f
                            ),

                        fontSize =
                            11.sp
                    )
                }

                Text(
                    text =
                        "● LIVE",

                    color =
                        Color(
                            0xFF52F2A0
                        ),

                    fontSize =
                        10.sp
                )
            }

            Spacer(
                modifier =
                    Modifier.height(
                        12.dp
                    )
            )

            Sensor3DViewport(
                sensorX =
                    ax,

                sensorY =
                    ay,

                sensorZ =
                    az,

                mode =
                    "ACCELEROMETER",

                modifier =
                    Modifier
                        .fillMaxWidth()
                        .height(
                            340.dp
                        )
            )

            Spacer(
                modifier =
                    Modifier.height(
                        12.dp
                    )
            )

            SensorValueRow(
                xLabel =
                    "AX",

                xValue =
                    ax,

                yLabel =
                    "AY",

                yValue =
                    ay,

                zLabel =
                    "AZ",

                zValue =
                    az
            )

            Spacer(
                modifier =
                    Modifier.height(
                        12.dp
                    )
            )

            Text(
                text =
                    "Drag to rotate  •  Pinch to zoom",

                modifier =
                    Modifier.fillMaxWidth(),

                color =
                    Color.White.copy(
                        alpha =
                            0.45f
                    ),

                fontSize =
                    10.sp
            )

            Spacer(
                modifier =
                    Modifier.height(
                        10.dp
                    )
            )

            Button(
                onClick =
                    onClose,

                modifier =
                    Modifier.fillMaxWidth(),

                shape =
                    RoundedCornerShape(
                        17.dp
                    ),

                colors =
                    ButtonDefaults.buttonColors(
                        containerColor =
                            Color(
                                0xFF17627D
                            )
                    )
            ) {

                Text(
                    text =
                        "CLOSE",

                    color =
                        Color.White
                )
            }
        }
    }
}