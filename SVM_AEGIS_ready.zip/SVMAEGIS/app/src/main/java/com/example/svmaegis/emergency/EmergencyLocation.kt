package com.example.svmaegis.emergency

data class EmergencyLocation(
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val address: String = ""
) {
    fun mapsUrl(): String {
        return "https://maps.google.com/?q=$latitude,$longitude"
    }
}
