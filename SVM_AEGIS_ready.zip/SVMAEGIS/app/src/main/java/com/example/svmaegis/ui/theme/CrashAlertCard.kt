
package com.example.svmaegis.ui.theme

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.svmaegis.PersonalProfile

@Composable
fun CrashAlertCard(

    countdown: Int,

    alertSent: Boolean,

    profile: PersonalProfile,

    onCancel: () -> Unit

) {

    Card(

        modifier =
            Modifier.fillMaxWidth(),

        shape =
            RoundedCornerShape(24.dp),

        colors =
            CardDefaults.cardColors(

                containerColor =
                    Color(0xFF35171B)
            )
    ) {

        Column(

            modifier =
                Modifier
                    .fillMaxWidth()
                    .padding(20.dp),

            horizontalAlignment =
                Alignment.CenterHorizontally,

            verticalArrangement =
                Arrangement.Center
        ) {

            Text(
                text = "🚨",
                fontSize = 42.sp
            )

            Spacer(
                modifier =
                    Modifier.height(8.dp)
            )

            Text(

                text =
                    if (alertSent) {

                        "EMERGENCY ALERT ACTIVE"

                    } else {

                        "CRASH DETECTED"
                    },

                color =
                    Color(0xFFFF453A),

                fontSize =
                    20.sp,

                fontWeight =
                    FontWeight.Bold,

                textAlign =
                    TextAlign.Center
            )

            Spacer(
                modifier =
                    Modifier.height(8.dp)
            )

            if (!alertSent) {

                Text(

                    text =
                        "Emergency contacts will be notified in",

                    color =
                        Color.White.copy(
                            alpha = 0.75f
                        ),

                    fontSize =
                        13.sp,

                    textAlign =
                        TextAlign.Center
                )

                Spacer(
                    modifier =
                        Modifier.height(4.dp)
                )

                Text(

                    text =
                        countdown.toString(),

                    color =
                        Color.White,

                    fontSize =
                        52.sp,

                    fontWeight =
                        FontWeight.Bold
                )

                Text(

                    text =
                        "SECONDS",

                    color =
                        Color.White.copy(
                            alpha = 0.6f
                        ),

                    fontSize =
                        10.sp
                )

            } else {

                Text(

                    text =
                        if (
                            profile
                                .emergencyName
                                .isNotBlank()
                        ) {

                            "Emergency contact: " +
                                    profile.emergencyName

                        } else {

                            "Emergency alert activated."
                        },

                    color =
                        Color.White.copy(
                            alpha = 0.75f
                        ),

                    fontSize =
                        13.sp,

                    textAlign =
                        TextAlign.Center
                )
            }

            Spacer(
                modifier =
                    Modifier.height(16.dp)
            )

            Button(

                onClick =
                    onCancel,

                modifier =
                    Modifier
                        .fillMaxWidth()
                        .height(52.dp),

                shape =
                    RoundedCornerShape(14.dp),

                colors =
                    ButtonDefaults.buttonColors(

                        containerColor =
                            Color(0xFF522328)
                    )
            ) {

                Text(

                    text =
                        "✓  I'M SAFE — CANCEL ALERT",

                    fontWeight =
                        FontWeight.Bold
                )
            }
        }
    }
}
