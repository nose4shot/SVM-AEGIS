package com.example.svmaegis.data

data class SensorStatus(
    val phoneAccelerometer: Boolean = false,
    val phoneGyroscope: Boolean = false,
    val phoneGps: Boolean = false,
    val bleConnected: Boolean = false,
    val externalConnected: Boolean = false,
    val externalAccelerometer: Boolean = false,
    val externalGyroscope: Boolean = false,
    val externalGps: Boolean = false,
    val lastExternalPacketMillis: Long? = null
) {
    val phoneReady: Boolean
        get() = phoneAccelerometer && phoneGyroscope

    val externalImuReady: Boolean
        get() = externalConnected &&
                externalAccelerometer &&
                externalGyroscope

    val externalReady: Boolean
        get() = externalConnected &&
                (externalAccelerometer || externalGyroscope || externalGps)
}
