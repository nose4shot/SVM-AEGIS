package com.example.svmaegis.bluetooth

import android.bluetooth.BluetoothDevice

data class BleDevice(
    val device: BluetoothDevice,
    val name: String = device.name ?: "Unknown BLE Device",
    val address: String = device.address
)
