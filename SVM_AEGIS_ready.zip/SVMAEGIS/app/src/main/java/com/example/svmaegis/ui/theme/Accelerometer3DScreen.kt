package com.example.svmaegis.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AccelerometerScreen(
    ax: Float,
    ay: Float,
    az: Float,
    onBack: () -> Unit
) {

    Column(
        modifier =
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color(
                                0xFF061E28
                            ),

                            Color(
                                0xFF04141C
                            )
                        )
                    )
                )
                .padding(
                    18.dp
                )
    ) {

        Row(
            modifier =
                Modifier.fillMaxWidth(),

            verticalAlignment =
                Alignment.CenterVertically,

            horizontalArrangement =
                Arrangement.SpaceBetween
        ) {

            Column {

                Text(
                    text =
                        "ACCELEROMETER",

                    color =
                        Color.White,

                    fontSize =
                        24.sp
                )

                Text(
                    text =
                        "3D motion monitor",

                    color =
                        Color.White.copy(
                            alpha =
                                0.55f
                        ),

                    fontSize =
                        12.sp
                )
            }

            Text(
                text =
                    "● LIVE",

                color =
                    Color(
                        0xFF52F2A0
                    ),

                fontSize =
                    11.sp
            )
        }

        Spacer(
            modifier =
                Modifier.height(
                    18.dp
                )
        )

        Sensor3DViewport(
            sensorX =
                ax,

            sensorY =
                ay,

            sensorZ =
                az,

            mode =
                "ACCELEROMETER",

            modifier =
                Modifier
                    .fillMaxWidth()
                    .weight(1f)
        )

        Spacer(
            modifier =
                Modifier.height(
                    16.dp
                )
        )

        SensorValueRow(
            xLabel =
                "AX",

            xValue =
                ax,

            yLabel =
                "AY",

            yValue =
                ay,

            zLabel =
                "AZ",

            zValue =
                az
        )

        Spacer(
            modifier =
                Modifier.height(
                    14.dp
                )
        )

        Button(
            onClick =
                onBack,

            modifier =
                Modifier.fillMaxWidth(),

            shape =
                RoundedCornerShape(
                    18.dp
                ),

            colors =
                ButtonDefaults.buttonColors(
                    containerColor =
                        Color(
                            0xFF17627D
                        )
                )
        ) {

            Text(
                text =
                    "BACK"
            )
        }
    }
}