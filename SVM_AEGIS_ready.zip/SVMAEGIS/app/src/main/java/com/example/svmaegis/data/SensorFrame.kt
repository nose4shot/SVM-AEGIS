package com.example.svmaegis.data

import kotlin.math.sqrt

data class SensorFrame(
    val timestampMillis: Long,
    val accX: Float,
    val accY: Float,
    val accZ: Float,
    val gyroX: Float,
    val gyroY: Float,
    val gyroZ: Float,
    val speedKmh: Float,
    val latitude: Double,
    val longitude: Double,
    val vibration: Float? = null,
    val temperatureCelsius: Float? = null,
    val source: SensorSource
) {
    val accelerationMagnitude: Float
        get() = sqrt(accX * accX + accY * accY + accZ * accZ)

    val gyroscopeMagnitude: Float
        get() = sqrt(gyroX * gyroX + gyroY * gyroY + gyroZ * gyroZ)
}
