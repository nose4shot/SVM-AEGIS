package com.example.svmaegis

import android.content.Context
import com.example.svmaegis.data.SensorFrame
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SensorDataRecorder(private val context: Context) {

    private var file: File? = null

    var isRecording: Boolean = false
        private set

    var sampleCount: Int = 0
        private set

    fun startRecording() {
        if (isRecording) return

        val timestamp = SimpleDateFormat(
            "yyyyMMdd_HHmmss",
            Locale.getDefault()
        ).format(Date())

        file = File(context.filesDir, "SVM_AEGIS_$timestamp.csv")
        file!!.writeText(
            "timestamp,ax,ay,az,gx,gy,gz,latitude,longitude,speed_kmh," +
                    "acc_magnitude,gyro_magnitude,vibration,temperature,source,label\n"
        )

        sampleCount = 0
        isRecording = true
    }

    fun addSample(frame: SensorFrame, label: String) {
        if (!isRecording) return

        val timestamp = SimpleDateFormat(
            "yyyy-MM-dd HH:mm:ss.SSS",
            Locale.getDefault()
        ).format(Date(frame.timestampMillis))

        val row = listOf(
            timestamp,
            frame.accX,
            frame.accY,
            frame.accZ,
            frame.gyroX,
            frame.gyroY,
            frame.gyroZ,
            frame.latitude,
            frame.longitude,
            frame.speedKmh,
            frame.accelerationMagnitude,
            frame.gyroscopeMagnitude,
            frame.vibration ?: "",
            frame.temperatureCelsius ?: "",
            frame.source.name,
            label
        ).joinToString(",")

        file?.appendText("$row\n")
        sampleCount++
    }

    fun stopRecording() {
        isRecording = false
    }

    fun getFilePath(): String =
        file?.absolutePath ?: "No file created"
}
