package com.example.svmaegis.emergency

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale

class EmergencyManager(
    private val context: Context
) {

    private var textToSpeech: TextToSpeech? = null

    private var emergencyActive = false

    init {
        textToSpeech = TextToSpeech(
            context
        ) { status ->

            if (status == TextToSpeech.SUCCESS) {
                textToSpeech?.language =
                    Locale.US

                Log.i(
                    TAG,
                    "Text-to-speech initialized"
                )
            }
        }
    }

    fun startEmergencyCountdown() {

        if (emergencyActive) {
            return
        }

        emergencyActive = true

        speak(
            "Possible accident detected. " +
                    "Emergency assistance will be contacted " +
                    "if the alert is not cancelled."
        )

        Log.i(
            TAG,
            "Emergency countdown started"
        )
    }

    fun cancelEmergency() {

        if (!emergencyActive) {
            return
        }

        emergencyActive = false

        speak(
            "Emergency alert cancelled."
        )

        Log.i(
            TAG,
            "Emergency alert cancelled"
        )
    }

    fun isEmergencyActive(): Boolean {

        return emergencyActive
    }

    fun sendEmergencyMessage(
        phoneNumber: String,
        latitude: Double,
        longitude: Double,
        speedKmh: Float,
        impactIntensity: Float,
        eventType: String
    ) {

        val location =
            "https://maps.google.com/?q=$latitude,$longitude"

        val message =
            "SVM-AEGIS EMERGENCY ALERT\n\n" +
                    "Possible vehicle accident detected.\n\n" +
                    "Event: $eventType\n" +
                    "Impact intensity: " +
                    "%.2f".format(impactIntensity) +
                    "\n" +
                    "Speed: " +
                    "%.1f".format(speedKmh) +
                    " km/h\n\n" +
                    "Accident location:\n" +
                    location

        openSms(
            phoneNumber = phoneNumber,
            message = message
        )

        Log.i(
            TAG,
            "Emergency SMS prepared"
        )
    }

    fun makeEmergencyCall(
        phoneNumber: String
    ) {

        try {

            val intent =
                Intent(
                    Intent.ACTION_DIAL
                ).apply {

                    data =
                        Uri.parse(
                            "tel:$phoneNumber"
                        )

                }

            intent.addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK
            )

            context.startActivity(
                intent
            )

            Log.i(
                TAG,
                "Emergency call screen opened"
            )

        } catch (exception: Exception) {

            Log.e(
                TAG,
                "Unable to open phone dialer",
                exception
            )
        }
    }

    private fun openSms(
        phoneNumber: String,
        message: String
    ) {

        try {

            val intent =
                Intent(
                    Intent.ACTION_SENDTO
                ).apply {

                    data =
                        Uri.parse(
                            "smsto:$phoneNumber"
                        )

                    putExtra(
                        "sms_body",
                        message
                    )
                }

            intent.addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK
            )

            context.startActivity(
                intent
            )

        } catch (exception: Exception) {

            Log.e(
                TAG,
                "Unable to open SMS application",
                exception
            )
        }
    }

    fun speak(
        message: String
    ) {

        textToSpeech?.speak(
            message,
            TextToSpeech.QUEUE_FLUSH,
            null,
            "SVM_AEGIS_EMERGENCY"
        )
    }

    fun release() {

        textToSpeech?.stop()

        textToSpeech?.shutdown()

        textToSpeech = null

        emergencyActive = false

        Log.i(
            TAG,
            "Emergency manager released"
        )
    }

    companion object {

        private const val TAG =
            "SVM_AEGIS"
    }
}