package com.example.svmaegis.ui.theme

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

private data class S3DPoint(
    val x: Float,
    val y: Float,
    val z: Float
)

private data class S2DPoint(
    val x: Float,
    val y: Float
)

private fun rotateX(
    p: S3DPoint,
    degrees: Float
): S3DPoint {

    val r = Math.toRadians(degrees.toDouble())

    val c = cos(r).toFloat()
    val s = sin(r).toFloat()

    return S3DPoint(
        x = p.x,
        y = p.y * c - p.z * s,
        z = p.y * s + p.z * c
    )
}

private fun rotateY(
    p: S3DPoint,
    degrees: Float
): S3DPoint {

    val r = Math.toRadians(degrees.toDouble())

    val c = cos(r).toFloat()
    val s = sin(r).toFloat()

    return S3DPoint(
        x = p.x * c + p.z * s,
        y = p.y,
        z = -p.x * s + p.z * c
    )
}

private fun rotateZ(
    p: S3DPoint,
    degrees: Float
): S3DPoint {

    val r = Math.toRadians(degrees.toDouble())

    val c = cos(r).toFloat()
    val s = sin(r).toFloat()

    return S3DPoint(
        x = p.x * c - p.y * s,
        y = p.x * s + p.y * c,
        z = p.z
    )
}

private fun rotatePoint(
    point: S3DPoint,
    rx: Float,
    ry: Float,
    rz: Float
): S3DPoint {

    var result = point

    result = rotateX(result, rx)
    result = rotateY(result, ry)
    result = rotateZ(result, rz)

    return result
}

private fun project(
    point: S3DPoint,
    centerX: Float,
    centerY: Float,
    scale: Float
): S2DPoint {

    val cameraDistance = 900f

    val depth =
        (cameraDistance - point.z)
            .coerceAtLeast(150f)

    val perspective =
        cameraDistance / depth

    return S2DPoint(
        x = centerX + point.x * scale * perspective,
        y = centerY + point.y * scale * perspective
    )
}

@Composable
fun Sensor3DViewport(
    sensorX: Float,
    sensorY: Float,
    sensorZ: Float,
    mode: String,
    modifier: Modifier = Modifier
) {

    var manualX by remember {
        mutableFloatStateOf(0f)
    }

    var manualY by remember {
        mutableFloatStateOf(0f)
    }

    var zoom by remember {
        mutableFloatStateOf(1f)
    }

    Box(
        modifier = modifier
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF164A5A),
                        Color(0xFF08252F),
                        Color(0xFF02090D)
                    )
                )
            )
            .pointerInput(Unit) {

                detectTransformGestures { _, pan, gestureZoom, _ ->

                    manualY += pan.x * 0.45f
                    manualX -= pan.y * 0.45f

                    zoom =
                        (zoom * gestureZoom)
                            .coerceIn(0.55f, 1.8f)
                }
            }
    ) {

        Canvas(
            modifier = Modifier.fillMaxSize()
        ) {

            val centerX = size.width / 2f
            val centerY = size.height / 2f

            val rx = sensorX + manualX
            val ry = sensorY + manualY
            val rz = sensorZ

            drawBackgroundGrid(
                centerX = centerX,
                centerY = centerY
            )

            drawAxes(
                centerX = centerX,
                centerY = centerY,
                scale = zoom,
                rx = rx,
                ry = ry,
                rz = rz
            )

            drawSensorCube(
                centerX = centerX,
                centerY = centerY,
                scale = zoom,
                rx = rx,
                ry = ry,
                rz = rz
            )
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawBackgroundGrid(
    centerX: Float,
    centerY: Float
) {

    val gridColor = Color(0x223BA8C7)

    for (i in -10..10) {

        val x = centerX + i * 45f
        val y = centerY + i * 45f

        drawLine(
            color = gridColor,
            start = Offset(x, 0f),
            end = Offset(x, size.height),
            strokeWidth = 1f
        )

        drawLine(
            color = gridColor,
            start = Offset(0f, y),
            end = Offset(size.width, y),
            strokeWidth = 1f
        )
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawSensorCube(
    centerX: Float,
    centerY: Float,
    scale: Float,
    rx: Float,
    ry: Float,
    rz: Float
) {

    val s = 125f

    val points = arrayOf(
        S3DPoint(-s, -s, s),
        S3DPoint(s, -s, s),
        S3DPoint(s, s, s),
        S3DPoint(-s, s, s),

        S3DPoint(-s, -s, -s),
        S3DPoint(s, -s, -s),
        S3DPoint(s, s, -s),
        S3DPoint(-s, s, -s)
    )

    drawCircle(
        color = Color(0x1938E8FF),
        radius = 220f,
        center = Offset(
            centerX,
            centerY
        )
    )

    val edges = arrayOf(
        0 to 1,
        1 to 2,
        2 to 3,
        3 to 0,

        4 to 5,
        5 to 6,
        6 to 7,
        7 to 4,

        0 to 4,
        1 to 5,
        2 to 6,
        3 to 7
    )

    edges.forEachIndexed { index, edge ->

        val p1 =
            project(
                rotatePoint(
                    points[edge.first],
                    rx,
                    ry,
                    rz
                ),
                centerX,
                centerY,
                scale
            )

        val p2 =
            project(
                rotatePoint(
                    points[edge.second],
                    rx,
                    ry,
                    rz
                ),
                centerX,
                centerY,
                scale
            )

        val color =
            if (index < 4) {
                Color(0xFF55D9FF)
            } else {
                Color(0xFF27758D)
            }

        drawLine(
            color = color,
            start = Offset(
                p1.x,
                p1.y
            ),
            end = Offset(
                p2.x,
                p2.y
            ),
            strokeWidth =
                if (index < 4) {
                    7f
                } else {
                    4f
                }
        )
    }

    val chip =
        project(
            rotatePoint(
                S3DPoint(
                    0f,
                    0f,
                    s + 20f
                ),
                rx,
                ry,
                rz
            ),
            centerX,
            centerY,
            scale
        )

    drawCircle(
        color = Color(0x5538E8FF),
        radius = 32f,
        center = Offset(
            chip.x,
            chip.y
        )
    )

    drawCircle(
        color = Color(0xFF55E8FF),
        radius = 15f,
        center = Offset(
            chip.x,
            chip.y
        )
    )

    drawCircle(
        color = Color.White,
        radius = 5f,
        center = Offset(
            chip.x,
            chip.y
        )
    )
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawAxes(
    centerX: Float,
    centerY: Float,
    scale: Float,
    rx: Float,
    ry: Float,
    rz: Float
) {

    draw3DLine(
        S3DPoint(0f, 0f, 0f),
        S3DPoint(300f, 0f, 0f),
        centerX,
        centerY,
        scale,
        rx,
        ry,
        rz,
        Color(0xFFFF4D5A)
    )

    draw3DLine(
        S3DPoint(0f, 0f, 0f),
        S3DPoint(0f, -300f, 0f),
        centerX,
        centerY,
        scale,
        rx,
        ry,
        rz,
        Color(0xFF4DFF88)
    )

    draw3DLine(
        S3DPoint(0f, 0f, 0f),
        S3DPoint(0f, 0f, 300f),
        centerX,
        centerY,
        scale,
        rx,
        ry,
        rz,
        Color(0xFF4DB8FF)
    )
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.draw3DLine(
    a: S3DPoint,
    b: S3DPoint,
    centerX: Float,
    centerY: Float,
    scale: Float,
    rx: Float,
    ry: Float,
    rz: Float,
    color: Color
) {

    val p1 =
        project(
            rotatePoint(a, rx, ry, rz),
            centerX,
            centerY,
            scale
        )

    val p2 =
        project(
            rotatePoint(b, rx, ry, rz),
            centerX,
            centerY,
            scale
        )

    drawLine(
        color = color,
        start = Offset(
            p1.x,
            p1.y
        ),
        end = Offset(
            p2.x,
            p2.y
        ),
        strokeWidth = 6f
    )
}

@Composable
fun SensorValueRow(
    xValue: Float,
    yValue: Float,
    zValue: Float,
    xTitle: String = "",
    yTitle: String = "",
    zTitle: String = "",
    xLabel: String? = null,
    yLabel: String? = null,
    zLabel: String? = null
) {

    val finalXTitle =
        xLabel ?: xTitle

    val finalYTitle =
        yLabel ?: yTitle

    val finalZTitle =
        zLabel ?: zTitle

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {

        SensorValueCard(
            title = finalXTitle,
            value = xValue,
            color = Color(0xFFFF4D5A),
            modifier = Modifier.weight(1f)
        )

        SensorValueCard(
            title = finalYTitle,
            value = yValue,
            color = Color(0xFF4DFF88),
            modifier = Modifier.weight(1f)
        )

        SensorValueCard(
            title = finalZTitle,
            value = zValue,
            color = Color(0xFF4DB8FF),
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun SensorValueCard(
    title: String,
    value: Float,
    color: Color,
    modifier: Modifier
) {

    Column(
        modifier = modifier
            .background(
                color = Color.White.copy(
                    alpha = 0.08f
                ),
                shape = RoundedCornerShape(14.dp)
            )
            .padding(
                horizontal = 8.dp,
                vertical = 10.dp
            ),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Text(
            text = title,
            color = color,
            fontSize = 12.sp
        )

        Text(
            text = "%.2f".format(value),
            color = Color.White,
            fontSize = 14.sp
        )
    }
}