package com.example.svmaegis.sensors

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import com.example.svmaegis.data.SensorFrame
import com.example.svmaegis.data.SensorSource

class PhoneSensorManager(
    context: Context,
    private val onFrame: (SensorFrame) -> Unit,
    private val onAvailabilityChanged: (Boolean, Boolean) -> Unit = { _, _ -> }
) : SensorEventListener {

    private val sensorManager =
        context.getSystemService(Context.SENSOR_SERVICE) as SensorManager

    private val accelerometer =
        sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    private val gyroscope =
        sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

    private var ax = 0f
    private var ay = 0f
    private var az = 0f

    private var gx = 0f
    private var gy = 0f
    private var gz = 0f

    private var haveAcceleration = false
    private var haveGyroscope = false

    var latestLatitude: Double = 0.0
    var latestLongitude: Double = 0.0
    var latestSpeedKmh: Float = 0f
    var gpsAvailable: Boolean = false

    val hasAccelerometer: Boolean
        get() = accelerometer != null

    val hasGyroscope: Boolean
        get() = gyroscope != null

    fun start() {
        haveAcceleration = false
        haveGyroscope = false

        val accelRegistered = accelerometer?.let {
            sensorManager.registerListener(
                this,
                it,
                SensorManager.SENSOR_DELAY_GAME
            )
        } ?: false

        val gyroRegistered = gyroscope?.let {
            sensorManager.registerListener(
                this,
                it,
                SensorManager.SENSOR_DELAY_GAME
            )
        } ?: false

        onAvailabilityChanged(
            accelRegistered,
            gyroRegistered
        )
    }

    fun stop() {
        sensorManager.unregisterListener(this)
    }

    fun updateLocation(
        latitude: Double,
        longitude: Double,
        speedKmh: Float
    ) {
        latestLatitude = latitude
        latestLongitude = longitude
        latestSpeedKmh = speedKmh
        gpsAvailable = true
    }

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> {
                ax = event.values[0]
                ay = event.values[1]
                az = event.values[2]
                haveAcceleration = true
            }

            Sensor.TYPE_GYROSCOPE -> {
                gx = event.values[0]
                gy = event.values[1]
                gz = event.values[2]
                haveGyroscope = true
            }
        }

        if (haveAcceleration && haveGyroscope) {
            onFrame(
                SensorFrame(
                    timestampMillis = System.currentTimeMillis(),
                    accX = ax,
                    accY = ay,
                    accZ = az,
                    gyroX = gx,
                    gyroY = gy,
                    gyroZ = gz,
                    speedKmh = latestSpeedKmh,
                    latitude = latestLatitude,
                    longitude = latestLongitude,
                    source = SensorSource.PHONE
                )
            )
        }
    }

    override fun onAccuracyChanged(
        sensor: Sensor?,
        accuracy: Int
    ) = Unit
}
