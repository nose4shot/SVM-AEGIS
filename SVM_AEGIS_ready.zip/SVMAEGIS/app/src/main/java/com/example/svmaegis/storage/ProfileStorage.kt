package com.example.svmaegis.storage

import android.content.Context
import com.example.svmaegis.PersonalProfile

class ProfileStorage(context: Context) {

    companion object {
        private const val PREFS = "SVM_AEGIS_PROFILE"
    }

    private val preferences =
        context.getSharedPreferences(
            PREFS,
            Context.MODE_PRIVATE
        )

    fun load(): PersonalProfile {
        return PersonalProfile(
            name = preferences.getString("name", "") ?: "",
            phone = preferences.getString("phone", "") ?: "",
            bloodGroup =
                preferences.getString("bloodGroup", "") ?: "",
            emergencyName =
                preferences.getString("emergencyName", "") ?: "",
            emergencyPhone =
                preferences.getString("emergencyPhone", "") ?: "",
            address =
                preferences.getString("address", "") ?: ""
        )
    }

    fun save(profile: PersonalProfile) {
        preferences.edit()
            .putString("name", profile.name)
            .putString("phone", profile.phone)
            .putString("bloodGroup", profile.bloodGroup)
            .putString("emergencyName", profile.emergencyName)
            .putString("emergencyPhone", profile.emergencyPhone)
            .putString("address", profile.address)
            .apply()
    }
}
