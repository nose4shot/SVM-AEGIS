package com.example.svmaegis.data

enum class SensorSource {
    PHONE,
    EXTERNAL,
    HYBRID
}
