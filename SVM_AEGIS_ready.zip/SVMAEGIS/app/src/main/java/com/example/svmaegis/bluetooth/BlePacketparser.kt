package com.example.svmaegis.bluetooth

data class ExternalSensorPacket(
    val accX: Float? = null,
    val accY: Float? = null,
    val accZ: Float? = null,
    val gyroX: Float? = null,
    val gyroY: Float? = null,
    val gyroZ: Float? = null,
    val speedKmh: Float? = null,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val vibration: Float? = null,
    val temperatureCelsius: Float? = null,
    val timestampMillis: Long = System.currentTimeMillis()
) {
    val hasAccelerometer: Boolean
        get() = accX != null && accY != null && accZ != null

    val hasGyroscope: Boolean
        get() = gyroX != null && gyroY != null && gyroZ != null

    val hasGps: Boolean
        get() = latitude != null && longitude != null
}

object BlePacketParser {

    /*
     * CSV protocol:
     * ACCX,ACCY,ACCZ,GYROX,GYROY,GYROZ,SPEED,LAT,LON,VIB,TEMP
     *
     * Example:
     * 0.12,-0.22,9.81,0.01,0.02,0.03,42.5,13.0827,80.2707,0.02,31.5
     */
    fun parse(text: String): ExternalSensorPacket? {
        val clean = text.trim()
        if (clean.isEmpty()) return null

        val values = clean.split(",").map { it.trim() }
        if (values.size < 9) return null

        fun floatAt(index: Int): Float? =
            values.getOrNull(index)
                ?.takeIf { it.isNotEmpty() }
                ?.toFloatOrNull()

        fun doubleAt(index: Int): Double? =
            values.getOrNull(index)
                ?.takeIf { it.isNotEmpty() }
                ?.toDoubleOrNull()

        return ExternalSensorPacket(
            accX = floatAt(0),
            accY = floatAt(1),
            accZ = floatAt(2),
            gyroX = floatAt(3),
            gyroY = floatAt(4),
            gyroZ = floatAt(5),
            speedKmh = floatAt(6),
            latitude = doubleAt(7),
            longitude = doubleAt(8),
            vibration = floatAt(9),
            temperatureCelsius = floatAt(10)
        )
    }
}
