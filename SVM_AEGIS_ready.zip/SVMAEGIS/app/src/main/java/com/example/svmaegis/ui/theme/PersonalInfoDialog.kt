package com.example.svmaegis.ui.theme

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.svmaegis.PersonalProfile

@Composable
fun PersonalInfoDialog(
    existingProfile: PersonalProfile,
    onDismiss: () -> Unit,
    onSave: (PersonalProfile) -> Unit
) {
    var name by remember { mutableStateOf(existingProfile.name) }
    var phone by remember { mutableStateOf(existingProfile.phone) }
    var bloodGroup by remember { mutableStateOf(existingProfile.bloodGroup) }
    var emergencyName by remember { mutableStateOf(existingProfile.emergencyName) }
    var emergencyPhone by remember { mutableStateOf(existingProfile.emergencyPhone) }
    var address by remember { mutableStateOf(existingProfile.address) }

    AlertDialog(
        onDismissRequest = onDismiss,

        title = {
            Text("Personal Information")
        },

        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = bloodGroup,
                    onValueChange = { bloodGroup = it },
                    label = { Text("Blood Group") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = emergencyName,
                    onValueChange = { emergencyName = it },
                    label = { Text("Emergency Contact Name") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = emergencyPhone,
                    onValueChange = { emergencyPhone = it },
                    label = { Text("Emergency Contact Phone") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Home Address") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    maxLines = 4
                )
            }
        },

        confirmButton = {
            TextButton(
                onClick = {
                    val updatedProfile = PersonalProfile(
                        name = name.trim(),
                        phone = phone.trim(),
                        bloodGroup = bloodGroup.trim(),
                        emergencyName = emergencyName.trim(),
                        emergencyPhone = emergencyPhone.trim(),
                        address = address.trim()
                    )

                    onSave(updatedProfile)
                }
            ) {
                Text("SAVE")
            }
        },

        dismissButton = {
            TextButton(
                onClick = onDismiss
            ) {
                Text("CANCEL")
            }
        }
    )
}