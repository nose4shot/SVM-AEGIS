package com.example.svmaegis

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.svmaegis.data.SensorFrame
import com.example.svmaegis.data.SensorSource
import com.example.svmaegis.detection.CrashDetector
import com.example.svmaegis.detection.TemporalStatus
import com.example.svmaegis.emergency.EmergencyController
import com.example.svmaegis.ml.AdvancedFeatures
import com.example.svmaegis.ui.theme.SensorScreen
import com.example.svmaegis.weather.WeatherManager
import com.example.svmaegis.weather.WeatherState
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.sqrt

class MainActivity : ComponentActivity(), SensorEventListener {

    companion object {
        private const val TAG = "SVM_AEGIS"

        private const val PROFILE_PREF = "SVM_AEGIS_PROFILE"

        private const val SENSOR_DELAY =
            SensorManager.SENSOR_DELAY_GAME

        private const val LOCATION_INTERVAL = 1000L
        private const val LOCATION_DISTANCE = 1f

        private const val WEATHER_REFRESH_INTERVAL =
            5 * 60 * 1000L

        private const val WEATHER_MIN_DISTANCE_KM = 1.0

        /*
         * Run AI approximately 10 times per second.
         */
        private const val INFERENCE_INTERVAL_MS = 100L

        /*
         * Accelerometer and gyroscope samples must be reasonably fresh
         * before running the AI.
         */
        private const val SENSOR_PAIR_MAX_AGE_MS = 500L
    }

    // ========================================================================
    // ANDROID SERVICES
    // ========================================================================

    private lateinit var sensorManager: SensorManager
    private lateinit var locationManager: LocationManager

    // ========================================================================
    // AI
    // ========================================================================

    private lateinit var crashDetector: CrashDetector

    private var emergencyController: EmergencyController? = null

    // ========================================================================
    // WEATHER
    // ========================================================================

    private lateinit var weatherManager: WeatherManager

    private var weatherJob: Job? = null

    private var lastWeatherLatitude = Double.NaN
    private var lastWeatherLongitude = Double.NaN
    private var lastWeatherUpdateTime = 0L

    // ========================================================================
    // SENSOR STATE
    // ========================================================================

    private val accelerometerXState =
        mutableFloatStateOf(0f)

    private val accelerometerYState =
        mutableFloatStateOf(0f)

    private val accelerometerZState =
        mutableFloatStateOf(0f)

    private val gyroscopeXState =
        mutableFloatStateOf(0f)

    private val gyroscopeYState =
        mutableFloatStateOf(0f)

    private val gyroscopeZState =
        mutableFloatStateOf(0f)

    private var hasAccelerometerSample = false
    private var hasGyroscopeSample = false

    private var lastAccelerometerTimestampMs = 0L
    private var lastGyroscopeTimestampMs = 0L
    private var lastInferenceTimeMs = 0L

    private var accelerometerAvailable = false
    private var gyroscopeAvailable = false

    private var sensorListenersRegistered = false

    // ========================================================================
    // ADVANCED FEATURE STATE
    // ========================================================================

    private var previousAccelerationMagnitude = 0f
    private var previousGyroMagnitude = 0f
    private var previousSpeedKmh = 0f
    private var previousTiltAngle = 0f
    private var previousFeatureTimestampMs = 0L

    private var hasPreviousAdvancedFeatures = false

    // ========================================================================
    // LOCATION STATE
    // ========================================================================

    private val latitudeState =
        mutableStateOf(0.0)

    private val longitudeState =
        mutableStateOf(0.0)

    /*
     * Android Location.speed = metres/second.
     *
     * This value is kept internally as m/s.
     *
     * It is converted to km/h immediately before ML inference.
     */
    private val speedState =
        mutableFloatStateOf(0f)

    private val gpsAvailableState =
        mutableStateOf(false)

    // ========================================================================
    // AI UI STATE
    // ========================================================================

    private val predictionLabelState =
        mutableStateOf("WAITING")

    private val crashProbabilityState =
        mutableFloatStateOf(0f)

    private val crashConfirmedState =
        mutableStateOf(false)

    private val crashReasonState =
        mutableStateOf("System initializing - monitoring telemetry...")

    private val isProtectionEnabledState =
        mutableStateOf(true)

    // ========================================================================
    // PROFILE
    // ========================================================================

    private val profileState =
        mutableStateOf(PersonalProfile())

    private val showProfileDialogState =
        mutableStateOf(false)

    // ========================================================================
    // WEATHER STATE
    // ========================================================================

    private val weatherState =
        mutableStateOf(WeatherState())

    // ========================================================================
    // LOCATION LISTENER
    // ========================================================================

    private val locationListener =
        object : LocationListener {

            override fun onLocationChanged(
                location: Location
            ) {

                updateLocation(location)

                Log.d(
                    TAG,
                    "GPS UPDATE: " +
                            "${location.latitude}, " +
                            "${location.longitude}, " +
                            "speed=${location.speed} m/s"
                )
            }

            override fun onProviderEnabled(
                provider: String
            ) {

                Log.d(
                    TAG,
                    "Location provider enabled: $provider"
                )
            }

            override fun onProviderDisabled(
                provider: String
            ) {

                Log.w(
                    TAG,
                    "Location provider disabled: $provider"
                )
            }
        }

    // ========================================================================
    // LOCATION PERMISSION
    // ========================================================================

    private val locationPermissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { permissions ->

            val fineGranted =
                permissions[
                    Manifest.permission.ACCESS_FINE_LOCATION
                ] == true

            val coarseGranted =
                permissions[
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ] == true

            if (fineGranted || coarseGranted) {

                Log.i(
                    TAG,
                    "Location permission granted. " +
                            "fine=$fineGranted " +
                            "coarse=$coarseGranted"
                )

                startLocationUpdates()

            } else {

                Log.w(
                    TAG,
                    "Location permission denied"
                )

                gpsAvailableState.value =
                    false
            }
        }

    // ========================================================================
    // ON CREATE
    // ========================================================================

    override fun onCreate(
        savedInstanceState: Bundle?
    ) {

        super.onCreate(savedInstanceState)

        Log.i(
            TAG,
            "========================================"
        )

        Log.i(
            TAG,
            "SVM-AEGIS starting"
        )

        Log.i(
            TAG,
            "========================================"
        )

        sensorManager =
            getSystemService(
                Context.SENSOR_SERVICE
            ) as SensorManager

        locationManager =
            getSystemService(
                Context.LOCATION_SERVICE
            ) as LocationManager

        weatherManager =
            WeatherManager(this)

        // --------------------------------------------------------------------
        // INITIALIZE CRASH DETECTOR
        // --------------------------------------------------------------------

        try {

            crashDetector =
                CrashDetector(this)

            Log.i(
                TAG,
                "Crash detector initialized successfully"
            )

        } catch (exception: Exception) {

            Log.e(
                TAG,
                "FAILED TO INITIALIZE CRASH DETECTOR",
                exception
            )
        }

        // --------------------------------------------------------------------
        // PROFILE
        // --------------------------------------------------------------------

        loadProfile()

        initializeEmergencyController()

        // --------------------------------------------------------------------
        // UI
        // --------------------------------------------------------------------

        setContent {

            SensorScreen(

                ax = accelerometerXState.value,
                ay = accelerometerYState.value,
                az = accelerometerZState.value,

                gx = gyroscopeXState.value,
                gy = gyroscopeYState.value,
                gz = gyroscopeZState.value,

                latitude = latitudeState.value,
                longitude = longitudeState.value,
                speed = speedState.value,

                predictionLabel =
                    predictionLabelState.value,

                crashProbability =
                    crashProbabilityState.value,

                crashConfirmed =
                    crashConfirmedState.value,

                crashReason =
                    crashReasonState.value,

                weather =
                    weatherState.value,

                profile =
                    profileState.value,

                showProfileDialog =
                    showProfileDialogState.value,

                onProfileDialogDismiss = {

                    showProfileDialogState.value =
                        false
                },

                onSaveProfile = { newProfile ->

                    profileState.value =
                        newProfile

                    saveProfile(newProfile)

                    initializeEmergencyController()

                    showProfileDialogState.value =
                        false
                },

                onOpenSettings = {

                    showProfileDialogState.value =
                        true
                },

                onTestCrash = {

                    runCrashTest()
                },

                onCancelCrash = {

                    cancelCrash()
                },

                onReset = {

                    resetSystem()
                }
            )
        }

        // --------------------------------------------------------------------
        // START SYSTEMS
        // --------------------------------------------------------------------

        startSensors()

        requestLocationPermission()
    }

    // ========================================================================
    // SOFTWARE CRASH TEST
    // ========================================================================

    private fun runCrashTest() {

        Log.i(
            TAG,
            "========================================"
        )

        Log.i(
            TAG,
            "STARTING SOFTWARE CRASH TEST"
        )

        Log.i(
            TAG,
            "========================================"
        )

        if (!::crashDetector.isInitialized) {

            Log.e(
                TAG,
                "Crash detector is not initialized"
            )

            return
        }

        try {

            val result =
                crashDetector.simulateCrash()

            crashProbabilityState.value =
                result.ensemblePrediction
                    .ensembleCrashProbability
                    .coerceIn(0f, 1f)

            predictionLabelState.value =
                "CRASH"

            crashConfirmedState.value =
                result.crashConfirmed

            crashReasonState.value =
                result.reason

            Log.w(
                TAG,
                "SOFTWARE TEST RESULT: " +
                        "probability=" +
                        crashProbabilityState.value +
                        ", confirmed=" +
                        result.crashConfirmed
            )

        } catch (exception: Exception) {

            Log.e(
                TAG,
                "Software crash test failed",
                exception
            )
        }
    }

    // ========================================================================
    // CANCEL CRASH
    // ========================================================================

    private fun cancelCrash() {

        Log.i(
            TAG,
            "Crash alert cancelled by user"
        )

        emergencyController?.cancelEmergency()

        crashConfirmedState.value =
            false

        predictionLabelState.value =
            "NORMAL"

        crashProbabilityState.value =
            0f

        crashReasonState.value =
            "System normal - stable riding conditions"

        resetAdvancedFeatureHistory()

        if (::crashDetector.isInitialized) {

            try {

                crashDetector.reset()

            } catch (exception: Exception) {

                Log.e(
                    TAG,
                    "Failed to reset detector",
                    exception
                )
            }
        }
    }

    // ========================================================================
    // RESET SYSTEM
    // ========================================================================

    private fun resetSystem() {

        Log.i(
            TAG,
            "SVM-AEGIS system reset"
        )

        emergencyController?.cancelEmergency()

        crashConfirmedState.value =
            false

        predictionLabelState.value =
            "WAITING"

        crashProbabilityState.value =
            0f

        crashReasonState.value =
            "System reset - waiting for sensor telemetry..."

        hasAccelerometerSample =
            false

        hasGyroscopeSample =
            false

        lastAccelerometerTimestampMs =
            0L

        lastGyroscopeTimestampMs =
            0L

        lastInferenceTimeMs =
            0L

        resetAdvancedFeatureHistory()

        if (::crashDetector.isInitialized) {

            try {

                crashDetector.reset()

            } catch (exception: Exception) {

                Log.e(
                    TAG,
                    "Detector reset failed",
                    exception
                )
            }
        }
    }

    // ========================================================================
    // RESET ADVANCED FEATURE HISTORY
    // ========================================================================

    private fun resetAdvancedFeatureHistory() {

        previousAccelerationMagnitude =
            0f

        previousGyroMagnitude =
            0f

        previousSpeedKmh =
            0f

        previousTiltAngle =
            0f

        previousFeatureTimestampMs =
            0L

        hasPreviousAdvancedFeatures =
            false
    }

    // ========================================================================
    // START PHONE SENSORS
    // ========================================================================

    private fun startSensors() {

        if (sensorListenersRegistered) {
            return
        }

        val accelerometer =
            sensorManager.getDefaultSensor(
                Sensor.TYPE_ACCELEROMETER
            )

        val gyroscope =
            sensorManager.getDefaultSensor(
                Sensor.TYPE_GYROSCOPE
            )

        var anySensorRegistered =
            false

        // --------------------------------------------------------------------
        // ACCELEROMETER
        // --------------------------------------------------------------------

        if (accelerometer != null) {

            accelerometerAvailable =
                true

            val registered =
                sensorManager.registerListener(
                    this,
                    accelerometer,
                    SENSOR_DELAY
                )

            Log.i(
                TAG,
                "Accelerometer registered: $registered"
            )

            if (registered) {
                anySensorRegistered =
                    true
            }

        } else {

            accelerometerAvailable =
                false

            Log.e(
                TAG,
                "Accelerometer unavailable"
            )
        }

        // --------------------------------------------------------------------
        // GYROSCOPE
        // --------------------------------------------------------------------

        if (gyroscope != null) {

            gyroscopeAvailable =
                true

            val registered =
                sensorManager.registerListener(
                    this,
                    gyroscope,
                    SENSOR_DELAY
                )

            Log.i(
                TAG,
                "Gyroscope registered: $registered"
            )

            if (registered) {
                anySensorRegistered =
                    true
            }

        } else {

            gyroscopeAvailable =
                false

            Log.e(
                TAG,
                "Gyroscope unavailable"
            )
        }

        sensorListenersRegistered =
            anySensorRegistered

        if (
            accelerometerAvailable &&
            gyroscopeAvailable &&
            sensorListenersRegistered
        ) {

            Log.i(
                TAG,
                "PHONE IMU READY"
            )

        } else {

            Log.w(
                TAG,
                "PHONE IMU NOT FULLY READY"
            )
        }
    }

    // ========================================================================
    // STOP PHONE SENSORS
    // ========================================================================

    private fun stopSensors() {

        if (!sensorListenersRegistered) {
            return
        }

        sensorManager.unregisterListener(this)

        sensorListenersRegistered =
            false

        hasAccelerometerSample =
            false

        hasGyroscopeSample =
            false

        Log.i(
            TAG,
            "Phone sensors stopped"
        )
    }

    // ========================================================================
    // SENSOR DATA
    // ========================================================================

    override fun onSensorChanged(
        event: SensorEvent
    ) {

        val now =
            System.currentTimeMillis()

        when (event.sensor.type) {

            Sensor.TYPE_ACCELEROMETER -> {

                if (event.values.size >= 3) {

                    accelerometerXState.value =
                        event.values[0]

                    accelerometerYState.value =
                        event.values[1]

                    accelerometerZState.value =
                        event.values[2]

                    hasAccelerometerSample =
                        true

                    lastAccelerometerTimestampMs =
                        now
                }
            }

            Sensor.TYPE_GYROSCOPE -> {

                if (event.values.size >= 3) {

                    gyroscopeXState.value =
                        event.values[0]

                    gyroscopeYState.value =
                        event.values[1]

                    gyroscopeZState.value =
                        event.values[2]

                    hasGyroscopeSample =
                        true

                    lastGyroscopeTimestampMs =
                        now
                }
            }
        }

        tryRunCrashDetection(now)
    }

    // ========================================================================
    // SYNCHRONIZED SENSOR -> AI PIPELINE
    // ========================================================================

    private fun tryRunCrashDetection(
        now: Long
    ) {

        if (crashConfirmedState.value) {
            return
        }

        if (!::crashDetector.isInitialized) {
            return
        }

        if (
            !hasAccelerometerSample ||
            !hasGyroscopeSample
        ) {
            return
        }

        val accelerometerAge =
            now -
                    lastAccelerometerTimestampMs

        val gyroscopeAge =
            now -
                    lastGyroscopeTimestampMs

        if (
            accelerometerAge >
            SENSOR_PAIR_MAX_AGE_MS
        ) {
            return
        }

        if (
            gyroscopeAge >
            SENSOR_PAIR_MAX_AGE_MS
        ) {
            return
        }

        if (
            now -
            lastInferenceTimeMs <
            INFERENCE_INTERVAL_MS
        ) {
            return
        }

        lastInferenceTimeMs =
            now

        processCrashDetection()
    }

    // ========================================================================
    // BUILD ADVANCED FEATURES
    // ========================================================================

    private fun buildAdvancedFeatures(
        ax: Float,
        ay: Float,
        az: Float,
        gx: Float,
        gy: Float,
        gz: Float,
        speedKmh: Float,
        timestampMs: Long
    ): AdvancedFeatures {

        // --------------------------------------------------------------------
        // ACCELERATION MAGNITUDE
        // --------------------------------------------------------------------

        val accelerationMagnitude =
            sqrt(
                ax * ax +
                        ay * ay +
                        az * az
            )

        // --------------------------------------------------------------------
        // GYROSCOPE MAGNITUDE
        // --------------------------------------------------------------------

        val gyroMagnitude =
            sqrt(
                gx * gx +
                        gy * gy +
                        gz * gz
            )

        // --------------------------------------------------------------------
        // TILT
        // --------------------------------------------------------------------

        val tiltAngle =
            Math.toDegrees(
                atan2(
                    sqrt(
                        ax * ax +
                                ay * ay
                    ).toDouble(),
                    az.toDouble()
                )
            ).toFloat()

        // --------------------------------------------------------------------
        // FIRST SAMPLE
        // --------------------------------------------------------------------

        if (!hasPreviousAdvancedFeatures) {

            previousAccelerationMagnitude =
                accelerationMagnitude

            previousGyroMagnitude =
                gyroMagnitude

            previousSpeedKmh =
                speedKmh

            previousTiltAngle =
                tiltAngle

            previousFeatureTimestampMs =
                timestampMs

            hasPreviousAdvancedFeatures =
                true

            return AdvancedFeatures(

                accelerationMagnitude =
                    accelerationMagnitude,

                gyroMagnitude =
                    gyroMagnitude,

                accelerationChange =
                    0f,

                gyroChange =
                    0f,

                jerk =
                    0f,

                speedChange =
                    0f,

                tiltAngle =
                    tiltAngle,

                orientationChange =
                    0f,

                vibration =
                    0f,

                pulseRate =
                    null,

                pulseChange =
                    null,

                sensorConfidence =
                    1.0f
            )
        }

        // --------------------------------------------------------------------
        // DELTA TIME
        // --------------------------------------------------------------------

        val deltaTimeSeconds =
            (
                    timestampMs -
                            previousFeatureTimestampMs
                    )
                .coerceAtLeast(1L) /
                    1000f

        // --------------------------------------------------------------------
        // ACCELERATION CHANGE
        // --------------------------------------------------------------------

        val accelerationChange =
            abs(
                accelerationMagnitude -
                        previousAccelerationMagnitude
            )

        // --------------------------------------------------------------------
        // GYRO CHANGE
        // --------------------------------------------------------------------

        val gyroChange =
            abs(
                gyroMagnitude -
                        previousGyroMagnitude
            )

        // --------------------------------------------------------------------
        // SPEED CHANGE
        // --------------------------------------------------------------------

        val speedChange =
            abs(
                speedKmh -
                        previousSpeedKmh
            )

        // --------------------------------------------------------------------
        // ORIENTATION CHANGE
        // --------------------------------------------------------------------

        val orientationChange =
            abs(
                tiltAngle -
                        previousTiltAngle
            )

        // --------------------------------------------------------------------
        // JERK
        // --------------------------------------------------------------------

        val jerk =
            accelerationChange /
                    deltaTimeSeconds

        // --------------------------------------------------------------------
        // VIBRATION
        // --------------------------------------------------------------------

        val vibration =
            accelerationChange

        // --------------------------------------------------------------------
        // CREATE FEATURES
        // --------------------------------------------------------------------

        val features =
            AdvancedFeatures(

                accelerationMagnitude =
                    accelerationMagnitude,

                gyroMagnitude =
                    gyroMagnitude,

                accelerationChange =
                    accelerationChange,

                gyroChange =
                    gyroChange,

                jerk =
                    jerk,

                speedChange =
                    speedChange,

                tiltAngle =
                    tiltAngle,

                orientationChange =
                    orientationChange,

                vibration =
                    vibration,

                pulseRate =
                    null,

                pulseChange =
                    null,

                sensorConfidence =
                    1.0f
            )

        // --------------------------------------------------------------------
        // SAVE FOR NEXT SAMPLE
        // --------------------------------------------------------------------

        previousAccelerationMagnitude =
            accelerationMagnitude

        previousGyroMagnitude =
            gyroMagnitude

        previousSpeedKmh =
            speedKmh

        previousTiltAngle =
            tiltAngle

        previousFeatureTimestampMs =
            timestampMs

        return features
    }

    // ========================================================================
    // MAIN AI PIPELINE
    // ========================================================================

    private fun processCrashDetection() {

        if (crashConfirmedState.value) {
            return
        }

        if (!::crashDetector.isInitialized) {
            return
        }

        try {

            // ----------------------------------------------------------------
            // SPEED CONVERSION
            // ----------------------------------------------------------------

            val speedKmh =
                (
                        speedState.value *
                                3.6f
                        )
                    .coerceAtLeast(0f)

            // ----------------------------------------------------------------
            // SENSOR VALUES
            // ----------------------------------------------------------------

            val ax =
                accelerometerXState.value

            val ay =
                accelerometerYState.value

            val az =
                accelerometerZState.value

            val gx =
                gyroscopeXState.value

            val gy =
                gyroscopeYState.value

            val gz =
                gyroscopeZState.value

            val timestamp =
                System.currentTimeMillis()

            // ----------------------------------------------------------------
            // BUILD ADVANCED FEATURES
            // ----------------------------------------------------------------

            val advancedFeatures =
                buildAdvancedFeatures(

                    ax = ax,
                    ay = ay,
                    az = az,

                    gx = gx,
                    gy = gy,
                    gz = gz,

                    speedKmh = speedKmh,

                    timestampMs = timestamp
                )

            // ----------------------------------------------------------------
            // DEBUG ADVANCED FEATURES
            // ----------------------------------------------------------------

            Log.d(
                TAG,
                "ADVANCED FEATURES: " +
                        "accMag=${"%.2f".format(
                            advancedFeatures
                                .accelerationMagnitude
                        )}, " +

                        "accChange=${"%.2f".format(
                            advancedFeatures
                                .accelerationChange
                        )}, " +

                        "gyroMag=${"%.2f".format(
                            advancedFeatures
                                .gyroMagnitude
                        )}, " +

                        "gyroChange=${"%.2f".format(
                            advancedFeatures
                                .gyroChange
                        )}, " +

                        "jerk=${"%.2f".format(
                            advancedFeatures
                                .jerk
                        )}, " +

                        "orientation=${"%.2f".format(
                            advancedFeatures
                                .orientationChange
                        )}, " +

                        "speedChange=${"%.2f".format(
                            advancedFeatures
                                .speedChange
                        )}, " +

                        "vibration=${"%.2f".format(
                            advancedFeatures
                                .vibration
                        )}"
            )

            // ----------------------------------------------------------------
            // CREATE SENSOR FRAME
            // ----------------------------------------------------------------

            val sensorFrame =
                SensorFrame(

                    timestampMillis =
                        timestamp,

                    accX = ax,
                    accY = ay,
                    accZ = az,

                    gyroX = gx,
                    gyroY = gy,
                    gyroZ = gz,

                    speedKmh =
                        speedKmh,

                    latitude =
                        latitudeState.value,

                    longitude =
                        longitudeState.value,

                    source =
                        SensorSource.PHONE
                )

            // ----------------------------------------------------------------
            // SEND FRAME TO EMERGENCY SYSTEM
            // ----------------------------------------------------------------

            emergencyController
                ?.updateSensorFrame(
                    sensorFrame
                )

            // ----------------------------------------------------------------
            // RUN ML + TEMPORAL DETECTION
            // ----------------------------------------------------------------

            val result =
                crashDetector
                    .detectCrashWithTemporal(

                        accX = ax,
                        accY = ay,
                        accZ = az,

                        gyroX = gx,
                        gyroY = gy,
                        gyroZ = gz,

                        speedKmh =
                            speedKmh,

                        advancedFeatures =
                            advancedFeatures
                    )

            // ----------------------------------------------------------------
            // ENSEMBLE PROBABILITY
            // ----------------------------------------------------------------

            val probability =
                result
                    .ensemblePrediction
                    .ensembleCrashProbability
                    .coerceIn(0f, 1f)

            crashProbabilityState.value =
                probability

            crashReasonState.value =
                result.reason

            // ----------------------------------------------------------------
            // TEMPORAL STATUS
            // ----------------------------------------------------------------

            when (result.status) {

                TemporalStatus.NORMAL -> {

                    predictionLabelState.value =
                        if (probability >= 0.5f) {
                            "AI HIGH"
                        } else {
                            "NORMAL"
                        }
                }

                TemporalStatus.POSSIBLE_IMPACT -> {

                    predictionLabelState.value =
                        "POSSIBLE IMPACT"
                }

                TemporalStatus.SETTLING -> {

                    predictionLabelState.value =
                        "SETTLING"
                }

                TemporalStatus.IMMOBILITY_CHECK -> {

                    predictionLabelState.value =
                        "IMMOBILITY CHECK"
                }

                TemporalStatus.CRASH_CONFIRMED -> {

                    predictionLabelState.value =
                        "CRASH"
                }
            }

            // ----------------------------------------------------------------
            // CRASH CONFIRMED
            // ----------------------------------------------------------------

            if (result.crashConfirmed) {

                crashConfirmedState.value =
                    true

                predictionLabelState.value =
                    "CRASH"

                emergencyController
                    ?.triggerCrashAlert(
                        result
                    )

                Log.w(
                    TAG,
                    "========================================"
                )

                Log.w(
                    TAG,
                    "CRASH CONFIRMED"
                )

                Log.w(
                    TAG,
                    "Probability = $probability"
                )

                Log.w(
                    TAG,
                    "Temporal status = ${result.status}"
                )

                Log.w(
                    TAG,
                    "Acceleration change = " +
                            advancedFeatures
                                .accelerationChange
                )

                Log.w(
                    TAG,
                    "Gyro change = " +
                            advancedFeatures
                                .gyroChange
                )

                Log.w(
                    TAG,
                    "Jerk = " +
                            advancedFeatures
                                .jerk
                )

                Log.w(
                    TAG,
                    "Orientation change = " +
                            advancedFeatures
                                .orientationChange
                )

                Log.w(
                    TAG,
                    "SVM = " +
                            result
                                .ensemblePrediction
                                .svmProbability
                )

                Log.w(
                    TAG,
                    "RF = " +
                            result
                                .ensemblePrediction
                                .randomForestProbability
                )

                Log.w(
                    TAG,
                    "XGB = " +
                            result
                                .ensemblePrediction
                                .xgBoostProbability
                )

                Log.w(
                    TAG,
                    "========================================"
                )

            } else {

                // ------------------------------------------------------------
                // LIVE AI LOG
                // ------------------------------------------------------------

                Log.d(
                    TAG,
                    "AI LIVE: " +

                            "P=${"%.3f".format(
                                probability
                            )} " +

                            "status=${result.status} " +

                            "A=($ax,$ay,$az) " +

                            "G=($gx,$gy,$gz) " +

                            "speed=${"%.2f".format(
                                speedKmh
                            )}"
                )
            }

        } catch (exception: Exception) {

            Log.e(
                TAG,
                "CRASH DETECTION ERROR",
                exception
            )

            predictionLabelState.value =
                "AI ERROR"
        }
    }

    // ========================================================================
    // SENSOR ACCURACY
    // ========================================================================

    override fun onAccuracyChanged(
        sensor: Sensor?,
        accuracy: Int
    ) {

        Log.d(
            TAG,
            "Sensor accuracy changed: " +
                    "${sensor?.name} -> $accuracy"
        )
    }

    // ========================================================================
    // LOCATION PERMISSION REQUEST
    // ========================================================================

    private fun requestLocationPermission() {

        if (hasLocationPermission()) {

            startLocationUpdates()

        } else {

            locationPermissionLauncher.launch(

                arrayOf(

                    Manifest.permission
                        .ACCESS_FINE_LOCATION,

                    Manifest.permission
                        .ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    // ========================================================================
    // LOCATION UPDATES
    // ========================================================================

    private fun startLocationUpdates() {

        /*
         * Direct permission checks are intentionally kept here
         * so Android Studio lint can verify the protected
         * LocationManager calls.
         */

        val fineLocationGranted =
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission
                    .ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED

        val coarseLocationGranted =
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission
                    .ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED

        if (
            !fineLocationGranted &&
            !coarseLocationGranted
        ) {

            Log.w(
                TAG,
                "Cannot start location updates: " +
                        "permission missing"
            )

            gpsAvailableState.value =
                false

            return
        }

        // --------------------------------------------------------------------
        // LAST KNOWN GPS LOCATION
        // --------------------------------------------------------------------

        if (fineLocationGranted) {

            try {

                val gpsLocation =
                    locationManager
                        .getLastKnownLocation(
                            LocationManager
                                .GPS_PROVIDER
                        )

                if (gpsLocation != null) {

                    updateLocation(
                        gpsLocation
                    )
                }

            } catch (
                exception: SecurityException
            ) {

                Log.e(
                    TAG,
                    "Unable to access last known GPS location",
                    exception
                )
            }
        }

        // --------------------------------------------------------------------
        // LAST KNOWN NETWORK LOCATION
        // --------------------------------------------------------------------

        if (
            coarseLocationGranted ||
            fineLocationGranted
        ) {

            try {

                val networkLocation =
                    locationManager
                        .getLastKnownLocation(
                            LocationManager
                                .NETWORK_PROVIDER
                        )

                if (
                    networkLocation != null &&
                    !gpsAvailableState.value
                ) {

                    updateLocation(
                        networkLocation
                    )
                }

            } catch (
                exception: SecurityException
            ) {

                Log.e(
                    TAG,
                    "Unable to access last known network location",
                    exception
                )
            }
        }

        // --------------------------------------------------------------------
        // GPS UPDATES
        // --------------------------------------------------------------------

        if (fineLocationGranted) {

            try {

                locationManager
                    .requestLocationUpdates(

                        LocationManager
                            .GPS_PROVIDER,

                        LOCATION_INTERVAL,

                        LOCATION_DISTANCE,

                        locationListener
                    )

                Log.i(
                    TAG,
                    "GPS location updates started"
                )

            } catch (
                exception: SecurityException
            ) {

                Log.e(
                    TAG,
                    "GPS permission was revoked",
                    exception
                )

            } catch (
                exception: Exception
            ) {

                Log.e(
                    TAG,
                    "GPS location update failed",
                    exception
                )
            }
        }

        // --------------------------------------------------------------------
        // NETWORK UPDATES
        // --------------------------------------------------------------------

        if (
            coarseLocationGranted ||
            fineLocationGranted
        ) {

            try {

                locationManager
                    .requestLocationUpdates(

                        LocationManager
                            .NETWORK_PROVIDER,

                        LOCATION_INTERVAL,

                        LOCATION_DISTANCE,

                        locationListener
                    )

                Log.i(
                    TAG,
                    "Network location updates started"
                )

            } catch (
                exception: SecurityException
            ) {

                Log.e(
                    TAG,
                    "Network location permission was revoked",
                    exception
                )

            } catch (
                exception: Exception
            ) {

                Log.e(
                    TAG,
                    "Network location update failed",
                    exception
                )
            }
        }
    }

    // ========================================================================
    // UPDATE LOCATION
    // ========================================================================

    private fun updateLocation(
        location: Location
    ) {

        latitudeState.value =
            location.latitude

        longitudeState.value =
            location.longitude

        speedState.value =
            if (location.hasSpeed()) {

                location.speed
                    .coerceAtLeast(0f)

            } else {

                0f
            }

        gpsAvailableState.value =
            true

        updateWeather(
            latitude =
                location.latitude,

            longitude =
                location.longitude
        )
    }

    // ========================================================================
    // WEATHER
    // ========================================================================

    private fun updateWeather(
        latitude: Double,
        longitude: Double,
        force: Boolean = false
    ) {

        if (
            latitude == 0.0 &&
            longitude == 0.0
        ) {
            return
        }

        val now =
            System.currentTimeMillis()

        val timeSinceLastUpdate =
            now -
                    lastWeatherUpdateTime

        var movedEnough =
            true

        if (
            !lastWeatherLatitude.isNaN() &&
            !lastWeatherLongitude.isNaN()
        ) {

            val distance =
                calculateDistanceKm(

                    lastWeatherLatitude,
                    lastWeatherLongitude,

                    latitude,
                    longitude
                )

            movedEnough =
                distance >=
                        WEATHER_MIN_DISTANCE_KM
        }

        if (!force) {

            if (
                timeSinceLastUpdate <
                WEATHER_REFRESH_INTERVAL &&
                !movedEnough
            ) {
                return
            }
        }

        weatherJob?.cancel()

        lastWeatherLatitude =
            latitude

        lastWeatherLongitude =
            longitude

        lastWeatherUpdateTime =
            now

        weatherJob =
            lifecycleScope.launch {

                try {

                    val result =
                        weatherManager.getWeather(
                            latitude,
                            longitude
                        )

                    if (result != null) {

                        weatherState.value =
                            result

                        Log.i(
                            TAG,
                            "Weather updated: " +
                                    "${result.city}, " +
                                    "${result.temperature}°C"
                        )
                    }

                } catch (exception: Exception) {

                    Log.e(
                        TAG,
                        "Weather update failed",
                        exception
                    )
                }
            }
    }

    // ========================================================================
    // DISTANCE
    // ========================================================================

    private fun calculateDistanceKm(
        lat1: Double,
        lon1: Double,
        lat2: Double,
        lon2: Double
    ): Double {

        val results =
            FloatArray(1)

        Location.distanceBetween(

            lat1,
            lon1,

            lat2,
            lon2,

            results
        )

        return results[0] / 1000.0
    }

    // ========================================================================
    // LOCATION PERMISSION CHECK
    // ========================================================================

    private fun hasLocationPermission(): Boolean {

        val fineGranted =
            ContextCompat.checkSelfPermission(

                this,

                Manifest.permission
                    .ACCESS_FINE_LOCATION

            ) == PackageManager.PERMISSION_GRANTED

        val coarseGranted =
            ContextCompat.checkSelfPermission(

                this,

                Manifest.permission
                    .ACCESS_COARSE_LOCATION

            ) == PackageManager.PERMISSION_GRANTED

        return fineGranted ||
                coarseGranted
    }

    // ========================================================================
    // EMERGENCY CONTROLLER
    // ========================================================================

    private fun initializeEmergencyController() {

        emergencyController?.release()

        val phoneNumber =
            profileState.value
                .emergencyPhone
                .trim()

        emergencyController =
            EmergencyController(

                context = this,

                emergencyPhoneNumber =
                    phoneNumber
            )

        Log.i(

            TAG,

            if (phoneNumber.isBlank()) {

                "Emergency controller initialized " +
                        "without emergency contact"

            } else {

                "Emergency controller initialized"
            }
        )
    }

    // ========================================================================
    // PROFILE STORAGE
    // ========================================================================

    private fun saveProfile(
        newProfile: PersonalProfile
    ) {

        try {

            getSharedPreferences(

                PROFILE_PREF,

                Context.MODE_PRIVATE

            )
                .edit()

                .putString(
                    "name",
                    newProfile.name
                )

                .putString(
                    "phone",
                    newProfile.phone
                )

                .putString(
                    "bloodGroup",
                    newProfile.bloodGroup
                )

                .putString(
                    "emergencyName",
                    newProfile.emergencyName
                )

                .putString(
                    "emergencyPhone",
                    newProfile.emergencyPhone
                )

                .putString(
                    "address",
                    newProfile.address
                )

                .apply()

        } catch (exception: Exception) {

            Log.e(
                TAG,
                "Failed to save profile",
                exception
            )
        }
    }

    private fun loadProfile() {

        try {

            val preferences =
                getSharedPreferences(

                    PROFILE_PREF,

                    Context.MODE_PRIVATE
                )

            profileState.value =
                PersonalProfile(

                    name =
                        preferences.getString(
                            "name",
                            ""
                        ) ?: "",

                    phone =
                        preferences.getString(
                            "phone",
                            ""
                        ) ?: "",

                    bloodGroup =
                        preferences.getString(
                            "bloodGroup",
                            ""
                        ) ?: "",

                    emergencyName =
                        preferences.getString(
                            "emergencyName",
                            ""
                        ) ?: "",

                    emergencyPhone =
                        preferences.getString(
                            "emergencyPhone",
                            ""
                        ) ?: "",

                    address =
                        preferences.getString(
                            "address",
                            ""
                        ) ?: ""
                )

        } catch (exception: Exception) {

            Log.e(
                TAG,
                "Failed to load profile",
                exception
            )
        }
    }

    // ========================================================================
    // RESUME
    // ========================================================================

    override fun onResume() {

        super.onResume()

        startSensors()

        if (hasLocationPermission()) {

            startLocationUpdates()

            if (
                latitudeState.value != 0.0 ||
                longitudeState.value != 0.0
            ) {

                updateWeather(

                    latitudeState.value,

                    longitudeState.value,

                    force = true
                )
            }
        }
    }

    // ========================================================================
    // PAUSE
    // ========================================================================

    override fun onPause() {

        stopSensors()

        if (hasLocationPermission()) {

            try {

                locationManager
                    .removeUpdates(
                        locationListener
                    )

            } catch (
                exception: SecurityException
            ) {

                Log.w(
                    TAG,
                    "Location permission revoked while " +
                            "stopping updates",
                    exception
                )

            } catch (
                exception: Exception
            ) {

                Log.e(
                    TAG,
                    "Failed to stop location updates",
                    exception
                )
            }
        }

        super.onPause()
    }

    // ========================================================================
    // DESTROY
    // ========================================================================

    override fun onDestroy() {

        stopSensors()

        weatherJob?.cancel()

        if (hasLocationPermission()) {

            try {

                locationManager
                    .removeUpdates(
                        locationListener
                    )

            } catch (
                exception: SecurityException
            ) {

                Log.w(
                    TAG,
                    "Location permission revoked during destroy",
                    exception
                )

            } catch (
                exception: Exception
            ) {

                Log.e(
                    TAG,
                    "Failed to remove location updates",
                    exception
                )
            }
        }

        try {

            emergencyController?.release()

            emergencyController =
                null

        } catch (exception: Exception) {

            Log.e(
                TAG,
                "Failed to release emergency controller",
                exception
            )
        }

        try {

            if (::crashDetector.isInitialized) {

                crashDetector.close()
            }

        } catch (exception: Exception) {

            Log.e(
                TAG,
                "Failed to close crash detector",
                exception
            )
        }

        super.onDestroy()
    }
}