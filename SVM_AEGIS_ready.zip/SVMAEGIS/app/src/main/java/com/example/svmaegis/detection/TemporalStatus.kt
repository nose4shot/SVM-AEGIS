package com.example.svmaegis.detection

enum class TemporalStatus {
    NORMAL,
    POSSIBLE_IMPACT,
    SETTLING,
    IMMOBILITY_CHECK,
    CRASH_CONFIRMED
}

data class TemporalResult(
    val crashConfirmed: Boolean,
    val status: TemporalStatus
)