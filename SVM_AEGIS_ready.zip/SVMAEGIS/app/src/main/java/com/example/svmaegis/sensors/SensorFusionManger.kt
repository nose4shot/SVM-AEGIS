package com.example.svmaegis.sensors

import com.example.svmaegis.bluetooth.ExternalSensorPacket
import com.example.svmaegis.data.SensorFrame
import com.example.svmaegis.data.SensorSource

class SensorFusionManager(
    private val onFusedFrame: (SensorFrame) -> Unit,
    private val externalTimeoutMillis: Long = 2_000L
) {

    private var latestPhone: SensorFrame? = null
    private var latestExternal: ExternalSensorPacket? = null

    private var externalConnected = false

    fun setExternalConnected(
        connected: Boolean
    ) {

        externalConnected = connected

        if (!connected) {
            latestExternal = null
        }
    }

    fun updatePhone(
        frame: SensorFrame
    ) {

        latestPhone = frame

        emitFusedFrame()
    }

    fun updateExternal(
        packet: ExternalSensorPacket
    ) {

        latestExternal = packet
        externalConnected = true

        emitFusedFrame()
    }

    fun clearExternal() {

        latestExternal = null
        externalConnected = false

        emitFusedFrame()
    }

    fun externalIsFresh(
        nowMillis: Long = System.currentTimeMillis()
    ): Boolean {

        val packet = latestExternal
            ?: return false

        return externalConnected &&
                nowMillis - packet.timestampMillis <= externalTimeoutMillis
    }

    fun latestPhoneFrame(): SensorFrame? {
        return latestPhone
    }

    fun latestExternalPacket(): ExternalSensorPacket? {
        return latestExternal
    }

    fun isExternalConnected(): Boolean {
        return externalConnected
    }

    private fun emitFusedFrame() {

        val phone = latestPhone
        val external = latestExternal

        val externalFresh =
            externalIsFresh()

        if (phone == null && !externalFresh) {
            return
        }

        val externalImuAvailable =
            externalFresh &&
                    (
                            external?.hasAccelerometer == true ||
                                    external?.hasGyroscope == true
                            )

        val externalGpsAvailable =
            externalFresh &&
                    external?.hasGps == true

        val accX =
            if (
                externalImuAvailable &&
                external?.hasAccelerometer == true &&
                external.accX != null
            ) {
                external.accX
            } else {
                phone?.accX ?: 0f
            }

        val accY =
            if (
                externalImuAvailable &&
                external?.hasAccelerometer == true &&
                external.accY != null
            ) {
                external.accY
            } else {
                phone?.accY ?: 0f
            }

        val accZ =
            if (
                externalImuAvailable &&
                external?.hasAccelerometer == true &&
                external.accZ != null
            ) {
                external.accZ
            } else {
                phone?.accZ ?: 0f
            }

        val gyroX =
            if (
                externalImuAvailable &&
                external?.hasGyroscope == true &&
                external.gyroX != null
            ) {
                external.gyroX
            } else {
                phone?.gyroX ?: 0f
            }

        val gyroY =
            if (
                externalImuAvailable &&
                external?.hasGyroscope == true &&
                external.gyroY != null
            ) {
                external.gyroY
            } else {
                phone?.gyroY ?: 0f
            }

        val gyroZ =
            if (
                externalImuAvailable &&
                external?.hasGyroscope == true &&
                external.gyroZ != null
            ) {
                external.gyroZ
            } else {
                phone?.gyroZ ?: 0f
            }

        val latitude =
            if (
                externalGpsAvailable &&
                external?.latitude != null &&
                external.latitude.isFinite()
            ) {
                external.latitude
            } else {
                phone?.latitude ?: 0.0
            }

        val longitude =
            if (
                externalGpsAvailable &&
                external?.longitude != null &&
                external.longitude.isFinite()
            ) {
                external.longitude
            } else {
                phone?.longitude ?: 0.0
            }

        val speed =
            if (
                externalFresh &&
                external?.speedKmh != null &&
                external.speedKmh.isFinite() &&
                external.speedKmh >= 0f
            ) {
                external.speedKmh
            } else {
                phone?.speedKmh ?: 0f
            }

        val vibration =
            if (
                externalFresh &&
                external?.vibration != null &&
                external.vibration.isFinite()
            ) {
                external.vibration
            } else {
                null
            }

        val temperature =
            if (
                externalFresh &&
                external?.temperatureCelsius != null &&
                external.temperatureCelsius.isFinite()
            ) {
                external.temperatureCelsius
            } else {
                null
            }

        val source =
            when {
                externalImuAvailable &&
                        externalGpsAvailable ->
                    SensorSource.EXTERNAL

                externalImuAvailable ||
                        externalGpsAvailable ->
                    SensorSource.HYBRID

                else ->
                    SensorSource.PHONE
            }

        val timestamp =
            maxOf(
                phone?.timestampMillis ?: 0L,
                external?.timestampMillis ?: 0L
            )

        onFusedFrame(
            SensorFrame(
                timestampMillis = timestamp,

                accX = accX,
                accY = accY,
                accZ = accZ,

                gyroX = gyroX,
                gyroY = gyroY,
                gyroZ = gyroZ,

                speedKmh = speed,

                latitude = latitude,
                longitude = longitude,

                vibration = vibration,
                temperatureCelsius = temperature,

                source = source
            )
        )
    }
}