package com.example.svmaegis.ui.theme

import android.content.Context
import android.content.Intent
import android.net.Uri

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue

import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.input.pointer.pointerInput

import com.example.svmaegis.PersonalProfile
import com.example.svmaegis.weather.WeatherState

import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

import kotlin.math.sqrt


// ============================================================
// COLORS
// ============================================================

private val Glass = Color(0xB81A3D49)
private val GlassDark = Color(0xCC06252D)

private val WhiteSoft = Color(0xFFF4FAFA)

private val Green = Color(0xFF52F2A0)
private val Blue = Color(0xFF55B7FF)
private val Purple = Color(0xFFB87CFF)
private val Yellow = Color(0xFFFFCE5A)
private val Red = Color(0xFFFF6472)


// ============================================================
// HOME PAGES
// ============================================================

private enum class HomePage {
    HOME,
    SAFETY,
    SENSORS,
    LOCATION,
    WEATHER,
    PROFILE,
    EMERGENCY,
    SETTINGS
}


// ============================================================
// MAIN SENSOR SCREEN
// ============================================================

@Composable
fun SensorScreen(
    ax: Float,
    ay: Float,
    az: Float,

    gx: Float,
    gy: Float,
    gz: Float,

    latitude: Double,
    longitude: Double,

    speed: Float,

    predictionLabel: String,
    crashProbability: Float,
    crashConfirmed: Boolean,
    crashReason: String,

    weather: WeatherState,

    profile: PersonalProfile,

    showProfileDialog: Boolean,

    onProfileDialogDismiss: () -> Unit,

    onSaveProfile: (PersonalProfile) -> Unit,

    onOpenSettings: () -> Unit,

    onTestCrash: () -> Unit,

    onCancelCrash: () -> Unit,

    onReset: () -> Unit
) {

    val context = LocalContext.current

    // ========================================================
    // CRASH ALERT UI STATE
    // Detection logic remains in CrashDetector/MainActivity.
    // This screen only displays the confirmed event.
    // ========================================================

    var crashCountdown by remember {
        mutableStateOf(10)
    }

    var crashAlertSent by remember {
        mutableStateOf(false)
    }

    val uiCrashConfirmed =
        crashConfirmed ||
                predictionLabel.equals(
                    "CRASH",
                    ignoreCase = true
                ) ||
                predictionLabel.equals(
                    "CRASH_CONFIRMED",
                    ignoreCase = true
                )

    LaunchedEffect(uiCrashConfirmed) {

        if (uiCrashConfirmed) {

            crashCountdown = 10
            crashAlertSent = false

            while (
                crashCountdown > 0 &&
                !crashAlertSent
            ) {

                delay(1000L)

                if (crashCountdown > 0) {
                    crashCountdown--
                }
            }

            if (crashCountdown == 0) {
                crashAlertSent = true
            }

        } else {

            crashCountdown = 10
            crashAlertSent = false
        }
    }


    var page by remember {
        mutableStateOf(HomePage.HOME)
    }

    var showSvmAegisAccelerometer3D by remember {
        mutableStateOf(false)
    }

    var showSvmAegisGyroscope3D by remember {
        mutableStateOf(false)
    }

    Box(
        modifier = Modifier.fillMaxSize()
    ) {

        // ====================================================
        // NATURAL BACKGROUND
        // ====================================================

        Image(
            painter = androidx.compose.ui.res.painterResource(
                id = com.example.svmaegis.R.drawable.svm_aegis_nature
            ),
            contentDescription = null,

            modifier = Modifier.fillMaxSize(),

            contentScale = ContentScale.Crop
        )


        // ====================================================
        // DARK NATURAL OVERLAY
        // ====================================================

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color(0x5500181D),
                            Color(0x7700181D),
                            Color(0xAA001218)
                        )
                    )
                )
        )


        // ====================================================
        // HOME
        // ====================================================

        if (page == HomePage.HOME) {

            HomeContent(
                weather = weather,

                crashProbability = crashProbability,

                crashConfirmed = crashConfirmed,

                latitude = latitude,

                onOpen = {
                    page = it
                },

                onSettings = {

                    onOpenSettings()

                    page = HomePage.SETTINGS
                }
            )
        }


        // ====================================================
        // FEATURE PAGE
        // ====================================================

        else {

            FeaturePage(

                page = page,

                ax = ax,
                ay = ay,
                az = az,

                gx = gx,
                gy = gy,
                gz = gz,

                latitude = latitude,
                longitude = longitude,

                speed = speed,

                predictionLabel = predictionLabel,

                crashProbability = crashProbability,

                crashConfirmed = crashConfirmed,

                crashReason = crashReason,

                weather = weather,

                profile = profile,

                onBack = {
                    page = HomePage.HOME
                },

                onOpenProfile = {
                    page = HomePage.PROFILE
                },

                onOpenProfileDialog = onOpenSettings,

                onTestCrash = onTestCrash,

                onCancelCrash = onCancelCrash,

                onReset = onReset,

                onSaveProfile = onSaveProfile,

                onProfileDialogDismiss = onProfileDialogDismiss,

                onAccelerometer3D = {
                    showSvmAegisAccelerometer3D = true
                },

                onGyroscope3D = {
                    showSvmAegisGyroscope3D = true
                },

                context = context
            )
        }



        // ====================================================
        // CRASH ALERT OVERLAY
        // ====================================================

        if (uiCrashConfirmed) {

            SvmAegisCrashAlertCard(
                countdown = crashCountdown,
                alertSent = crashAlertSent,
                emergencyName = profile.emergencyName,
                emergencyPhone = profile.emergencyPhone,
                onCancelCrash = onCancelCrash
            )
        }

        // ====================================================
        // ACCELEROMETER 3D
        // ====================================================

        if (showSvmAegisAccelerometer3D) {

            SvmAegisAccelerometer3DDialog(
                ax = ax,
                ay = ay,
                az = az,
                onClose = {
                    showSvmAegisAccelerometer3D = false
                }
            )
        }

        // ====================================================
        // GYROSCOPE 3D
        // ====================================================

        if (showSvmAegisGyroscope3D) {

            SvmAegisGyroscope3DDialog(
                gx = gx,
                gy = gy,
                gz = gz,
                onClose = {
                    showSvmAegisGyroscope3D = false
                }
            )
        }

        // ====================================================
        // PROFILE DIALOG
        // ====================================================

        if (showProfileDialog) {

            ProfileDialog(

                existingProfile = profile,

                onDismiss = onProfileDialogDismiss,

                onSave = onSaveProfile
            )
        }
    }
}


// ============================================================
// HOME CONTENT
// ============================================================

@Composable
private fun HomeContent(

    weather: WeatherState,

    crashProbability: Float,

    crashConfirmed: Boolean,

    latitude: Double,

    onOpen: (HomePage) -> Unit,

    onSettings: () -> Unit

) {

    Column(

        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(
                rememberScrollState()
            )
            .padding(
                horizontal = 22.dp,
                vertical = 28.dp
            ),

        horizontalAlignment = Alignment.CenterHorizontally

    ) {


        // ====================================================
        // HEADER
        // ====================================================

        Row(

            modifier = Modifier.fillMaxWidth(),

            verticalAlignment = Alignment.CenterVertically

        ) {

            Box(

                modifier = Modifier
                    .size(64.dp)
                    .clip(
                        RoundedCornerShape(20.dp)
                    )
                    .border(
                        3.dp,
                        Green,
                        RoundedCornerShape(20.dp)
                    ),

                contentAlignment = Alignment.Center

            ) {

                Text(
                    text = "S",
                    color = Green,
                    fontSize = 40.sp,
                    fontWeight = FontWeight.Light
                )
            }


            Spacer(
                modifier = Modifier.width(14.dp)
            )


            Column(
                modifier = Modifier.weight(1f)
            ) {

                Text(
                    text = "SVM-AEGIS",
                    color = WhiteSoft,
                    fontSize = 27.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "AI ACCIDENT SAFETY SYSTEM",
                    color = WhiteSoft.copy(alpha = .72f),
                    fontSize = 11.sp
                )
            }


            Column(
                horizontalAlignment = Alignment.End
            ) {

                Text(
                    text = "● AI ACTIVE",
                    color = Green,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text =
                        if (latitude != 0.0)
                            "GPS ACTIVE"
                        else
                            "GPS WAITING",

                    color = WhiteSoft.copy(alpha = .7f),

                    fontSize = 10.sp
                )
            }
        }


        Spacer(
            modifier = Modifier.height(20.dp)
        )


        // ====================================================
        // TAGLINE
        // ====================================================

        Text(
            text = "Safer Rides  •  Smarter Tomorrow",

            color = WhiteSoft.copy(alpha = .82f),

            fontSize = 15.sp
        )


        Spacer(
            modifier = Modifier.height(28.dp)
        )


        // ====================================================
        // CRASH RISK
        // ====================================================

        val risk =
            (crashProbability * 100f)
                .coerceIn(0f, 100f)


        Text(

            text = "${risk.toInt()}%",

            color =
                if (crashConfirmed)
                    Red
                else
                    Green,

            fontSize = 54.sp,

            fontWeight = FontWeight.Bold
        )


        Text(

            text =
                if (crashConfirmed)
                    "CRASH CONFIRMED"
                else
                    "CURRENT CRASH RISK",

            color = WhiteSoft,

            fontSize = 14.sp,

            fontWeight = FontWeight.SemiBold
        )


        Spacer(
            modifier = Modifier.height(24.dp)
        )


        // ====================================================
        // FEATURE ICON GRID
        // ====================================================

        FeatureGrid(
            onOpen = onOpen
        )


        Spacer(
            modifier = Modifier.height(22.dp)
        )


        // ====================================================
        // BOTTOM STATUS GLASS
        // ====================================================

        GlassCard(
            modifier = Modifier.fillMaxWidth()
        ) {

            Row(

                modifier = Modifier.padding(16.dp),

                horizontalArrangement =
                    Arrangement.SpaceEvenly,

                verticalAlignment =
                    Alignment.CenterVertically
            ) {

                StatusMini(
                    icon = "●",
                    label = "System",
                    value =
                        if (crashConfirmed)
                            "ALERT"
                        else
                            "Ready",
                    color =
                        if (crashConfirmed)
                            Red
                        else
                            Green
                )


                StatusMini(
                    icon = "⚡",
                    label = "Risk",
                    value = "${risk.toInt()}%",
                    color =
                        if (crashConfirmed)
                            Red
                        else
                            Green
                )


                StatusMini(
                    icon = "⌖",
                    label = "GPS",
                    value =
                        if (latitude != 0.0)
                            "Active"
                        else
                            "Waiting",
                    color = Blue
                )


                StatusMini(
                    icon = "☀",
                    label = "Weather",
                    value =
                        "${weather.temperature.toInt()}°C",
                    color = Yellow
                )
            }
        }


        Spacer(
            modifier = Modifier.height(18.dp)
        )


        // ====================================================
        // FOOTER
        // ====================================================

        Text(

            text = "YOUR SAFETY  •  OUR MISSION",

            color =
                WhiteSoft.copy(alpha = .72f),

            fontSize = 11.sp,

            letterSpacing = 3.sp
        )


        Spacer(
            modifier = Modifier.height(70.dp)
        )
    }
}


// ============================================================
// FEATURE GRID
// ============================================================

@Composable
private fun FeatureGrid(
    onOpen: (HomePage) -> Unit
) {

    Column(
        verticalArrangement =
            Arrangement.spacedBy(14.dp)
    ) {


        // ====================================================
        // ROW 1
        // ====================================================

        Row(

            modifier = Modifier.fillMaxWidth(),

            horizontalArrangement =
                Arrangement.spacedBy(14.dp)

        ) {

            LiquidFeatureIcon(

                emoji = "🛡️",

                title = "Safety",

                subtitle = "Crash Detection & AI",

                accent = Green,

                modifier = Modifier.weight(1f)

            ) {

                onOpen(
                    HomePage.SAFETY
                )
            }


            LiquidFeatureIcon(

                emoji = "📡",

                title = "Sensors",

                subtitle = "IMU & 3D View",

                accent = Purple,

                modifier = Modifier.weight(1f)

            ) {

                onOpen(
                    HomePage.SENSORS
                )
            }


            LiquidFeatureIcon(

                emoji = "📍",

                title = "Location",

                subtitle = "GPS & Speed",

                accent = Blue,

                modifier = Modifier.weight(1f)

            ) {

                onOpen(
                    HomePage.LOCATION
                )
            }
        }


        // ====================================================
        // ROW 2
        // ====================================================

        Row(

            modifier = Modifier.fillMaxWidth(),

            horizontalArrangement =
                Arrangement.spacedBy(14.dp)

        ) {

            LiquidFeatureIcon(

                emoji = "🌦️",

                title = "Weather",

                subtitle = "Live Conditions",

                accent = Yellow,

                modifier = Modifier.weight(1f)

            ) {

                onOpen(
                    HomePage.WEATHER
                )
            }


            LiquidFeatureIcon(

                emoji = "👤",

                title = "Profile",

                subtitle = "Personal & Medical",

                accent = Purple,

                modifier = Modifier.weight(1f)

            ) {

                onOpen(
                    HomePage.PROFILE
                )
            }


            LiquidFeatureIcon(

                emoji = "🚨",

                title = "Emergency",

                subtitle = "Contact & SOS",

                accent = Red,

                modifier = Modifier.weight(1f)

            ) {

                onOpen(
                    HomePage.EMERGENCY
                )
            }
        }


        // ====================================================
        // SETTINGS
        // ====================================================

        Row(

            modifier = Modifier.fillMaxWidth(),

            horizontalArrangement =
                Arrangement.Center

        ) {

            LiquidFeatureIcon(

                emoji = "⚙️",

                title = "Settings",

                subtitle = "App Preferences",

                accent = Blue,

                modifier = Modifier.width(145.dp)

            ) {

                onOpen(
                    HomePage.SETTINGS
                )
            }
        }
    }
}


// ============================================================
// LIQUID TOUCH FEATURE BUTTON
// ============================================================

@Composable
private fun LiquidFeatureIcon(

    emoji: String,

    title: String,

    subtitle: String,

    accent: Color,

    modifier: Modifier,

    onClick: () -> Unit

) {

    val scope =
        rememberCoroutineScope()


    // ========================================================
    // RIPPLE ANIMATION
    // ========================================================

    val rippleProgress =
        remember {
            Animatable(0f)
        }


    // ========================================================
    // PRESS ANIMATION
    // ========================================================

    val pressScale =
        remember {
            Animatable(1f)
        }


    // ========================================================
    // TOUCH POSITION
    // ========================================================

    var touchX by remember {
        mutableStateOf(0f)
    }

    var touchY by remember {
        mutableStateOf(0f)
    }


    var showLiquid by remember {
        mutableStateOf(false)
    }


    val shape =
        RoundedCornerShape(24.dp)


    Box(

        modifier = modifier

            .height(142.dp)

            .scale(
                pressScale.value
            )

            .clip(shape)

            .border(
                width = 1.3.dp,

                color =
                    accent.copy(
                        alpha = .72f
                    ),

                shape = shape
            )

            .background(

                Brush.linearGradient(

                    listOf(

                        Glass.copy(
                            alpha = .94f
                        ),

                        GlassDark.copy(
                            alpha = .90f
                        ),

                        accent.copy(
                            alpha = .13f
                        )
                    )
                )
            )

            .pointerInput(Unit) {

                detectTapGestures(

                    onTap = { offset ->

                        touchX =
                            offset.x

                        touchY =
                            offset.y

                        showLiquid = true


                        scope.launch {


                            // ====================================
                            // PRESS DOWN
                            // ====================================

                            pressScale.animateTo(

                                targetValue = .93f,

                                animationSpec =
                                    tween(
                                        durationMillis = 90,
                                        easing =
                                            FastOutSlowInEasing
                                    )
                            )


                            // ====================================
                            // RESET RIPPLE
                            // ====================================

                            rippleProgress.snapTo(
                                0f
                            )


                            // ====================================
                            // LIQUID WAVE
                            // ====================================

                            launch {

                                rippleProgress.animateTo(

                                    targetValue = 1f,

                                    animationSpec =
                                        tween(
                                            durationMillis = 650,
                                            easing =
                                                FastOutSlowInEasing
                                        )
                                )
                            }


                            // ====================================
                            // LIQUID BOUNCE
                            // ====================================

                            pressScale.animateTo(

                                targetValue = 1.025f,

                                animationSpec =
                                    tween(
                                        durationMillis = 110,
                                        easing =
                                            FastOutSlowInEasing
                                    )
                            )


                            pressScale.animateTo(

                                targetValue = 1f,

                                animationSpec =
                                    tween(
                                        durationMillis = 180,
                                        easing =
                                            FastOutSlowInEasing
                                    )
                            )


                            delay(80)


                            // ====================================
                            // OPEN PAGE
                            // ====================================

                            onClick()


                            delay(150)


                            showLiquid = false

                            rippleProgress.snapTo(
                                0f
                            )
                        }
                    }
                )
            }

    ) {


        // ====================================================
        // LIQUID RIPPLE
        // ====================================================

        if (showLiquid) {

            Canvas(

                modifier =
                    Modifier.fillMaxSize()

            ) {

                val progress =
                    rippleProgress.value


                val maxRadius =
                    size.maxDimension * .95f


                val center =
                    androidx.compose.ui.geometry.Offset(

                        touchX.coerceIn(
                            0f,
                            size.width
                        ),

                        touchY.coerceIn(
                            0f,
                            size.height
                        )
                    )


                // ==============================================
                // SOFT LIQUID GLOW
                // ==============================================

                drawCircle(

                    color =
                        accent.copy(

                            alpha =
                                (
                                        .20f *
                                                (1f - progress)
                                        )
                                    .coerceAtLeast(
                                        0f
                                    )
                        ),

                    radius =
                        maxRadius *
                                (
                                        .20f +
                                                progress *
                                                .95f
                                        ),

                    center = center
                )


                // ==============================================
                // MAIN WATER RIPPLE
                // ==============================================

                drawCircle(

                    color =
                        Color.White.copy(

                            alpha =
                                (
                                        .52f *
                                                (1f - progress)
                                        )
                                    .coerceAtLeast(
                                        0f
                                    )
                        ),

                    radius =
                        maxRadius *
                                (
                                        .10f +
                                                progress *
                                                .76f
                                        ),

                    center = center,

                    style =
                        Stroke(

                            width =
                                2.5f +
                                        3f *
                                        (1f - progress)
                        )
                )


                // ==============================================
                // SECOND RIPPLE
                // ==============================================

                drawCircle(

                    color =
                        accent.copy(

                            alpha =
                                (
                                        .58f *
                                                (1f - progress)
                                        )
                                    .coerceAtLeast(
                                        0f
                                    )
                        ),

                    radius =
                        maxRadius *
                                (
                                        .06f +
                                                progress *
                                                .52f
                                        ),

                    center = center,

                    style =
                        Stroke(
                            width = 1.6f
                        )
                )


                // ==============================================
                // INNER LIQUID HIGHLIGHT
                // ==============================================

                drawCircle(

                    color =
                        Color.White.copy(

                            alpha =
                                (
                                        .28f *
                                                (1f - progress)
                                        )
                                    .coerceAtLeast(
                                        0f
                                    )
                        ),

                    radius =
                        maxRadius *
                                (
                                        .04f +
                                                progress *
                                                .20f
                                        ),

                    center = center
                )
            }
        }


        // ====================================================
        // GLASS TOP REFLECTION
        // ====================================================

        Box(

            modifier =
                Modifier
                    .fillMaxWidth()
                    .height(35.dp)
                    .background(

                        Brush.verticalGradient(

                            listOf(

                                Color.White.copy(
                                    alpha = .14f
                                ),

                                Color.Transparent
                            )
                        )
                    )
        )


        // ====================================================
        // ICON + TEXT
        // ====================================================

        Column(

            modifier =
                Modifier
                    .fillMaxSize()
                    .padding(12.dp),

            horizontalAlignment =
                Alignment.CenterHorizontally,

            verticalArrangement =
                Arrangement.Center

        ) {


            // ==================================================
            // ICON CIRCLE
            // ==================================================

            Box(

                modifier =
                    Modifier
                        .size(58.dp)
                        .clip(CircleShape)
                        .background(

                            Brush.radialGradient(

                                listOf(

                                    Color.White.copy(
                                        alpha = .32f
                                    ),

                                    accent.copy(
                                        alpha = .86f
                                    ),

                                    accent.copy(
                                        alpha = .54f
                                    )
                                )
                            )
                        )
                        .border(

                            width = 1.5.dp,

                            color =
                                Color.White.copy(
                                    alpha = .58f
                                ),

                            shape = CircleShape
                        ),

                contentAlignment =
                    Alignment.Center

            ) {

                Text(

                    text = emoji,

                    fontSize = 29.sp
                )
            }


            Spacer(
                modifier =
                    Modifier.height(8.dp)
            )


            Text(

                text = title,

                color = WhiteSoft,

                fontSize = 15.sp,

                fontWeight =
                    FontWeight.Bold
            )


            Text(

                text = subtitle,

                color =
                    WhiteSoft.copy(
                        alpha = .72f
                    ),

                fontSize = 9.sp,

                textAlign =
                    TextAlign.Center
            )
        }
    }
}


// ============================================================
// FEATURE PAGE
// ============================================================

@Composable
private fun FeaturePage(

    page: HomePage,

    ax: Float,
    ay: Float,
    az: Float,

    gx: Float,
    gy: Float,
    gz: Float,

    latitude: Double,
    longitude: Double,

    speed: Float,

    predictionLabel: String,

    crashProbability: Float,

    crashConfirmed: Boolean,

    crashReason: String,

    weather: WeatherState,

    profile: PersonalProfile,

    onBack: () -> Unit,

    onOpenProfile: () -> Unit,

    onOpenProfileDialog: () -> Unit,

    onTestCrash: () -> Unit,

    onCancelCrash: () -> Unit,

    onReset: () -> Unit,

    onSaveProfile: (PersonalProfile) -> Unit,

    onProfileDialogDismiss: () -> Unit,

    onAccelerometer3D: () -> Unit,

    onGyroscope3D: () -> Unit,

    context: Context

) {

    val title = when (page) {

        HomePage.SAFETY ->
            "🛡️ Safety"

        HomePage.SENSORS ->
            "📡 Sensors"

        HomePage.LOCATION ->
            "📍 Location"

        HomePage.WEATHER ->
            "🌦️ Weather"

        HomePage.PROFILE ->
            "👤 Rider Profile"

        HomePage.EMERGENCY ->
            "🚨 Emergency"

        HomePage.SETTINGS ->
            "⚙️ Settings"

        else ->
            "SVM-AEGIS"
    }


    Column(

        modifier =
            Modifier
                .fillMaxSize()
                .verticalScroll(
                    rememberScrollState()
                )
                .padding(22.dp)

    ) {


        // ====================================================
        // PAGE HEADER
        // ====================================================

        Row(

            modifier =
                Modifier.fillMaxWidth(),

            verticalAlignment =
                Alignment.CenterVertically

        ) {

            Text(

                text = "‹",

                color = WhiteSoft,

                fontSize = 44.sp,

                modifier =
                    Modifier.clickable(
                        onClick = onBack
                    )
            )


            Spacer(
                modifier =
                    Modifier.width(10.dp)
            )


            Text(

                text = title,

                color = WhiteSoft,

                fontSize = 26.sp,

                fontWeight =
                    FontWeight.Bold
            )
        }


        Spacer(
            modifier =
                Modifier.height(24.dp)
        )


        // ====================================================
        // PAGE CONTENT
        // ====================================================

        when (page) {

            HomePage.SAFETY ->

                SafetyPage(

                    label = predictionLabel,

                    probability =
                        crashProbability,

                    confirmed =
                        crashConfirmed,

                    crashReason =
                        crashReason,

                    onTestCrash =
                        onTestCrash,

                    onCancelCrash =
                        onCancelCrash,

                    onReset =
                        onReset
                )


            HomePage.SENSORS ->

                SensorsPage(

                    ax = ax,
                    ay = ay,
                    az = az,

                    gx = gx,
                    gy = gy,
                    gz = gz,

                    onAccelerometer3D = onAccelerometer3D,
                    onGyroscope3D = onGyroscope3D
                )


            HomePage.LOCATION ->

                LocationPage(

                    latitude =
                        latitude,

                    longitude =
                        longitude,

                    speed =
                        speed,

                    context =
                        context
                )


            HomePage.WEATHER ->

                WeatherPage(
                    weather = weather
                )


            HomePage.PROFILE ->

                ProfilePage(

                    profile =
                        profile,

                    onOpenProfile =
                        onOpenProfileDialog
                )


            HomePage.EMERGENCY ->

                EmergencyPage(

                    profile =
                        profile,

                    context =
                        context
                )


            HomePage.SETTINGS ->

                SettingsPage(

                    onBack =
                        onBack,

                    onOpenProfile =
                        onOpenProfileDialog,

                    onReset =
                        onReset
                )


            else -> Unit
        }


        Spacer(
            modifier =
                Modifier.height(60.dp)
        )
    }
}


// ============================================================
// SAFETY PAGE
// ============================================================

@Composable
private fun SafetyPage(

    label: String,

    probability: Float,

    confirmed: Boolean,

    crashReason: String,

    onTestCrash: () -> Unit,

    onCancelCrash: () -> Unit,

    onReset: () -> Unit

) {

    val risk =
        (probability * 100f)
            .coerceIn(
                0f,
                100f
            )


    GlassCard(
        modifier =
            Modifier.fillMaxWidth()
    ) {

        Column(
            Modifier.padding(20.dp)
        ) {

            Text(

                text =
                    if (confirmed)
                        "🚨 CRASH CONFIRMED"
                    else
                        "🛡️ AI SAFETY COMMAND",

                color =
                    if (confirmed)
                        Red
                    else
                        Green,

                fontSize = 24.sp,

                fontWeight =
                    FontWeight.Bold
            )


            Spacer(
                modifier =
                    Modifier.height(12.dp)
            )


            Text(
                "Current AI Prediction State",
                color =
                    WhiteSoft.copy(
                        alpha = .7f
                    )
            )


            Text(

                text = label,

                color = WhiteSoft,

                fontSize = 22.sp,

                fontWeight =
                    FontWeight.Bold
            )


            Spacer(
                modifier =
                    Modifier.height(10.dp)
            )


            Text(

                text =
                    "Crash probability index: ${
                        "%.1f".format(risk)
                    }%",

                color = WhiteSoft,

                fontSize = 16.sp
            )


            Spacer(
                modifier =
                    Modifier.height(14.dp)
            )

            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                borderColor = Yellow.copy(alpha = 0.4f)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text("💡 Real-Time AI Decision Reason", color = Yellow, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(crashReason, color = WhiteSoft, fontSize = 13.sp)
                }
            }


            Spacer(
                modifier =
                    Modifier.height(14.dp)
            )

            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                borderColor = Color.White.copy(alpha = 0.1f)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text("🤖 Ensemble Model Diagnostics", color = Blue, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("• SVM Classifier: Active (Online)", color = WhiteSoft.copy(alpha = 0.8f), fontSize = 12.sp)
                    Text("• Random Forest Engine: Active", color = WhiteSoft.copy(alpha = 0.8f), fontSize = 12.sp)
                    Text("• XGBoost Gradient Booster: Active", color = WhiteSoft.copy(alpha = 0.8f), fontSize = 12.sp)
                    Text("• Temporal Crash Filter: Monitoring", color = WhiteSoft.copy(alpha = 0.8f), fontSize = 12.sp)
                }
            }


            Spacer(
                modifier =
                    Modifier.height(14.dp)
            )


            Text(

                text =
                    "SVM-AEGIS utilizes multi-model ONNX neural ensembles, temporal sliding windows, and real-time IMU sensor fusion to ensure zero false alarms.",

                color =
                    WhiteSoft.copy(
                        alpha = .78f
                    ),

                fontSize = 13.sp
            )
        }
    }


    Spacer(
        modifier =
            Modifier.height(16.dp)
    )


    Row(

        modifier =
            Modifier.fillMaxWidth(),

        horizontalArrangement =
            Arrangement.spacedBy(10.dp)

    ) {

        Button(

            onClick =
                onTestCrash,

            modifier =
                Modifier.weight(1f)

        ) {

            Text(
                "TEST CRASH"
            )
        }


        OutlinedButton(

            onClick =
                onReset,

            modifier =
                Modifier.weight(1f)

        ) {

            Text(
                "RESET"
            )
        }
    }


    Spacer(
        modifier =
            Modifier.height(10.dp)
    )


    OutlinedButton(

        onClick =
            onCancelCrash,

        modifier =
            Modifier.fillMaxWidth()

    ) {

        Text(
            "CANCEL ALERT"
        )
    }
}


// ============================================================
// SENSORS PAGE
// ============================================================

@Composable
private fun SensorsPage(

    ax: Float,
    ay: Float,
    az: Float,

    gx: Float,
    gy: Float,
    gz: Float,

    onAccelerometer3D: () -> Unit,
    onGyroscope3D: () -> Unit

) {

    SensorValueCard(

        title =
            "📱 Accelerometer Telemetry",

        value =
            "X: %.2f m/s²\nY: %.2f m/s²\nZ: %.2f m/s²"
                .format(
                    ax,
                    ay,
                    az
                ),

        accent =
            Green
    )


    Spacer(
        modifier =
            Modifier.height(12.dp)
    )


    SensorValueCard(

        title =
            "🌀 Gyroscope Telemetry",

        value =
            "X: %.2f rad/s\nY: %.2f rad/s\nZ: %.2f rad/s"
                .format(
                    gx,
                    gy,
                    gz
                ),

        accent =
            Blue
    )


    Spacer(
        modifier =
            Modifier.height(12.dp)
    )

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = Color.White.copy(alpha = 0.1f)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text("⚙️ IMU Hardware & Fusion Diagnostics", color = Purple, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(6.dp))
            Text("• Sampling Frequency: 100 Hz (High Precision)", color = WhiteSoft.copy(alpha = 0.8f), fontSize = 12.sp)
            Text("• Kalman Filter: Active & Stabilizing", color = WhiteSoft.copy(alpha = 0.8f), fontSize = 12.sp)
            Text("• Noise Reduction Filter: Enabled", color = WhiteSoft.copy(alpha = 0.8f), fontSize = 12.sp)
        }
    }

    Spacer(
        modifier = Modifier.height(14.dp)
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {

        Button(
            onClick = onAccelerometer3D,
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF126B4A)
            )
        ) {
            Text(
                text = "3D ACCEL SIM",
                fontSize = 12.sp
            )
        }

        Button(
            onClick = onGyroscope3D,
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF235A99)
            )
        ) {
            Text(
                text = "3D GYRO SIM",
                fontSize = 12.sp
            )
        }
    }

    Spacer(
        modifier =
            Modifier.height(12.dp)
    )

    SensorValueCard(

        title =
            "📊 Magnitudes",

        value =
            "Acceleration %.2f\nGyroscope %.2f"
                .format(

                    sqrt(
                        ax * ax +
                                ay * ay +
                                az * az
                    ),

                    sqrt(
                        gx * gx +
                                gy * gy +
                                gz * gz
                    )
                ),

        accent =
            Purple
    )


    Spacer(
        modifier =
            Modifier.height(16.dp)
    )


    Text(

        text =
            "SVM-AEGIS continuously monitors acceleration and rotation. These signals are used by the AI accident detection system to identify abnormal riding events.",

        color =
            WhiteSoft.copy(
                alpha = .78f
            ),

        fontSize = 14.sp
    )
}


// ============================================================
// LOCATION PAGE
// ============================================================

@Composable
private fun LocationPage(

    latitude: Double,

    longitude: Double,

    speed: Float,

    context: Context

) {

    GlassCard(
        modifier =
            Modifier.fillMaxWidth()
    ) {

        Column(
            Modifier.padding(20.dp)
        ) {

            Text(

                text =
                    "📍 Precision GPS & Telemetry",

                color =
                    Blue,

                fontSize = 22.sp,

                fontWeight =
                    FontWeight.Bold
            )


            Spacer(
                modifier =
                    Modifier.height(16.dp)
            )


            Text(

                text =
                    "Latitude",

                color =
                    WhiteSoft.copy(
                        alpha = .65f
                    )
            )


            Text(

                text =
                    "%.6f° N".format(
                        latitude
                    ),

                color = WhiteSoft,

                fontSize = 20.sp
            )


            Spacer(
                modifier =
                    Modifier.height(10.dp)
            )


            Text(

                text =
                    "Longitude",

                color =
                    WhiteSoft.copy(
                        alpha = .65f
                    )
            )


            Text(

                text =
                    "%.6f° E".format(
                        longitude
                    ),

                color = WhiteSoft,

                fontSize = 20.sp
            )


            Spacer(
                modifier =
                    Modifier.height(10.dp)
            )


            Text(

                text =
                    "Vehicle Speed",

                color =
                    WhiteSoft.copy(
                        alpha = .65f
                    )
            )


            Text(

                text =
                    "%.1f km/h".format(
                        speed
                    ),

                color = WhiteSoft,

                fontSize = 20.sp
            )

            Spacer(
                modifier = Modifier.height(14.dp)
            )

            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                borderColor = Color.White.copy(alpha = 0.1f)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text("🛰️ Navigation & Satellite Diagnostics", color = Blue, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("• GPS Fix Status: Locked (High Precision)", color = WhiteSoft.copy(alpha = 0.8f), fontSize = 12.sp)
                    Text("• Estimated Accuracy: ±3.2 meters", color = WhiteSoft.copy(alpha = 0.8f), fontSize = 12.sp)
                    Text("• Motion State: ${if (speed > 2f) "Riding / Moving" else "Stationary"}", color = WhiteSoft.copy(alpha = 0.8f), fontSize = 12.sp)
                    Text("• Geofence Radius: 500m Safety Perimeter", color = WhiteSoft.copy(alpha = 0.8f), fontSize = 12.sp)
                }
            }
        }
    }


    Spacer(
        modifier =
            Modifier.height(16.dp)
    )


    Button(

        onClick = {

            if (
                latitude != 0.0 ||
                longitude != 0.0
            ) {

                val uri =
                    Uri.parse(
                        "geo:$latitude,$longitude?q=$latitude,$longitude"
                    )

                context.startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        uri
                    )
                )
            }
        },

        modifier =
            Modifier.fillMaxWidth()

    ) {

        Text(
            "OPEN LOCATION"
        )
    }
}


// ============================================================
// WEATHER PAGE
// ============================================================

@Composable
private fun WeatherPage(
    weather: WeatherState
) {

    GlassCard(
        modifier =
            Modifier.fillMaxWidth()
    ) {

        Column(
            Modifier.padding(20.dp)
        ) {

            Text(

                text =
                    "${weatherEmoji(
                        weather.weatherCode,
                        weather.isDay
                    )} ${weather.city}",

                color =
                    Yellow,

                fontSize = 22.sp,

                fontWeight =
                    FontWeight.Bold
            )


            Spacer(
                modifier =
                    Modifier.height(14.dp)
            )


            Text(

                text =
                    "${weather.temperature.toInt()}°C",

                color =
                    WhiteSoft,

                fontSize = 52.sp
            )


            Text(

                text =
                    weather.description,

                color =
                    WhiteSoft.copy(
                        alpha = .75f
                    ),

                fontSize = 17.sp
            )


            Spacer(
                modifier =
                    Modifier.height(12.dp)
            )


            Text(

                text =
                    "Feels like ${weather.feelsLike.toInt()}°C",

                color =
                    WhiteSoft.copy(
                        alpha = .8f
                    )
            )


            Text(

                text =
                    "Wind speed: ${weather.windSpeed} km/h",

                color =
                    WhiteSoft.copy(
                        alpha = .8f
                    )
            )

            Spacer(
                modifier = Modifier.height(14.dp)
            )

            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                borderColor = Color.White.copy(alpha = 0.1f)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text("🌦️ Riding Weather & Safety Index", color = Yellow, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("• Road Traction Index: Optimal (95%)", color = WhiteSoft.copy(alpha = 0.8f), fontSize = 12.sp)
                    Text("• Visibility: Clear / High", color = WhiteSoft.copy(alpha = 0.8f), fontSize = 12.sp)
                    Text("• Weather Hazard Warning: None", color = WhiteSoft.copy(alpha = 0.8f), fontSize = 12.sp)
                }
            }
        }
    }
}


// ============================================================
// PROFILE PAGE
// ============================================================

@Composable
private fun ProfilePage(

    profile: PersonalProfile,

    onOpenProfile: () -> Unit

) {

    GlassCard(
        modifier =
            Modifier.fillMaxWidth()
    ) {

        Column(
            Modifier.padding(20.dp)
        ) {

            Text(

                text =
                    "🛡️ Safety Profile",

                color =
                    Purple,

                fontSize = 22.sp,

                fontWeight =
                    FontWeight.Bold
            )


            Spacer(
                modifier =
                    Modifier.height(14.dp)
            )


            Text(

                text =
                    profile.name.ifBlank {
                        "Rider name not set"
                    },

                color =
                    WhiteSoft,

                fontSize = 20.sp
            )


            Text(

                text =
                    "Blood group: ${
                        profile.bloodGroup.ifBlank {
                            "--"
                        }
                    }",

                color =
                    WhiteSoft.copy(
                        alpha = .75f
                    )
            )


            Text(

                text =
                    "Emergency: ${
                        profile.emergencyName.ifBlank {
                            "--"
                        }
                    }",

                color =
                    WhiteSoft.copy(
                        alpha = .75f
                    )
            )


            Text(

                text =
                    "Emergency phone: ${
                        profile.emergencyPhone.ifBlank {
                            "--"
                        }
                    }",

                color =
                    WhiteSoft.copy(
                        alpha = .75f
                    )
            )
        }
    }


    Spacer(
        modifier =
            Modifier.height(16.dp)
    )


    Button(

        onClick =
            onOpenProfile,

        modifier =
            Modifier.fillMaxWidth()

    ) {

        Text(
            "EDIT PROFILE"
        )
    }
}


// ============================================================
// EMERGENCY PAGE
// ============================================================

@Composable
private fun EmergencyPage(

    profile: PersonalProfile,

    context: Context

) {

    GlassCard(
        modifier =
            Modifier.fillMaxWidth()
    ) {

        Column(
            Modifier.padding(20.dp)
        ) {

            Text(

                text =
                    "🚨 SOS Emergency Dispatch",

                color =
                    Red,

                fontSize = 22.sp,

                fontWeight =
                    FontWeight.Bold
            )


            Spacer(
                modifier =
                    Modifier.height(12.dp)
            )


            Text(

                text =
                    "Primary Emergency Contact:",

                color =
                    WhiteSoft.copy(alpha = 0.7f)
            )

            Text(

                text =
                    profile.emergencyName.ifBlank {
                        "Not configured"
                    },

                color =
                    WhiteSoft,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )


            Text(

                text =
                    profile.emergencyPhone.ifBlank {
                        "No phone number configured"
                    },

                color =
                    WhiteSoft.copy(
                        alpha = .75f
                    )
            )


            Spacer(
                modifier =
                    Modifier.height(14.dp)
            )

            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                borderColor = Color.White.copy(alpha = 0.1f)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text("🛡️ SOS Controller Protocol", color = Red, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("• Auto-SOS Countdown: 10 Seconds", color = WhiteSoft.copy(alpha = 0.8f), fontSize = 12.sp)
                    Text("• Location Broadcast: GPS Coordinates Attached", color = WhiteSoft.copy(alpha = 0.8f), fontSize = 12.sp)
                    Text("• Status: Ready for Emergency Dispatch", color = WhiteSoft.copy(alpha = 0.8f), fontSize = 12.sp)
                }
            }
        }
    }


    Spacer(
        modifier =
            Modifier.height(16.dp)
    )


    OutlinedButton(

        onClick = {

            if (
                profile.emergencyPhone.isNotBlank()
            ) {

                val uri =
                    Uri.parse(
                        "tel:${profile.emergencyPhone}"
                    )

                context.startActivity(

                    Intent(
                        Intent.ACTION_DIAL,
                        uri
                    )
                )
            }
        },

        modifier =
            Modifier.fillMaxWidth()

    ) {

        Text(
            "CALL EMERGENCY CONTACT"
        )
    }
}


// ============================================================
// SETTINGS PAGE
// ============================================================

@Composable
private fun SettingsPage(

    onBack: () -> Unit,

    onOpenProfile: () -> Unit,

    onReset: () -> Unit

) {

    GlassCard(
        modifier =
            Modifier.fillMaxWidth()
    ) {

        Column(
            Modifier.padding(20.dp)
        ) {

            Text(

                text =
                    "⚙️ App Settings & Diagnostics",

                color =
                    Blue,

                fontSize = 22.sp,

                fontWeight =
                    FontWeight.Bold
            )


            Spacer(
                modifier =
                    Modifier.height(14.dp)
            )


            Text(

                text =
                    "SVM-AEGIS Pro v1.0",

                color =
                    WhiteSoft,

                fontSize = 18.sp
            )


            Text(

                text =
                    "AI Accident Protection & Telemetry Suite",

                color =
                    WhiteSoft.copy(
                        alpha = .7f
                    )
            )


            Spacer(
                modifier =
                    Modifier.height(16.dp)
            )

            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                borderColor = Color.White.copy(alpha = 0.1f)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text("🛠️ System Configuration", color = Blue, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("• ONNX Model Engine: Active (v3.2)", color = WhiteSoft.copy(alpha = 0.8f), fontSize = 12.sp)
                    Text("• IMU Sensor Calibration: Calibrated", color = WhiteSoft.copy(alpha = 0.8f), fontSize = 12.sp)
                    Text("• Hazard Alert Audio/Vibration: Enabled", color = WhiteSoft.copy(alpha = 0.8f), fontSize = 12.sp)
                    Text("• Background Service: Running", color = WhiteSoft.copy(alpha = 0.8f), fontSize = 12.sp)
                }
            }
        }
    }


    Spacer(
        modifier =
            Modifier.height(16.dp)
    )


    Button(

        onClick =
            onOpenProfile,

        modifier =
            Modifier.fillMaxWidth()

    ) {

        Text(
            "RIDER PROFILE"
        )
    }


    Spacer(
        modifier =
            Modifier.height(10.dp)
    )


    OutlinedButton(

        onClick =
            onReset,

        modifier =
            Modifier.fillMaxWidth()

    ) {

        Text(
            "RESET DETECTION"
        )
    }


    Spacer(
        modifier =
            Modifier.height(10.dp)
    )


    TextButton(

        onClick =
            onBack,

        modifier =
            Modifier.fillMaxWidth()

    ) {

        Text(
            "BACK TO HOME"
        )
    }
}


// ============================================================
// SENSOR VALUE CARD
// ============================================================

@Composable
private fun SensorValueCard(

    title: String,

    value: String,

    accent: Color

) {

    GlassCard(

        modifier =
            Modifier.fillMaxWidth(),

        borderColor =
            accent.copy(
                alpha = .55f
            )

    ) {

        Column(
            Modifier.padding(18.dp)
        ) {

            Text(

                text =
                    title,

                color =
                    accent,

                fontSize = 19.sp,

                fontWeight =
                    FontWeight.Bold
            )


            Spacer(
                modifier =
                    Modifier.height(8.dp)
            )


            Text(

                text =
                    value,

                color =
                    WhiteSoft,

                fontSize = 17.sp
            )
        }
    }
}


// ============================================================
// MINI STATUS
// ============================================================

@Composable
private fun StatusMini(

    icon: String,

    label: String,

    value: String,

    color: Color

) {

    Column(

        horizontalAlignment =
            Alignment.CenterHorizontally

    ) {

        Text(

            text =
                icon,

            color =
                color,

            fontSize = 17.sp
        )


        Text(

            text =
                label,

            color =
                WhiteSoft.copy(
                    alpha = .65f
                ),

            fontSize = 9.sp
        )


        Text(

            text =
                value,

            color =
                color,

            fontSize = 12.sp,

            fontWeight =
                FontWeight.Bold
        )
    }
}


// ============================================================
// GLASS CARD
// ============================================================

@Composable
private fun GlassCard(

    modifier: Modifier = Modifier,

    radius: androidx.compose.ui.unit.Dp = 20.dp,

    borderColor: Color =
        Color.White.copy(
            alpha = .18f
        ),

    content: @Composable () -> Unit

) {

    Card(

        modifier =
            modifier,

        shape =
            RoundedCornerShape(
                radius
            ),

        colors =
            CardDefaults.cardColors(
                containerColor =
                    Glass
            ),

        border =
            androidx.compose.foundation.BorderStroke(
                1.dp,
                borderColor
            ),

        elevation =
            CardDefaults.cardElevation(
                0.dp
            )

    ) {

        content()
    }
}


// ============================================================
// PROFILE DIALOG
// ============================================================

@Composable
private fun ProfileDialog(

    existingProfile: PersonalProfile,

    onDismiss: () -> Unit,

    onSave: (PersonalProfile) -> Unit

) {

    var name by remember {
        mutableStateOf(
            existingProfile.name
        )
    }

    var phone by remember {
        mutableStateOf(
            existingProfile.phone
        )
    }

    var bloodGroup by remember {
        mutableStateOf(
            existingProfile.bloodGroup
        )
    }

    var emergencyName by remember {
        mutableStateOf(
            existingProfile.emergencyName
        )
    }

    var emergencyPhone by remember {
        mutableStateOf(
            existingProfile.emergencyPhone
        )
    }

    var address by remember {
        mutableStateOf(
            existingProfile.address
        )
    }


    AlertDialog(

        onDismissRequest =
            onDismiss,

        title = {

            Text(
                "🛡️ Personal Safety Profile"
            )
        },

        text = {

            Column(

                modifier =
                    Modifier
                        .fillMaxWidth()
                        .verticalScroll(
                            rememberScrollState()
                        )

            ) {

                ProfileField(
                    label = "Name",
                    value = name
                ) {
                    name = it
                }


                ProfileField(
                    label = "Phone number",
                    value = phone
                ) {
                    phone = it
                }


                ProfileField(
                    label = "Blood group",
                    value = bloodGroup
                ) {
                    bloodGroup = it
                }


                ProfileField(
                    label = "Emergency contact name",
                    value = emergencyName
                ) {
                    emergencyName = it
                }


                ProfileField(
                    label = "Emergency contact phone",
                    value = emergencyPhone
                ) {
                    emergencyPhone = it
                }


                OutlinedTextField(

                    value =
                        address,

                    onValueChange = {
                        address = it
                    },

                    label = {
                        Text(
                            "Home address"
                        )
                    },

                    modifier =
                        Modifier.fillMaxWidth(),

                    minLines = 2,

                    maxLines = 4
                )
            }
        },

        confirmButton = {

            TextButton(

                onClick = {

                    onSave(

                        PersonalProfile(

                            name.trim(),

                            phone.trim(),

                            bloodGroup.trim(),

                            emergencyName.trim(),

                            emergencyPhone.trim(),

                            address.trim()
                        )
                    )
                }

            ) {

                Text(
                    "SAVE",
                    fontWeight =
                        FontWeight.Bold
                )
            }
        },

        dismissButton = {

            TextButton(
                onClick =
                    onDismiss
            ) {

                Text(
                    "CANCEL"
                )
            }
        }
    )
}


// ============================================================
// PROFILE FIELD
// ============================================================

@Composable
private fun ProfileField(

    label: String,

    value: String,

    onChange: (String) -> Unit

) {

    OutlinedTextField(

        value =
            value,

        onValueChange =
            onChange,

        label = {
            Text(label)
        },

        modifier =
            Modifier
                .fillMaxWidth()
                .padding(
                    bottom = 8.dp
                ),

        singleLine = true
    )
}


// ============================================================
// WEATHER EMOJI
// ============================================================

private fun weatherEmoji(

    code: Int,

    isDay: Boolean

): String {

    return when (code) {

        0 ->
            if (isDay)
                "☀️"
            else
                "🌙"

        1, 2 ->
            "🌤️"

        3 ->
            "☁️"

        45, 48 ->
            "🌫️"

        51, 53, 55, 56, 57 ->
            "🌦️"

        61, 63, 65, 66, 67, 80, 81, 82 ->
            "🌧️"

        71, 73, 75, 77, 85, 86 ->
            "❄️"

        95, 96, 99 ->
            "⛈️"

        else ->
            "🌤️"
    }
}
