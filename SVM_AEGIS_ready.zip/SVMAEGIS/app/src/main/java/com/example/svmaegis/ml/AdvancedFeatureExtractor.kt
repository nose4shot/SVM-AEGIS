package com.example.svmaegis.ml

import com.example.svmaegis.data.SensorFrame
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.sqrt

data class AdvancedFeatures(
    val accelerationMagnitude: Float,
    val gyroMagnitude: Float,
    val accelerationChange: Float,
    val gyroChange: Float,
    val jerk: Float,
    val speedChange: Float,
    val tiltAngle: Float,
    val orientationChange: Float,
    val vibration: Float,
    val pulseRate: Float?,
    val pulseChange: Float?,
    val sensorConfidence: Float
)

class AdvancedFeatureExtractor {

    private var previousFrame: SensorFrame? = null

    private var previousAccelerationMagnitude: Float? = null
    private var previousGyroMagnitude: Float? = null
    private var previousSpeed: Float? = null
    private var previousTilt: Float? = null
    private var previousPulseRate: Float? = null

    fun extract(
        frame: SensorFrame,
        pulseRate: Float? = null
    ): AdvancedFeatures {

        val accelerationMagnitude =
            frame.accelerationMagnitude

        val gyroMagnitude =
            frame.gyroscopeMagnitude

        /*
         * ---------------------------------------------------------
         * TIME DIFFERENCE
         * ---------------------------------------------------------
         */

        val deltaTime =
            calculateDeltaTime(frame)

        /*
         * ---------------------------------------------------------
         * ACCELERATION CHANGE
         * ---------------------------------------------------------
         */

        val accelerationChange =
            previousAccelerationMagnitude?.let {
                abs(
                    accelerationMagnitude - it
                )
            } ?: 0f

        /*
         * ---------------------------------------------------------
         * GYROSCOPE CHANGE
         * ---------------------------------------------------------
         */

        val gyroChange =
            previousGyroMagnitude?.let {
                abs(
                    gyroMagnitude - it
                )
            } ?: 0f

        /*
         * ---------------------------------------------------------
         * JERK
         * ---------------------------------------------------------
         *
         * Jerk = rate of change of acceleration.
         */

        val jerk =
            if (deltaTime > 0f) {
                accelerationChange / deltaTime
            } else {
                0f
            }

        /*
         * ---------------------------------------------------------
         * SPEED CHANGE
         * ---------------------------------------------------------
         */

        val speedChange =
            previousSpeed?.let {
                abs(
                    frame.speedKmh - it
                )
            } ?: 0f

        /*
         * ---------------------------------------------------------
         * TILT ANGLE
         * ---------------------------------------------------------
         */

        val tiltAngle =
            calculateTilt(
                frame.accX,
                frame.accY,
                frame.accZ
            )

        /*
         * ---------------------------------------------------------
         * ORIENTATION CHANGE
         * ---------------------------------------------------------
         */

        val orientationChange =
            previousTilt?.let {
                abs(
                    tiltAngle - it
                )
            } ?: 0f

        /*
         * ---------------------------------------------------------
         * VIBRATION
         * ---------------------------------------------------------
         */

        val vibration =
            frame.vibration ?: 0f

        /*
         * ---------------------------------------------------------
         * PULSE RATE
         * ---------------------------------------------------------
         */

        val pulseChange =
            if (
                pulseRate != null &&
                previousPulseRate != null
            ) {
                abs(
                    pulseRate - previousPulseRate!!
                )
            } else {
                null
            }

        /*
         * ---------------------------------------------------------
         * SENSOR CONFIDENCE
         * ---------------------------------------------------------
         */

        val sensorConfidence =
            calculateSensorConfidence(frame)

        /*
         * ---------------------------------------------------------
         * UPDATE PREVIOUS VALUES
         * ---------------------------------------------------------
         */

        previousFrame =
            frame

        previousAccelerationMagnitude =
            accelerationMagnitude

        previousGyroMagnitude =
            gyroMagnitude

        previousSpeed =
            frame.speedKmh

        previousTilt =
            tiltAngle

        if (pulseRate != null) {
            previousPulseRate =
                pulseRate
        }

        /*
         * ---------------------------------------------------------
         * RETURN FEATURES
         * ---------------------------------------------------------
         */

        return AdvancedFeatures(

            accelerationMagnitude =
                accelerationMagnitude,

            gyroMagnitude =
                gyroMagnitude,

            accelerationChange =
                accelerationChange,

            gyroChange =
                gyroChange,

            jerk =
                jerk,

            speedChange =
                speedChange,

            tiltAngle =
                tiltAngle,

            orientationChange =
                orientationChange,

            vibration =
                vibration,

            pulseRate =
                pulseRate,

            pulseChange =
                pulseChange,

            sensorConfidence =
                sensorConfidence
        )
    }

    /*
     * -------------------------------------------------------------
     * CALCULATE TILT
     * -------------------------------------------------------------
     */

    private fun calculateTilt(
        x: Float,
        y: Float,
        z: Float
    ): Float {

        return Math.toDegrees(
            atan2(
                sqrt(
                    x * x +
                            y * y
                ).toDouble(),
                z.toDouble()
            )
        ).toFloat()
    }

    /*
     * -------------------------------------------------------------
     * CALCULATE TIME BETWEEN SENSOR FRAMES
     * -------------------------------------------------------------
     */

    private fun calculateDeltaTime(
        frame: SensorFrame
    ): Float {

        val previous =
            previousFrame
                ?: return 0.1f

        val deltaMillis =
            frame.timestampMillis -
                    previous.timestampMillis

        return (
                deltaMillis
                    .coerceAtLeast(1L)
                        / 1000f
                )
    }

    /*
     * -------------------------------------------------------------
     * SENSOR CONFIDENCE
     * -------------------------------------------------------------
     *
     * This is a basic quality indicator.
     *
     * It is NOT a scientifically validated confidence score.
     */

    private fun calculateSensorConfidence(
        frame: SensorFrame
    ): Float {

        var confidence =
            0.0f

        /*
         * Accelerometer available
         */
        if (
            frame.accelerationMagnitude
                .isFinite()
        ) {
            confidence += 0.25f
        }

        /*
         * Gyroscope available
         */
        if (
            frame.gyroscopeMagnitude
                .isFinite()
        ) {
            confidence += 0.25f
        }

        /*
         * Speed available
         */
        if (
            frame.speedKmh.isFinite() &&
            frame.speedKmh >= 0f
        ) {
            confidence += 0.15f
        }

        /*
         * GPS available
         */
        if (
            frame.latitude.isFinite() &&
            frame.longitude.isFinite() &&
            (
                    frame.latitude != 0.0 ||
                            frame.longitude != 0.0
                    )
        ) {
            confidence += 0.15f
        }

        /*
         * External vibration sensor
         */
        if (
            frame.vibration != null &&
            frame.vibration.isFinite()
        ) {
            confidence += 0.10f
        }

        /*
         * External temperature sensor
         */
        if (
            frame.temperatureCelsius != null &&
            frame.temperatureCelsius.isFinite()
        ) {
            confidence += 0.10f
        }

        return confidence.coerceIn(
            0f,
            1f
        )
    }

    /*
     * -------------------------------------------------------------
     * RESET
     * -------------------------------------------------------------
     */

    fun reset() {

        previousFrame =
            null

        previousAccelerationMagnitude =
            null

        previousGyroMagnitude =
            null

        previousSpeed =
            null

        previousTilt =
            null

        previousPulseRate =
            null
    }
}