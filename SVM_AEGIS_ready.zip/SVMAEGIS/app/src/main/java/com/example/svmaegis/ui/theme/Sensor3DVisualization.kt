package com.example.svmaegis.ui.theme

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

private data class Point3D(
    val x: Float,
    val y: Float,
    val z: Float
)

private data class Point2D(
    val x: Float,
    val y: Float,
    val depth: Float
)

private fun rotatePoint(
    point: Point3D,
    pitch: Float,
    yaw: Float,
    roll: Float
): Point3D {

    var x = point.x
    var y = point.y
    var z = point.z

    val cp = cos(pitch)
    val sp = sin(pitch)

    val y1 = y * cp - z * sp
    val z1 = y * sp + z * cp

    y = y1
    z = z1

    val cy = cos(yaw)
    val sy = sin(yaw)

    val x2 = x * cy + z * sy
    val z2 = -x * sy + z * cy

    x = x2
    z = z2

    val cr = cos(roll)
    val sr = sin(roll)

    val x3 = x * cr - y * sr
    val y3 = x * sr + y * cr

    x = x3
    y = y3

    return Point3D(x, y, z)
}

private fun projectPoint(
    point: Point3D,
    center: Offset,
    scale: Float
): Point2D {

    val camera = 700f

    val perspective =
        camera / (camera + point.z)

    return Point2D(
        center.x + point.x * scale * perspective,
        center.y + point.y * scale * perspective,
        perspective
    )
}

private fun DrawScope.draw3DLine(
    start: Point3D,
    end: Point3D,
    center: Offset,
    scale: Float,
    pitch: Float,
    yaw: Float,
    roll: Float,
    color: Color,
    width: Float
) {

    val p1 = projectPoint(
        rotatePoint(start, pitch, yaw, roll),
        center,
        scale
    )

    val p2 = projectPoint(
        rotatePoint(end, pitch, yaw, roll),
        center,
        scale
    )

    drawLine(
        color = color,
        start = Offset(p1.x, p1.y),
        end = Offset(p2.x, p2.y),
        strokeWidth = width
    )
}

private fun DrawScope.draw3DCircle(
    point: Point3D,
    radius: Float,
    center: Offset,
    scale: Float,
    pitch: Float,
    yaw: Float,
    roll: Float,
    color: Color
) {

    val rotated = rotatePoint(
        point,
        pitch,
        yaw,
        roll
    )

    val projected = projectPoint(
        rotated,
        center,
        scale
    )

    drawCircle(
        color = color,
        radius = radius * scale * projected.depth,
        center = Offset(
            projected.x,
            projected.y
        )
    )
}

private fun DrawScope.drawAxis(
    start: Point3D,
    end: Point3D,
    label: String,
    center: Offset,
    scale: Float,
    pitch: Float,
    yaw: Float,
    roll: Float,
    color: Color
) {

    draw3DLine(
        start = start,
        end = end,
        center = center,
        scale = scale,
        pitch = pitch,
        yaw = yaw,
        roll = roll,
        color = color,
        width = 5f
    )

    val rotatedEnd = rotatePoint(
        end,
        pitch,
        yaw,
        roll
    )

    val projected = projectPoint(
        rotatedEnd,
        center,
        scale
    )

    drawCircle(
        color = color,
        radius = 8f,
        center = Offset(
            projected.x,
            projected.y
        )
    )
}

private fun DrawScope.drawPhone(
    center: Offset,
    scale: Float,
    pitch: Float,
    yaw: Float,
    roll: Float
) {

    val phone = listOf(
        Point3D(-0.65f, -1.25f, 0f),
        Point3D(0.65f, -1.25f, 0f),
        Point3D(0.65f, 1.25f, 0f),
        Point3D(-0.65f, 1.25f, 0f)
    )

    val projected = phone.map {
        projectPoint(
            rotatePoint(
                it,
                pitch,
                yaw,
                roll
            ),
            center,
            scale
        )
    }

    val path = Path()

    path.moveTo(
        projected[0].x,
        projected[0].y
    )

    projected.drop(1).forEach {
        path.lineTo(
            it.x,
            it.y
        )
    }

    path.close()

    drawPath(
        path = path,
        color = Color(0xFF24272E)
    )

    val screen = listOf(
        Point3D(-0.50f, -0.90f, -0.03f),
        Point3D(0.50f, -0.90f, -0.03f),
        Point3D(0.50f, 0.70f, -0.03f),
        Point3D(-0.50f, 0.70f, -0.03f)
    )

    val screenProjected = screen.map {
        projectPoint(
            rotatePoint(
                it,
                pitch,
                yaw,
                roll
            ),
            center,
            scale
        )
    }

    val screenPath = Path()

    screenPath.moveTo(
        screenProjected[0].x,
        screenProjected[0].y
    )

    screenProjected.drop(1).forEach {
        screenPath.lineTo(
            it.x,
            it.y
        )
    }

    screenPath.close()

    drawPath(
        path = screenPath,
        color = Color(0xFF9BE7FF)
    )

    drawCircle(
        color = Color.White,
        radius = 4f,
        center = Offset(
            projected[0].x,
            projected[0].y
        )
    )
}

private fun DrawScope.drawHuman(
    center: Offset,
    scale: Float,
    pitch: Float,
    yaw: Float,
    roll: Float
) {

    val head = Point3D(
        0f,
        -3.0f,
        0f
    )

    draw3DCircle(
        point = head,
        radius = 0.55f,
        center = center,
        scale = scale,
        pitch = pitch,
        yaw = yaw,
        roll = roll,
        color = Color(0xFFE5E7EB)
    )

    val neck = Point3D(
        0f,
        -2.35f,
        0f
    )

    val shoulderLeft = Point3D(
        -0.75f,
        -2.05f,
        0f
    )

    val shoulderRight = Point3D(
        0.75f,
        -2.05f,
        0f
    )

    val chest = Point3D(
        0f,
        -1.55f,
        0f
    )

    val waist = Point3D(
        0f,
        -0.40f,
        0f
    )

    val hipLeft = Point3D(
        -0.45f,
        -0.20f,
        0f
    )

    val hipRight = Point3D(
        0.45f,
        -0.20f,
        0f
    )

    val elbowLeft = Point3D(
        -1.15f,
        -1.15f,
        0.1f
    )

    val handLeft = Point3D(
        -1.45f,
        -0.40f,
        0.1f
    )

    val elbowRight = Point3D(
        1.10f,
        -1.30f,
        -0.1f
    )

    val handRight = Point3D(
        1.35f,
        -0.65f,
        -0.1f
    )

    val kneeLeft = Point3D(
        -0.35f,
        1.10f,
        0f
    )

    val kneeRight = Point3D(
        0.35f,
        1.10f,
        0f
    )

    val footLeft = Point3D(
        -0.45f,
        2.25f,
        0.15f
    )

    val footRight = Point3D(
        0.45f,
        2.25f,
        0.15f
    )

    val bodyColor = Color(0xFFD9DCE1)

    draw3DLine(
        neck,
        chest,
        center,
        scale,
        pitch,
        yaw,
        roll,
        bodyColor,
        35f
    )

    draw3DLine(
        shoulderLeft,
        shoulderRight,
        center,
        scale,
        pitch,
        yaw,
        roll,
        bodyColor,
        38f
    )

    draw3DLine(
        chest,
        waist,
        center,
        scale,
        pitch,
        yaw,
        roll,
        bodyColor,
        55f
    )

    draw3DLine(
        hipLeft,
        hipRight,
        center,
        scale,
        pitch,
        yaw,
        roll,
        bodyColor,
        42f
    )

    draw3DLine(
        shoulderLeft,
        elbowLeft,
        center,
        scale,
        pitch,
        yaw,
        roll,
        bodyColor,
        30f
    )

    draw3DLine(
        elbowLeft,
        handLeft,
        center,
        scale,
        pitch,
        yaw,
        roll,
        bodyColor,
        27f
    )

    draw3DLine(
        shoulderRight,
        elbowRight,
        center,
        scale,
        pitch,
        yaw,
        roll,
        bodyColor,
        30f
    )

    draw3DLine(
        elbowRight,
        handRight,
        center,
        scale,
        pitch,
        yaw,
        roll,
        bodyColor,
        27f
    )

    draw3DLine(
        hipLeft,
        kneeLeft,
        center,
        scale,
        pitch,
        yaw,
        roll,
        bodyColor,
        38f
    )

    draw3DLine(
        kneeLeft,
        footLeft,
        center,
        scale,
        pitch,
        yaw,
        roll,
        bodyColor,
        34f
    )

    draw3DLine(
        hipRight,
        kneeRight,
        center,
        scale,
        pitch,
        yaw,
        roll,
        bodyColor,
        38f
    )

    draw3DLine(
        kneeRight,
        footRight,
        center,
        scale,
        pitch,
        yaw,
        roll,
        bodyColor,
        34f
    )

    draw3DCircle(
        head,
        0.55f,
        center,
        scale,
        pitch,
        yaw,
        roll,
        bodyColor
    )

    draw3DCircle(
        handLeft,
        0.25f,
        center,
        scale,
        pitch,
        yaw,
        roll,
        bodyColor
    )

    draw3DCircle(
        handRight,
        0.25f,
        center,
        scale,
        pitch,
        yaw,
        roll,
        bodyColor
    )

    draw3DCircle(
        footLeft,
        0.28f,
        center,
        scale,
        pitch,
        yaw,
        roll,
        bodyColor
    )

    draw3DCircle(
        footRight,
        0.28f,
        center,
        scale,
        pitch,
        yaw,
        roll,
        bodyColor
    )

    drawPhone(
        center = Offset(
            center.x + 85f,
            center.y - 20f
        ),
        scale = scale * 0.65f,
        pitch = pitch,
        yaw = yaw,
        roll = roll
    )
}

@Composable
fun Accelerometer3DView(
    ax: Float,
    ay: Float,
    az: Float,
    modifier: Modifier = Modifier
) {

    val magnitude = sqrt(
        ax * ax +
                ay * ay +
                az * az
    )

    val pitch = (ay * 0.035f).coerceIn(
        -1.0f,
        1.0f
    )

    val roll = (ax * 0.035f).coerceIn(
        -1.0f,
        1.0f
    )

    val yaw = ((az - 9.81f) * 0.015f)
        .coerceIn(-0.6f, 0.6f)

    Box(
        modifier = modifier
            .background(
                Color(0xFF101318),
                RoundedCornerShape(24.dp)
            )
    ) {

        Canvas(
            modifier = Modifier.fillMaxSize()
        ) {

            val center = Offset(
                size.width * 0.45f,
                size.height * 0.54f
            )

            drawHuman(
                center = center,
                scale = minOf(
                    size.width,
                    size.height
                ) / 190f,
                pitch = pitch,
                yaw = yaw,
                roll = roll
            )

            drawAxis(
                start = Point3D(0f, 0f, 0f),
                end = Point3D(2.0f, 0f, 0f),
                label = "X",
                center = center,
                scale = 45f,
                pitch = pitch,
                yaw = yaw,
                roll = roll,
                color = Color(0xFFFF5252)
            )

            drawAxis(
                start = Point3D(0f, 0f, 0f),
                end = Point3D(0f, -2.0f, 0f),
                label = "Y",
                center = center,
                scale = 45f,
                pitch = pitch,
                yaw = yaw,
                roll = roll,
                color = Color(0xFF69F0AE)
            )

            drawAxis(
                start = Point3D(0f, 0f, 0f),
                end = Point3D(0f, 0f, 2.0f),
                label = "Z",
                center = center,
                scale = 45f,
                pitch = pitch,
                yaw = yaw,
                roll = roll,
                color = Color(0xFF40C4FF)
            )
        }

        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(16.dp)
        ) {

            Text(
                text = "3D ACCELEROMETER",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "Live motion visualization",
                color = Color.LightGray,
                fontSize = 12.sp
            )
        }

        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp)
        ) {

            Text(
                text = "X  ${"%.2f".format(ax)} m/s²",
                color = Color(0xFFFF5252),
                fontSize = 13.sp
            )

            Text(
                text = "Y  ${"%.2f".format(ay)} m/s²",
                color = Color(0xFF69F0AE),
                fontSize = 13.sp
            )

            Text(
                text = "Z  ${"%.2f".format(az)} m/s²",
                color = Color(0xFF40C4FF),
                fontSize = 13.sp
            )

            Text(
                text = "|A|  ${"%.2f".format(magnitude)} m/s²",
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun Gyroscope3DView(
    gx: Float,
    gy: Float,
    gz: Float,
    modifier: Modifier = Modifier
) {

    var pitch by remember {
        mutableFloatStateOf(0f)
    }

    var yaw by remember {
        mutableFloatStateOf(0f)
    }

    var roll by remember {
        mutableFloatStateOf(0f)
    }

    LaunchedEffect(
        gx,
        gy,
        gz
    ) {

        while (true) {

            val dt = 0.016f

            pitch += gx * dt
            yaw += gy * dt
            roll += gz * dt

            pitch *= 0.995f
            yaw *= 0.995f
            roll *= 0.995f

            delay(16)
        }
    }

    val magnitude = sqrt(
        gx * gx +
                gy * gy +
                gz * gz
    )

    Box(
        modifier = modifier
            .background(
                Color(0xFF101318),
                RoundedCornerShape(24.dp)
            )
    ) {

        Canvas(
            modifier = Modifier.fillMaxSize()
        ) {

            val center = Offset(
                size.width * 0.45f,
                size.height * 0.54f
            )

            drawHuman(
                center = center,
                scale = minOf(
                    size.width,
                    size.height
                ) / 190f,
                pitch = pitch,
                yaw = yaw,
                roll = roll
            )

            drawAxis(
                start = Point3D(0f, 0f, 0f),
                end = Point3D(2.0f, 0f, 0f),
                label = "X",
                center = center,
                scale = 45f,
                pitch = pitch,
                yaw = yaw,
                roll = roll,
                color = Color(0xFFFF5252)
            )

            drawAxis(
                start = Point3D(0f, 0f, 0f),
                end = Point3D(0f, -2.0f, 0f),
                label = "Y",
                center = center,
                scale = 45f,
                pitch = pitch,
                yaw = yaw,
                roll = roll,
                color = Color(0xFF69F0AE)
            )

            drawAxis(
                start = Point3D(0f, 0f, 0f),
                end = Point3D(0f, 0f, 2.0f),
                label = "Z",
                center = center,
                scale = 45f,
                pitch = pitch,
                yaw = yaw,
                roll = roll,
                color = Color(0xFF40C4FF)
            )
        }

        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(16.dp)
        ) {

            Text(
                text = "3D GYROSCOPE",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "Live rotation visualization",
                color = Color.LightGray,
                fontSize = 12.sp
            )
        }

        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp)
        ) {

            Text(
                text = "GX  ${"%.2f".format(gx)} rad/s",
                color = Color(0xFFFF5252),
                fontSize = 13.sp
            )

            Text(
                text = "GY  ${"%.2f".format(gy)} rad/s",
                color = Color(0xFF69F0AE),
                fontSize = 13.sp
            )

            Text(
                text = "GZ  ${"%.2f".format(gz)} rad/s",
                color = Color(0xFF40C4FF),
                fontSize = 13.sp
            )

            Text(
                text = "|G|  ${"%.2f".format(magnitude)} rad/s",
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}