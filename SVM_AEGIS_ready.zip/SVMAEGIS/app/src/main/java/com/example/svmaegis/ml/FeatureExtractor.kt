package com.example.svmaegis.ml

import com.example.svmaegis.data.SensorFrame

object FeatureExtractor {

    const val FEATURE_COUNT = 8

    /*
     * MUST remain identical to training/deployment order:
     * 1 Acc_X
     * 2 Acc_Y
     * 3 Acc_Z
     * 4 Gyro_X
     * 5 Gyro_Y
     * 6 Gyro_Z
     * 7 Speed_kmh
     * 8 Acc_Magnitude
     */
    fun extract(frame: SensorFrame): FloatArray {
        return floatArrayOf(
            frame.accX,
            frame.accY,
            frame.accZ,
            frame.gyroX,
            frame.gyroY,
            frame.gyroZ,
            frame.speedKmh,
            frame.accelerationMagnitude
        )
    }

    fun extract(
        accX: Float,
        accY: Float,
        accZ: Float,
        gyroX: Float,
        gyroY: Float,
        gyroZ: Float,
        speedKmh: Float
    ): FloatArray {
        val magnitude =
            kotlin.math.sqrt(
                accX * accX +
                        accY * accY +
                        accZ * accZ
            )

        return floatArrayOf(
            accX,
            accY,
            accZ,
            gyroX,
            gyroY,
            gyroZ,
            speedKmh,
            magnitude
        )
    }
}
