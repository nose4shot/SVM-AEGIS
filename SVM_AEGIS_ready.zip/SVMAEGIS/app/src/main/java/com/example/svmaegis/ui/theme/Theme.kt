package com.example.svmaegis.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val AegisColorScheme = darkColorScheme(
    primary = AegisBlue,
    secondary = AegisCyan,
    tertiary = AegisGreen,
    background = AegisDark,
    surface = AegisCard
)

@Composable
fun SVMAEGISTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = AegisColorScheme,
        content = content
    )
}
