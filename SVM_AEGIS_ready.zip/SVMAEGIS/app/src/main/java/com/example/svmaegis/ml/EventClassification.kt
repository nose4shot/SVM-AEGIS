package com.example.svmaegis.ml

enum class EventType {
    NORMAL,
    RUNNING,
    JUMP,
    POTHOLE,
    HARD_BRAKING,
    LIGHT_FALL,
    NEAR_MISS,
    POSSIBLE_ACCIDENT
}

data class EventClassificationResult(
    val eventType: EventType,
    val confidence: Float,
    val reason: String
)

class EventClassifier {

    companion object {
        private const val LOW_ACCELERATION = 0.35f
        private const val MODERATE_ACCELERATION = 1.5f
        private const val HIGH_ACCELERATION = 3.0f
        private const val VERY_HIGH_ACCELERATION = 5.0f

        private const val LOW_GYRO_CHANGE = 0.30f
        private const val MODERATE_GYRO_CHANGE = 0.80f
        private const val HIGH_GYRO_CHANGE = 1.50f

        private const val JUMP_JERK_THRESHOLD = 12.0f
        private const val STRONG_JERK_THRESHOLD = 20.0f

        private const val ORIENTATION_CHANGE_THRESHOLD = 15.0f

        private const val VIBRATION_THRESHOLD = 1.5f
    }

    fun classify(
        features: AdvancedFeatures,
        mlProbability: Float
    ): EventClassificationResult {

        val probability = mlProbability.coerceIn(0f, 1f)

        val accelerationChange = features.accelerationChange
        val gyroChange = features.gyroChange
        val jerk = features.jerk
        val speedChange = features.speedChange
        val orientationChange = features.orientationChange
        val accelerationMagnitude = features.accelerationMagnitude
        val vibration = features.vibration

        /*
         * 1. Normal movement
         */
        if (
            accelerationChange <= LOW_ACCELERATION &&
            gyroChange <= LOW_GYRO_CHANGE &&
            jerk < JUMP_JERK_THRESHOLD &&
            orientationChange < ORIENTATION_CHANGE_THRESHOLD
        ) {
            return EventClassificationResult(
                eventType = EventType.NORMAL,
                confidence = 0.90f,
                reason = "Stable sensor movement"
            )
        }

        /*
         * 2. Running / strong repeated body movement
         */
        if (
            accelerationChange in MODERATE_ACCELERATION..HIGH_ACCELERATION &&
            gyroChange in MODERATE_GYRO_CHANGE..HIGH_GYRO_CHANGE &&
            jerk >= JUMP_JERK_THRESHOLD &&
            jerk < STRONG_JERK_THRESHOLD &&
            vibration < VIBRATION_THRESHOLD &&
            probability < 0.70f
        ) {
            return EventClassificationResult(
                eventType = EventType.RUNNING,
                confidence = 0.72f,
                reason = "Repeated moderate acceleration and rotational movement"
            )
        }

        /*
         * 3. Jump
         */
        if (
            jerk >= JUMP_JERK_THRESHOLD &&
            accelerationChange >= MODERATE_ACCELERATION &&
            orientationChange < ORIENTATION_CHANGE_THRESHOLD &&
            probability < 0.75f
        ) {
            return EventClassificationResult(
                eventType = EventType.JUMP,
                confidence = 0.76f,
                reason = "Rapid vertical-style acceleration change detected"
            )
        }

        /*
         * 4. Pothole / dent / rough road impact
         */
        if (
            accelerationChange >= MODERATE_ACCELERATION &&
            accelerationChange < VERY_HIGH_ACCELERATION &&
            vibration >= VIBRATION_THRESHOLD &&
            gyroChange < HIGH_GYRO_CHANGE &&
            probability < 0.75f
        ) {
            return EventClassificationResult(
                eventType = EventType.POTHOLE,
                confidence = 0.78f,
                reason = "Short impact with vibration and limited rotational change"
            )
        }

        /*
         * 5. Hard braking
         */
        if (
            speedChange >= 8.0f &&
            accelerationChange >= MODERATE_ACCELERATION &&
            orientationChange < ORIENTATION_CHANGE_THRESHOLD &&
            probability < 0.80f
        ) {
            return EventClassificationResult(
                eventType = EventType.HARD_BRAKING,
                confidence = 0.82f,
                reason = "Large speed reduction with controlled orientation"
            )
        }

        /*
         * 6. Light fall
         */
        if (
            orientationChange >= ORIENTATION_CHANGE_THRESHOLD &&
            accelerationChange >= MODERATE_ACCELERATION &&
            accelerationChange < VERY_HIGH_ACCELERATION &&
            probability < 0.80f
        ) {
            return EventClassificationResult(
                eventType = EventType.LIGHT_FALL,
                confidence = 0.74f,
                reason = "Significant orientation change with moderate impact"
            )
        }

        /*
         * 7. Near miss
         */
        if (
            accelerationChange >= HIGH_ACCELERATION &&
            gyroChange >= MODERATE_GYRO_CHANGE &&
            probability >= 0.50f &&
            probability < 0.75f
        ) {
            return EventClassificationResult(
                eventType = EventType.NEAR_MISS,
                confidence = 0.80f,
                reason = "Strong maneuver detected without sufficient crash evidence"
            )
        }

        /*
         * 8. Possible accident
         */
        if (
            probability >= 0.70f ||
            accelerationChange >= VERY_HIGH_ACCELERATION ||
            gyroChange >= HIGH_GYRO_CHANGE ||
            jerk >= STRONG_JERK_THRESHOLD ||
            orientationChange >= ORIENTATION_CHANGE_THRESHOLD
        ) {
            val confidence = (
                    probability * 0.50f +
                            normalize(accelerationChange, 0f, 8f) * 0.20f +
                            normalize(gyroChange, 0f, 3f) * 0.15f +
                            normalize(jerk, 0f, 30f) * 0.10f +
                            normalize(orientationChange, 0f, 45f) * 0.05f
                    ).coerceIn(0f, 1f)

            return EventClassificationResult(
                eventType = EventType.POSSIBLE_ACCIDENT,
                confidence = confidence,
                reason = "Multiple strong accident-related signals detected"
            )
        }

        /*
         * 9. Default
         */
        return EventClassificationResult(
            eventType = EventType.NORMAL,
            confidence = 0.60f,
            reason = "No strong event pattern detected"
        )
    }

    private fun normalize(
        value: Float,
        minimum: Float,
        maximum: Float
    ): Float {
        if (maximum <= minimum) return 0f

        return ((value - minimum) / (maximum - minimum))
            .coerceIn(0f, 1f)
    }
}