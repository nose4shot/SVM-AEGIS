package com.example.svmaegis.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun Gyroscope3DDialog(
    gx: Float,
    gy: Float,
    gz: Float,
    onClose: () -> Unit
) {

    var rotationX by remember { mutableFloatStateOf(0f) }
    var rotationY by remember { mutableFloatStateOf(0f) }
    var rotationZ by remember { mutableFloatStateOf(0f) }

    /*
     * Gyroscope values are angular velocity.
     *
     * gx, gy, gz are normally radians/second.
     *
     * We integrate them over time:
     *
     * angle = angle + angularVelocity * deltaTime
     *
     * The multiplier controls visual sensitivity.
     */
    LaunchedEffect(Unit) {

        var lastTime = System.nanoTime()

        while (true) {

            val currentTime = System.nanoTime()

            val deltaTime =
                ((currentTime - lastTime) / 1_000_000_000f)
                    .coerceIn(0f, 0.05f)

            lastTime = currentTime

            /*
             * Convert radians to degrees.
             */
            val sensitivity = 57.29578f

            rotationX += gx * deltaTime * sensitivity
            rotationY += gy * deltaTime * sensitivity
            rotationZ += gz * deltaTime * sensitivity

            /*
             * Keep values inside a reasonable range.
             */
            rotationX %= 360f
            rotationY %= 360f
            rotationZ %= 360f

            delay(16L)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF06131A),
                        Color(0xFF081F2A),
                        Color(0xFF06131A)
                    )
                )
            )
    ) {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Text(
                text = "3D GYROSCOPE",
                color = Color(0xFF73CFFF),
                fontSize = 24.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Move your phone and watch the model rotate",
                color = Color.White.copy(alpha = 0.70f),
                fontSize = 13.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            /*
             * 3D MODEL
             *
             * The model now receives accumulated rotation,
             * so it follows the actual physical movement.
             */
            Sensor3DViewport(
                sensorX = rotationX,
                sensorY = rotationY,
                sensorZ = rotationZ,
                mode = "GYROSCOPE",
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            )

            Spacer(modifier = Modifier.height(14.dp))

            /*
             * LIVE GYROSCOPE VALUES
             */
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {

                SensorValueBox(
                    title = "GX",
                    value = gx,
                    color = Color(0xFFFF5A5A),
                    modifier = Modifier.weight(1f)
                )

                SensorValueBox(
                    title = "GY",
                    value = gy,
                    color = Color(0xFF55F28A),
                    modifier = Modifier.weight(1f)
                )

                SensorValueBox(
                    title = "GZ",
                    value = gz,
                    color = Color(0xFF55B7FF),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = onClose,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF1976D2)
                )
            ) {

                Text(
                    text = "CLOSE 3D VIEW",
                    fontSize = 15.sp
                )
            }
        }
    }
}

@Composable
private fun SensorValueBox(
    title: String,
    value: Float,
    color: Color,
    modifier: Modifier = Modifier
) {

    Box(
        modifier = modifier
            .background(
                color = Color.White.copy(alpha = 0.08f),
                shape = RoundedCornerShape(14.dp)
            )
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {

        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Text(
                text = title,
                color = color,
                fontSize = 13.sp
            )

            Text(
                text = "%.2f".format(value),
                color = Color.White,
                fontSize = 15.sp
            )
        }
    }
}