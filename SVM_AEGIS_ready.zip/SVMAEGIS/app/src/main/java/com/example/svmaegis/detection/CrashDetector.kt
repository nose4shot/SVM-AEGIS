package com.example.svmaegis.detection

import android.content.Context
import android.util.Log
import com.example.svmaegis.ml.AdvancedFeatures
import com.example.svmaegis.ml.EnsembleCrashDetector
import com.example.svmaegis.ml.EnsemblePrediction
import kotlin.math.atan2
import kotlin.math.sqrt

data class CrashDetectionResult(
    val ensemblePrediction: EnsemblePrediction,
    val temporalResult: TemporalResult,
    val reason: String = "Normal riding conditions - stable IMU telemetry"
) {

    val crashConfirmed: Boolean
        get() = temporalResult.crashConfirmed

    val status: TemporalStatus
        get() = temporalResult.status
}

class CrashDetector(
    context: Context
) {

    companion object {
        private const val TAG = "SVM_AEGIS"
    }

    private val ensembleDetector =
        EnsembleCrashDetector(context)

    private val temporalFilter =
        TemporalCrashFilter()

    init {

        Log.i(
            TAG,
            "========================================"
        )

        Log.i(
            TAG,
            "SVM-AEGIS Crash Detector initialized"
        )

        Log.i(
            TAG,
            "ML Models: SVM + Random Forest + XGBoost"
        )

        Log.i(
            TAG,
            "Temporal Crash Filter initialized"
        )

        Log.i(
            TAG,
            "========================================"
        )
    }

    /*
     * =============================================================
     * MAIN CRASH DETECTION
     * =============================================================
     *
     * ML MODEL INPUT:
     *
     * 1. AccX
     * 2. AccY
     * 3. AccZ
     * 4. GyroX
     * 5. GyroY
     * 6. GyroZ
     * 7. Speed
     * 8. Acceleration Magnitude
     *
     * AdvancedFeatures are NOT inserted into the existing ONNX
     * model input vector.
     *
     * They are used by TemporalCrashFilter for validation.
     */

    fun detectCrashWithTemporal(
        accX: Float,
        accY: Float,
        accZ: Float,
        gyroX: Float,
        gyroY: Float,
        gyroZ: Float,
        speedKmh: Float,
        advancedFeatures: AdvancedFeatures? = null
    ): CrashDetectionResult {

        /*
         * ---------------------------------------------------------
         * STEP 1
         * RUN ENSEMBLE MODEL
         * ---------------------------------------------------------
         */

        val prediction =
            ensembleDetector.predict(
                accX = accX,
                accY = accY,
                accZ = accZ,
                gyroX = gyroX,
                gyroY = gyroY,
                gyroZ = gyroZ,
                speedKmh = speedKmh
            )

        /*
         * ---------------------------------------------------------
         * STEP 2
         * GET ADVANCED FEATURES
         * ---------------------------------------------------------
         *
         * Normally DetectionEngine should provide these.
         *
         * If they are unavailable, a compatibility fallback is
         * generated.
         */

        val features =
            advancedFeatures
                ?: createFallbackFeatures(
                    accX = accX,
                    accY = accY,
                    accZ = accZ,
                    gyroX = gyroX,
                    gyroY = gyroY,
                    gyroZ = gyroZ,
                    speedKmh = speedKmh
                )

        /*
         * ---------------------------------------------------------
         * STEP 3
         * TEMPORAL VALIDATION
         * ---------------------------------------------------------
         */

        val temporalResult =
            temporalFilter.update(
                ensembleProbability =
                    prediction.ensembleCrashProbability,
                features = features
            )

        /*
         * ---------------------------------------------------------
         * STEP 4
         * LOG AI RESULTS
         * ---------------------------------------------------------
         */

        logDetection(
            prediction = prediction,
            features = features,
            temporalResult = temporalResult
        )

        /*
         * ---------------------------------------------------------
         * STEP 5
         * DETERMINE DECISION REASON
         * ---------------------------------------------------------
         */

        val reason = determineReason(
            probability = prediction.ensembleCrashProbability,
            confirmed = temporalResult.crashConfirmed,
            status = temporalResult.status,
            features = features,
            speedKmh = speedKmh
        )

        /*
         * ---------------------------------------------------------
         * STEP 6
         * RETURN RESULT
         * ---------------------------------------------------------
         */

        return CrashDetectionResult(
            ensemblePrediction = prediction,
            temporalResult = temporalResult,
            reason = reason
        )
    }

    private fun determineReason(
        probability: Float,
        confirmed: Boolean,
        status: TemporalStatus,
        features: AdvancedFeatures,
        speedKmh: Float
    ): String {
        if (confirmed || status == TemporalStatus.CRASH_CONFIRMED) {
            return "Critical impact detected: High G-force impact spike with sudden deceleration and immobility."
        }
        if (status == TemporalStatus.POSSIBLE_IMPACT || status == TemporalStatus.IMMOBILITY_CHECK) {
            return "Potential hazard: Abnormal acceleration change (${"%.1f".format(features.accelerationChange)} m/s²) - evaluating temporal impact pattern."
        }
        if (probability >= 0.5f) {
            return "Elevated AI risk score (${"%.1f".format(probability * 100)}%) - evaluating motion patterns."
        }

        return when {
            speedKmh < 1.0f && features.accelerationChange < 0.3f ->
                "Ideal condition: Vehicle stationary / parked securely. Zero movement detected."
            features.accelerationChange < 1.0f && features.gyroChange < 0.2f ->
                "Ideal condition: Steady cruising speed. Smooth ride dynamics, stable IMU telemetry."
            speedKmh > 5.0f && features.vibration < 0.5f ->
                "Ideal condition: Normal highway/road cruising. Vibration levels within safe limits."
            else ->
                "Normal riding conditions: Sensor readings stable, no impact anomalies detected."
        }
    }

    /*
     * =============================================================
     * COMPATIBILITY DETECTION API
     * =============================================================
     *
     * Keeps the older API available.
     */

    fun detectCrashWithTemporal(
        accX: Float,
        accY: Float,
        accZ: Float,
        gyroX: Float,
        gyroY: Float,
        gyroZ: Float,
        speedKmh: Float
    ): CrashDetectionResult {

        return detectCrashWithTemporal(
            accX = accX,
            accY = accY,
            accZ = accZ,
            gyroX = gyroX,
            gyroY = gyroY,
            gyroZ = gyroZ,
            speedKmh = speedKmh,
            advancedFeatures = null
        )
    }

    /*
     * =============================================================
     * SIMPLE DETECTION API
     * =============================================================
     */

    fun detectCrash(
        accX: Float,
        accY: Float,
        accZ: Float,
        gyroX: Float,
        gyroY: Float,
        gyroZ: Float,
        speedKmh: Float
    ): CrashDetectionResult {

        return detectCrashWithTemporal(
            accX = accX,
            accY = accY,
            accZ = accZ,
            gyroX = gyroX,
            gyroY = gyroY,
            gyroZ = gyroZ,
            speedKmh = speedKmh,
            advancedFeatures = null
        )
    }

    /*
     * =============================================================
     * DETECTION WITH ADVANCED FEATURES
     * =============================================================
     *
     * This API is preferred when AdvancedFeatureExtractor is
     * available.
     */

    fun detectCrash(
        accX: Float,
        accY: Float,
        accZ: Float,
        gyroX: Float,
        gyroY: Float,
        gyroZ: Float,
        speedKmh: Float,
        advancedFeatures: AdvancedFeatures
    ): CrashDetectionResult {

        return detectCrashWithTemporal(
            accX = accX,
            accY = accY,
            accZ = accZ,
            gyroX = gyroX,
            gyroY = gyroY,
            gyroZ = gyroZ,
            speedKmh = speedKmh,
            advancedFeatures = advancedFeatures
        )
    }

    /*
     * =============================================================
     * FALLBACK ADVANCED FEATURES
     * =============================================================
     *
     * Used only when AdvancedFeatureExtractor has not supplied
     * AdvancedFeatures.
     *
     * IMPORTANT:
     *
     * These values cannot reproduce temporal changes because this
     * method only receives the current sensor sample.
     *
     * Therefore accelerationChange, gyroChange, jerk,
     * speedChange and orientationChange remain zero here.
     *
     * The real production path should provide AdvancedFeatures
     * from AdvancedFeatureExtractor.
     */

    private fun createFallbackFeatures(
        accX: Float,
        accY: Float,
        accZ: Float,
        gyroX: Float,
        gyroY: Float,
        gyroZ: Float,
        speedKmh: Float
    ): AdvancedFeatures {

        /*
         * ---------------------------------------------------------
         * ACCELERATION MAGNITUDE
         * ---------------------------------------------------------
         */

        val accelerationMagnitude =
            sqrt(
                accX * accX +
                        accY * accY +
                        accZ * accZ
            )

        /*
         * ---------------------------------------------------------
         * GYROSCOPE MAGNITUDE
         * ---------------------------------------------------------
         */

        val gyroMagnitude =
            sqrt(
                gyroX * gyroX +
                        gyroY * gyroY +
                        gyroZ * gyroZ
            )

        /*
         * ---------------------------------------------------------
         * TILT ANGLE
         * ---------------------------------------------------------
         */

        val tiltAngle =
            Math.toDegrees(
                atan2(
                    sqrt(
                        accX * accX +
                                accY * accY
                    ).toDouble(),
                    accZ.toDouble()
                )
            ).toFloat()

        /*
         * ---------------------------------------------------------
         * BASIC SENSOR VALIDATION
         * ---------------------------------------------------------
         */

        val accelerationValid =
            accelerationMagnitude.isFinite()

        val gyroValid =
            gyroMagnitude.isFinite()

        val speedValid =
            speedKmh.isFinite() &&
                    speedKmh >= 0f

        /*
         * ---------------------------------------------------------
         * FALLBACK SENSOR CONFIDENCE
         * ---------------------------------------------------------
         *
         * This is deliberately NOT 1.0.
         *
         * We only know that the current accelerometer,
         * gyroscope and speed values are valid.
         */

        var confidence = 0f

        if (accelerationValid) {
            confidence += 0.40f
        }

        if (gyroValid) {
            confidence += 0.40f
        }

        if (speedValid) {
            confidence += 0.20f
        }

        confidence =
            confidence.coerceIn(
                0f,
                1f
            )

        return AdvancedFeatures(

            accelerationMagnitude =
                accelerationMagnitude,

            gyroMagnitude =
                gyroMagnitude,

            accelerationChange =
                0f,

            gyroChange =
                0f,

            jerk =
                0f,

            speedChange =
                0f,

            tiltAngle =
                tiltAngle,

            orientationChange =
                0f,

            vibration =
                0f,

            pulseRate =
                null,

            pulseChange =
                null,

            sensorConfidence =
                confidence
        )
    }

    /*
     * =============================================================
     * LOG DETECTION INFORMATION
     * =============================================================
     */

    private fun logDetection(
        prediction: EnsemblePrediction,
        features: AdvancedFeatures,
        temporalResult: TemporalResult
    ) {

        Log.i(
            TAG,
            "========== SVM-AEGIS AI ANALYSIS =========="
        )

        /*
         * ---------------------------------------------------------
         * ML RESULT
         * ---------------------------------------------------------
         */

        Log.i(
            TAG,
            "ML LABEL: ${prediction.label}"
        )

        Log.i(
            TAG,
            "SVM PROBABILITY: ${prediction.svmProbability}"
        )

        Log.i(
            TAG,
            "RF PROBABILITY: ${prediction.randomForestProbability}"
        )

        Log.i(
            TAG,
            "XGBOOST PROBABILITY: ${prediction.xgBoostProbability}"
        )

        Log.i(
            TAG,
            "ENSEMBLE PROBABILITY: ${prediction.ensembleCrashProbability}"
        )

        /*
         * ---------------------------------------------------------
         * ADVANCED FEATURES
         * ---------------------------------------------------------
         */

        Log.i(
            TAG,
            "---------- ADVANCED FEATURES ----------"
        )

        Log.i(
            TAG,
            "ACC MAGNITUDE: ${features.accelerationMagnitude}"
        )

        Log.i(
            TAG,
            "GYRO MAGNITUDE: ${features.gyroMagnitude}"
        )

        Log.i(
            TAG,
            "ACCELERATION CHANGE: ${features.accelerationChange}"
        )

        Log.i(
            TAG,
            "GYRO CHANGE: ${features.gyroChange}"
        )

        Log.i(
            TAG,
            "JERK: ${features.jerk}"
        )

        Log.i(
            TAG,
            "SPEED CHANGE: ${features.speedChange}"
        )

        Log.i(
            TAG,
            "TILT ANGLE: ${features.tiltAngle}"
        )

        Log.i(
            TAG,
            "ORIENTATION CHANGE: ${features.orientationChange}"
        )

        Log.i(
            TAG,
            "VIBRATION: ${features.vibration}"
        )

        Log.i(
            TAG,
            "PULSE RATE: ${features.pulseRate}"
        )

        Log.i(
            TAG,
            "PULSE CHANGE: ${features.pulseChange}"
        )

        Log.i(
            TAG,
            "SENSOR CONFIDENCE: ${features.sensorConfidence}"
        )

        /*
         * ---------------------------------------------------------
         * TEMPORAL RESULT
         * ---------------------------------------------------------
         */

        Log.i(
            TAG,
            "---------- TEMPORAL VALIDATION ----------"
        )

        Log.i(
            TAG,
            "TEMPORAL STATUS: ${temporalResult.status}"
        )

        Log.i(
            TAG,
            "CRASH CONFIRMED: ${temporalResult.crashConfirmed}"
        )

        /*
         * ---------------------------------------------------------
         * FINAL DECISION
         * ---------------------------------------------------------
         */

        if (temporalResult.crashConfirmed) {

            Log.w(
                TAG,
                "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
            )

            Log.w(
                TAG,
                "CRASH CONFIRMED BY TEMPORAL FILTER"
            )

            Log.w(
                TAG,
                "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
            )

        } else {

            Log.i(
                TAG,
                "Crash not confirmed"
            )
        }

        Log.i(
            TAG,
            "=========================================="
        )
    }

    /*
     * =============================================================
     * RESET
     * =============================================================
     */

    fun reset() {

        temporalFilter.reset()

        Log.i(
            TAG,
            "Crash detector reset"
        )
    }

    /*
     * =============================================================
     * SIMULATE CRASH
     * =============================================================
     *
     * Used for testing the emergency workflow without creating
     * a real accident.
     */

    fun simulateCrash(): CrashDetectionResult {

        val temporalResult =
            temporalFilter.simulateCrash()

        val testPrediction =
            EnsemblePrediction(
                label = "CRASH",
                ensembleCrashProbability = 1.0f,
                svmProbability = 1.0f,
                randomForestProbability = 1.0f,
                xgBoostProbability = 1.0f
            )

        Log.w(
            TAG,
            "=========================================="
        )

        Log.w(
            TAG,
            "SIMULATED CRASH"
        )

        Log.w(
            TAG,
            "CRASH CONFIRMED = ${temporalResult.crashConfirmed}"
        )

        Log.w(
            TAG,
            "=========================================="
        )

        return CrashDetectionResult(
            ensemblePrediction =
                testPrediction,

            temporalResult =
                temporalResult
        )
    }

    /*
     * =============================================================
     * CLOSE
     * =============================================================
     */

    fun close() {

        ensembleDetector.close()

        Log.i(
            TAG,
            "Crash detector closed"
        )
    }
}