package com.example.svmaegis.ml

import android.content.Context
import android.util.Log
import ai.onnxruntime.OnnxMap
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OnnxValue
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import com.example.svmaegis.data.SensorFrame
import java.nio.FloatBuffer

data class EnsemblePrediction(
    val label: String,
    val ensembleCrashProbability: Float,
    val svmProbability: Float,
    val randomForestProbability: Float,
    val xgBoostProbability: Float
)

class EnsembleCrashDetector(context: Context) {

    private val environment = OrtEnvironment.getEnvironment()

    private val svmSession: OrtSession
    private val rfSession: OrtSession
    private val xgbSession: OrtSession

    init {

        val svmBytes = context.assets
            .open("svm_aegis_final.onnx")
            .use { it.readBytes() }

        val rfBytes = context.assets
            .open("rf_aegis_final.onnx")
            .use { it.readBytes() }

        val xgbBytes = context.assets
            .open("xgb_aegis_final.onnx")
            .use { it.readBytes() }

        svmSession = environment.createSession(svmBytes)
        rfSession = environment.createSession(rfBytes)
        xgbSession = environment.createSession(xgbBytes)

        Log.i(TAG, "========================================")
        Log.i(TAG, "SVM-AEGIS ML ENGINE INITIALIZED")
        Log.i(TAG, "========================================")

        Log.i(TAG, "SVM inputs: ${svmSession.inputNames}")
        Log.i(TAG, "SVM outputs: ${svmSession.outputNames}")

        Log.i(TAG, "RF inputs: ${rfSession.inputNames}")
        Log.i(TAG, "RF outputs: ${rfSession.outputNames}")

        Log.i(TAG, "XGB inputs: ${xgbSession.inputNames}")
        Log.i(TAG, "XGB outputs: ${xgbSession.outputNames}")

        Log.i(TAG, "All ONNX models loaded successfully")
    }

    fun predict(frame: SensorFrame): EnsemblePrediction {
        return predict(
            FeatureExtractor.extract(frame)
        )
    }

    fun predict(
        accX: Float,
        accY: Float,
        accZ: Float,
        gyroX: Float,
        gyroY: Float,
        gyroZ: Float,
        speedKmh: Float
    ): EnsemblePrediction {

        return predict(
            FeatureExtractor.extract(
                accX,
                accY,
                accZ,
                gyroX,
                gyroY,
                gyroZ,
                speedKmh
            )
        )
    }

    fun predict(features: FloatArray): EnsemblePrediction {

        require(features.size == 8) {
            "SVM-AEGIS requires exactly 8 features"
        }

        Log.d(TAG, "----------------------------------------")
        Log.d(TAG, "NEW ML PREDICTION")

        Log.d(
            TAG,
            "Features = [${features.joinToString(", ")}]"
        )

        val svmProbability = runModel(
            name = "SVM",
            session = svmSession,
            features = features
        )

        val rfProbability = runModel(
            name = "RF",
            session = rfSession,
            features = features
        )

        val xgbProbability = runModel(
            name = "XGBoost",
            session = xgbSession,
            features = features
        )

        val ensembleProbability =
            (
                    svmProbability +
                            rfProbability +
                            xgbProbability
                    ) / 3f

        val finalProbability =
            ensembleProbability.coerceIn(0f, 1f)

        val label =
            if (finalProbability >= 0.5f) {
                "CRASH"
            } else {
                "NORMAL"
            }

        Log.i(TAG, "SVM = $svmProbability")
        Log.i(TAG, "RF = $rfProbability")
        Log.i(TAG, "XGBoost = $xgbProbability")
        Log.i(TAG, "ENSEMBLE = $finalProbability")
        Log.i(TAG, "LABEL = $label")

        Log.d(TAG, "----------------------------------------")

        return EnsemblePrediction(
            label = label,
            ensembleCrashProbability = finalProbability,
            svmProbability = svmProbability,
            randomForestProbability = rfProbability,
            xgBoostProbability = xgbProbability
        )
    }

    private fun runModel(
        name: String,
        session: OrtSession,
        features: FloatArray
    ): Float {

        val inputName =
            session.inputNames.firstOrNull()
                ?: "float_input"

        Log.d(
            TAG,
            "$name input name = $inputName"
        )

        val tensor =
            OnnxTensor.createTensor(
                environment,
                FloatBuffer.wrap(features),
                longArrayOf(1, 8)
            )

        tensor.use {

            session.run(
                mapOf(
                    inputName to tensor
                )
            ).use { result ->

                Log.d(
                    TAG,
                    "$name result count = ${result.size()}"
                )

                val outputNames =
                    session.outputNames.toList()

                for (index in 0 until result.size()) {

                    val outputName =
                        if (index < outputNames.size) {
                            outputNames[index]
                        } else {
                            "output_$index"
                        }

                    val outputValue =
                        result[index]

                    Log.d(
                        TAG,
                        "$name output[$index] name=$outputName"
                    )

                    logRawOutput(
                        name,
                        outputName,
                        outputValue
                    )
                }

                return extractProbability(
                    name,
                    session,
                    result
                )
            }
        }
    }

    private fun extractProbability(
        modelName: String,
        session: OrtSession,
        result: OrtSession.Result
    ): Float {

        val outputNames =
            session.outputNames.toList()

        var probabilityIndex = -1

        for (index in outputNames.indices) {

            val outputName =
                outputNames[index]

            if (
                outputName.contains(
                    "prob",
                    ignoreCase = true
                )
            ) {

                probabilityIndex = index
                break
            }
        }

        if (probabilityIndex == -1) {

            Log.w(
                TAG,
                "$modelName probability output not found"
            )

            return 0f
        }

        if (probabilityIndex >= result.size()) {

            Log.w(
                TAG,
                "$modelName probability index invalid: $probabilityIndex"
            )

            return 0f
        }

        val output =
            result[probabilityIndex]

        val probability =
            extractProbabilityValue(
                output
            )

        Log.i(
            TAG,
            "$modelName crash probability = $probability"
        )

        return probability.coerceIn(
            0f,
            1f
        )
    }

    private fun extractProbabilityValue(
        value: OnnxValue?
    ): Float {

        if (value == null) {
            return 0f
        }

        return try {

            val raw =
                value.value

            Log.d(
                TAG,
                "Probability raw type = ${raw?.javaClass?.name}"
            )

            extractFromObject(raw)

        } catch (e: Exception) {

            Log.e(
                TAG,
                "Probability extraction error",
                e
            )

            0f
        }
    }

    private fun extractFromObject(
        value: Any?
    ): Float {

        if (value == null) {
            return 0f
        }

        return when (value) {

            is OnnxMap -> {

                extractFromOnnxMap(
                    value
                )
            }

            is List<*> -> {

                extractFromList(
                    value
                )
            }

            is FloatArray -> {

                extractFromFloatArray(
                    value
                )
            }

            is DoubleArray -> {

                extractFromDoubleArray(
                    value
                )
            }

            is Array<*> -> {

                extractFromArray(
                    value
                )
            }

            is Float -> {

                value.coerceIn(
                    0f,
                    1f
                )
            }

            is Double -> {

                value
                    .toFloat()
                    .coerceIn(
                        0f,
                        1f
                    )
            }

            is Number -> {

                value
                    .toFloat()
                    .coerceIn(
                        0f,
                        1f
                    )
            }

            else -> {

                Log.d(
                    TAG,
                    "Unknown ONNX output type = ${value.javaClass.name}"
                )

                value
                    .toString()
                    .toFloatOrNull()
                    ?.coerceIn(
                        0f,
                        1f
                    )
                    ?: 0f
            }
        }
    }

    private fun extractFromList(
        values: List<*>
    ): Float {

        if (values.isEmpty()) {
            return 0f
        }

        Log.d(
            TAG,
            "ONNX List size = ${values.size}"
        )

        for (item in values) {

            if (item is OnnxMap) {

                Log.d(
                    TAG,
                    "ONNX List contains OnnxMap"
                )

                return extractFromOnnxMap(
                    item
                )
            }
        }

        val first =
            values.firstOrNull()

        if (first is FloatArray) {

            return extractFromFloatArray(
                first
            )
        }

        if (first is DoubleArray) {

            return extractFromDoubleArray(
                first
            )
        }

        if (first is Array<*>) {

            return extractFromArray(
                first
            )
        }

        val numbers =
            values.mapNotNull {
                (it as? Number)?.toFloat()
            }

        if (numbers.size >= 2) {

            return numbers[1]
                .coerceIn(
                    0f,
                    1f
                )
        }

        if (numbers.size == 1) {

            return numbers[0]
                .coerceIn(
                    0f,
                    1f
                )
        }

        return 0f
    }

    private fun extractFromOnnxMap(
        onnxMap: OnnxMap
    ): Float {

        val map =
            onnxMap.value

        Log.d(
            TAG,
            "ONNX MAP = $map"
        )

        var crashProbability: Float? = null

        var firstProbability: Float? = null

        for ((key, probability) in map) {

            val keyText =
                key.toString()

            val probabilityValue =
                when (probability) {

                    is Number ->
                        probability.toFloat()

                    else ->
                        probability
                            .toString()
                            .toFloatOrNull()
                }

            if (probabilityValue == null) {
                continue
            }

            val safeProbability =
                probabilityValue.coerceIn(
                    0f,
                    1f
                )

            if (firstProbability == null) {

                firstProbability =
                    safeProbability
            }

            Log.d(
                TAG,
                "ONNX MAP entry: key=$keyText probability=$safeProbability"
            )

            if (
                keyText == "1" ||
                keyText.equals(
                    "CRASH",
                    ignoreCase = true
                ) ||
                keyText.equals(
                    "true",
                    ignoreCase = true
                )
            ) {

                crashProbability =
                    safeProbability
            }
        }

        if (crashProbability != null) {

            Log.d(
                TAG,
                "Selected class 1 crash probability = $crashProbability"
            )

            return crashProbability
        }

        return firstProbability ?: 0f
    }

    private fun extractFromFloatArray(
        values: FloatArray
    ): Float {

        if (values.isEmpty()) {
            return 0f
        }

        return when {

            values.size == 1 -> {

                values[0]
            }

            values.size >= 2 -> {

                Log.d(
                    TAG,
                    "Selecting class 1 probability from FloatArray"
                )

                values[1]
            }

            else -> {
                0f
            }

        }.coerceIn(
            0f,
            1f
        )
    }

    private fun extractFromDoubleArray(
        values: DoubleArray
    ): Float {

        if (values.isEmpty()) {
            return 0f
        }

        return when {

            values.size == 1 -> {

                values[0].toFloat()
            }

            values.size >= 2 -> {

                Log.d(
                    TAG,
                    "Selecting class 1 probability from DoubleArray"
                )

                values[1].toFloat()
            }

            else -> {
                0f
            }

        }.coerceIn(
            0f,
            1f
        )
    }

    private fun extractFromArray(
        values: Array<*>
    ): Float {

        if (values.isEmpty()) {
            return 0f
        }

        Log.d(
            TAG,
            "Processing nested Array"
        )

        for (item in values) {

            if (item is OnnxMap) {

                return extractFromOnnxMap(
                    item
                )
            }

            if (item is List<*>) {

                return extractFromList(
                    item
                )
            }
        }

        val first =
            values.firstOrNull()

        if (first is FloatArray) {

            return extractFromFloatArray(
                first
            )
        }

        if (first is DoubleArray) {

            return extractFromDoubleArray(
                first
            )
        }

        if (first is Array<*>) {

            return extractFromArray(
                first
            )
        }

        if (first is Number) {

            val numbers =
                values.mapNotNull {
                    (it as? Number)?.toFloat()
                }

            if (numbers.size >= 2) {

                return numbers[1]
                    .coerceIn(
                        0f,
                        1f
                    )
            }

            if (numbers.size == 1) {

                return numbers[0]
                    .coerceIn(
                        0f,
                        1f
                    )
            }
        }

        return 0f
    }

    private fun logRawOutput(
        modelName: String,
        outputName: String,
        output: OnnxValue?
    ) {

        if (output == null) {

            Log.d(
                TAG,
                "$modelName [$outputName] = null"
            )

            return
        }

        try {

            val raw =
                output.value

            Log.d(
                TAG,
                "$modelName [$outputName] raw type = ${raw?.javaClass?.name}"
            )

            when (raw) {

                is OnnxMap -> {

                    Log.d(
                        TAG,
                        "$modelName [$outputName] MAP = ${raw.value}"
                    )
                }

                is List<*> -> {

                    Log.d(
                        TAG,
                        "$modelName [$outputName] LIST = $raw"
                    )
                }

                is FloatArray -> {

                    Log.d(
                        TAG,
                        "$modelName [$outputName] FloatArray = ${raw.contentToString()}"
                    )
                }

                is DoubleArray -> {

                    Log.d(
                        TAG,
                        "$modelName [$outputName] DoubleArray = ${raw.contentToString()}"
                    )
                }

                is Array<*> -> {

                    Log.d(
                        TAG,
                        "$modelName [$outputName] Array = ${raw.contentDeepToString()}"
                    )
                }

                else -> {

                    Log.d(
                        TAG,
                        "$modelName [$outputName] value = $raw"
                    )
                }
            }

        } catch (e: Exception) {

            Log.e(
                TAG,
                "$modelName [$outputName] logging failed",
                e
            )
        }
    }

    fun close() {

        try {
            svmSession.close()
        } catch (_: Exception) {
        }

        try {
            rfSession.close()
        } catch (_: Exception) {
        }

        try {
            xgbSession.close()
        } catch (_: Exception) {
        }

        Log.i(
            TAG,
            "SVM-AEGIS ML engine closed"
        )
    }

    companion object {

        private const val TAG =
            "SVM_AEGIS_ML"
    }
}