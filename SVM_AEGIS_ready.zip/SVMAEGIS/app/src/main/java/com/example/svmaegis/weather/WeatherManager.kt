package com.example.svmaegis.weather

import android.content.Context
import android.location.Geocoder
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * Loads current weather from Open-Meteo and converts it directly into the
 * WeatherState used by the SVM-AEGIS UI.
 */
class WeatherManager(
    private val context: Context
) {

    suspend fun getWeather(
        latitude: Double,
        longitude: Double
    ): WeatherState? = withContext(Dispatchers.IO) {

        var connection: HttpURLConnection? = null

        try {
            val url = URL(
                "https://api.open-meteo.com/v1/forecast" +
                        "?latitude=$latitude" +
                        "&longitude=$longitude" +
                        "&current=temperature_2m,apparent_temperature," +
                        "weather_code,wind_speed_10m,is_day" +
                        "&timezone=auto"
            )

            connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 10_000
            connection.readTimeout = 10_000
            connection.useCaches = false

            val responseCode = connection.responseCode
            if (responseCode !in 200..299) {
                return@withContext null
            }

            val response = connection.inputStream
                .bufferedReader()
                .use { it.readText() }

            val json = JSONObject(response)
            val current = json.optJSONObject("current")
                ?: return@withContext null

            val weatherCode = current.optInt("weather_code", -1)

            WeatherState(
                city = getLocationName(latitude, longitude),
                temperature = current.optDouble("temperature_2m", 0.0),
                feelsLike = current.optDouble("apparent_temperature", 0.0),
                windSpeed = current.optDouble("wind_speed_10m", 0.0),
                description = weatherCodeToText(weatherCode),
                weatherCode = weatherCode,
                isDay = current.optInt("is_day", 1) == 1
            )
        } catch (_: Exception) {
            null
        } finally {
            connection?.disconnect()
        }
    }

    @Suppress("DEPRECATION")
    private fun getLocationName(
        latitude: Double,
        longitude: Double
    ): String {
        return try {
            val geocoder = Geocoder(
                context,
                Locale.getDefault()
            )

            val addresses = geocoder.getFromLocation(
                latitude,
                longitude,
                1
            )

            if (!addresses.isNullOrEmpty()) {
                val address = addresses[0]
                address.locality
                    ?: address.subAdminArea
                    ?: address.adminArea
                    ?: "Current Location"
            } else {
                "Current Location"
            }
        } catch (_: Exception) {
            "Current Location"
        }
    }

    private fun weatherCodeToText(code: Int): String = when (code) {
        0 -> "Clear Sky"
        1 -> "Mainly Clear"
        2 -> "Partly Cloudy"
        3 -> "Overcast"
        45, 48 -> "Fog"
        51, 53, 55, 56, 57 -> "Drizzle"
        61, 63, 65, 66, 67 -> "Rain"
        71, 73, 75, 77 -> "Snow"
        80, 81, 82 -> "Rain Showers"
        85, 86 -> "Snow Showers"
        95 -> "Thunderstorm"
        96, 99 -> "Thunderstorm with Hail"
        else -> "Weather unavailable"
    }
}
