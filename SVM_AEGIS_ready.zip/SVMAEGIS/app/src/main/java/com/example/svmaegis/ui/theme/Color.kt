package com.example.svmaegis.ui.theme

import androidx.compose.ui.graphics.Color

val AegisBlue = Color(0xFF2F80ED)
val AegisCyan = Color(0xFF00C6FF)
val AegisGreen = Color(0xFF20C997)
val AegisOrange = Color(0xFFFFA726)
val AegisRed = Color(0xFFFF4D5A)
val AegisDark = Color(0xFF071521)
val AegisCard = Color(0xFF102838)
