package com.example.svmaegis.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun SvmAegisGyroscope3DScreen(
    gx: Float,
    gy: Float,
    gz: Float,
    onBack: () -> Unit
) {
    var rx by remember { mutableFloatStateOf(0f) }
    var ry by remember { mutableFloatStateOf(0f) }
    var rz by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        var last = System.nanoTime()

        while (true) {
            val now = System.nanoTime()

            val dt =
                ((now - last) / 1_000_000_000f)
                    .coerceIn(0f, 0.05f)

            last = now

            val toDegrees = 57.29578f

            rx += gx * dt * toDegrees
            ry += gy * dt * toDegrees
            rz += gz * dt * toDegrees

            if (rx > 360000f || rx < -360000f) rx %= 360f
            if (ry > 360000f || ry < -360000f) ry %= 360f
            if (rz > 360000f || rz < -360000f) rz %= 360f

            delay(16L)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF020A0F),
                        Color(0xFF09253A),
                        Color(0xFF020A0F)
                    )
                )
            )
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Text(
            text = "SVM-AEGIS",
            color = Color(0xFF55B7FF),
            fontSize = 14.sp
        )

        Text(
            text = "3D GYROSCOPE",
            color = Color.White,
            fontSize = 27.sp
        )

        Text(
            text = "Move the phone to rotate the model",
            color = Color.White.copy(alpha = 0.65f),
            fontSize = 12.sp
        )

        Spacer(
            modifier = Modifier.height(12.dp)
        )

        SvmAegis3DViewport(
            xRotation = rx,
            yRotation = ry,
            zRotation = rz,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        )

        Spacer(
            modifier = Modifier.height(10.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onBack,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF235A99)
                )
            ) {
                Text("BACK")
            }
        }
    }
}
