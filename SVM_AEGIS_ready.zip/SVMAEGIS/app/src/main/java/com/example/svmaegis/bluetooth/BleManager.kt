package com.example.svmaegis.bluetooth

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import java.util.UUID

class BleManager(
    private val context: Context,
    private val onPacket: (ExternalSensorPacket) -> Unit,
    private val onStatusChanged: (Boolean, BleDevice?) -> Unit = { _, _ -> }
) {

    companion object {
        private const val TAG = "SVM_AEGIS_BLE"

        val SERVICE_UUID: UUID =
            UUID.fromString("6E400001-B5A3-F393-E0A9-E50E24DCCA9E")

        val RX_UUID: UUID =
            UUID.fromString("6E400003-B5A3-F393-E0A9-E50E24DCCA9E")

        val TX_UUID: UUID =
            UUID.fromString("6E400002-B5A3-F393-E0A9-E50E24DCCA9E")
    }

    private val bluetoothManager =
        context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager

    private val adapter: BluetoothAdapter?
        get() = bluetoothManager.adapter

    private val scanner: BluetoothLeScanner?
        get() = adapter?.bluetoothLeScanner

    private var bluetoothGatt: BluetoothGatt? = null
    private var connectedDevice: BleDevice? = null
    private val packetBuffer = StringBuilder()

    val isConnected: Boolean
        get() = bluetoothGatt != null && connectedDevice != null

    fun startScan(scanDurationMillis: Long = 10_000L) {
        if (!hasBlePermissions()) {
            Log.w(TAG, "BLE permission not granted")
            return
        }

        val leScanner = scanner ?: return

        try {
            leScanner.startScan(scanCallback)
            android.os.Handler(context.mainLooper).postDelayed({
                stopScan()
            }, scanDurationMillis)
        } catch (e: SecurityException) {
            Log.e(TAG, "BLE scan permission error", e)
        }
    }

    fun stopScan() {
        if (!hasBlePermissions()) return
        try {
            scanner?.stopScan(scanCallback)
        } catch (e: SecurityException) {
            Log.e(TAG, "Unable to stop BLE scan", e)
        }
    }

    fun connect(device: BluetoothDevice) {
        if (!hasBlePermissions()) return

        stopScan()

        try {
            bluetoothGatt?.close()
            bluetoothGatt = null

            connectedDevice = BleDevice(device)
            onStatusChanged(false, connectedDevice)

            bluetoothGatt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                device.connectGatt(
                    context,
                    false,
                    gattCallback,
                    BluetoothDevice.TRANSPORT_LE
                )
            } else {
                device.connectGatt(context, false, gattCallback)
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "BLE connect permission error", e)
        }
    }

    fun disconnect() {
        if (!hasBlePermissions()) return

        try {
            bluetoothGatt?.disconnect()
        } catch (e: SecurityException) {
            Log.e(TAG, "BLE disconnect error", e)
        }
    }

    fun close() {
        stopScan()
        try {
            bluetoothGatt?.close()
        } catch (e: SecurityException) {
            Log.e(TAG, "BLE close error", e)
        }
        bluetoothGatt = null
        connectedDevice = null
        onStatusChanged(false, null)
    }

    fun writeCommand(command: String) {
        if (!hasBlePermissions()) return

        val gatt = bluetoothGatt ?: return
        val service = gatt.getService(SERVICE_UUID) ?: return
        val characteristic = service.getCharacteristic(TX_UUID) ?: return

        try {
            characteristic.value = command.toByteArray(Charsets.UTF_8)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                gatt.writeCharacteristic(
                    characteristic,
                    characteristic.value,
                    BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                )
            } else {
                characteristic.writeType =
                    BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                gatt.writeCharacteristic(characteristic)
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "BLE write permission error", e)
        }
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(
            callbackType: Int,
            result: ScanResult
        ) {
            val device = result.device
            val name = try {
                if (hasBlePermissions()) device.name else null
            } catch (_: SecurityException) {
                null
            } ?: result.scanRecord?.deviceName ?: "BLE Sensor"

            Log.d(TAG, "Found BLE device: $name / ${device.address}")

            // Future UI can expose discovered devices.
            // This implementation does not auto-connect to unknown devices.
        }

        override fun onScanFailed(errorCode: Int) {
            Log.e(TAG, "BLE scan failed: $errorCode")
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {

        override fun onConnectionStateChange(
            gatt: BluetoothGatt,
            status: Int,
            newState: Int
        ) {
            if (newState == BluetoothGatt.STATE_CONNECTED) {
                Log.i(TAG, "BLE connected")
                bluetoothGatt = gatt
                if (hasBlePermissions()) {
                    try {
                        gatt.discoverServices()
                    } catch (e: SecurityException) {
                        Log.e(TAG, "Service discovery permission error", e)
                    }
                }
            } else if (newState == BluetoothGatt.STATE_DISCONNECTED) {
                Log.i(TAG, "BLE disconnected")
                if (bluetoothGatt === gatt) {
                    bluetoothGatt = null
                }
                onStatusChanged(false, connectedDevice)
                try {
                    gatt.close()
                } catch (_: Exception) {
                }
            }
        }

        override fun onServicesDiscovered(
            gatt: BluetoothGatt,
            status: Int
        ) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                Log.e(TAG, "Service discovery failed: $status")
                return
            }

            val service = gatt.getService(SERVICE_UUID)
            val rx = service?.getCharacteristic(RX_UUID)

            if (service == null || rx == null) {
                Log.w(TAG, "Expected UART service/characteristic not found")
                return
            }

            if (!hasBlePermissions()) return

            try {
                gatt.setCharacteristicNotification(rx, true)

                val descriptor =
                    rx.getDescriptor(
                        UUID.fromString(
                            "00002902-0000-1000-8000-00805f9b34fb"
                        )
                    )

                if (descriptor != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        gatt.writeDescriptor(
                            descriptor,
                            BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                        )
                    } else {
                        descriptor.value =
                            BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                        gatt.writeDescriptor(descriptor)
                    }
                }

                onStatusChanged(true, connectedDevice)
                Log.i(TAG, "External sensor notifications enabled")
            } catch (e: SecurityException) {
                Log.e(TAG, "Notification setup permission error", e)
            }
        }

        override fun onCharacteristicChanged(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic
        ) {
            if (characteristic.uuid != RX_UUID) return

            val text = characteristic.value
                ?.toString(Charsets.UTF_8)
                ?: return

            handleIncomingText(text)
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray
        ) {
            if (characteristic.uuid != RX_UUID) return
            handleIncomingText(value.toString(Charsets.UTF_8))
        }
    }

    private fun handleIncomingText(text: String) {
        synchronized(packetBuffer) {
            packetBuffer.append(text)

            while (true) {
                val newlineIndex = packetBuffer.indexOf("\n")
                if (newlineIndex < 0) break

                val line = packetBuffer
                    .substring(0, newlineIndex)
                    .trim()

                packetBuffer.delete(0, newlineIndex + 1)

                val packet = BlePacketParser.parse(line)
                if (packet != null) {
                    onPacket(packet)
                }
            }
        }
    }

    private fun hasBlePermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.BLUETOOTH_SCAN
            ) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.BLUETOOTH_CONNECT
                    ) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.BLUETOOTH
            ) == PackageManager.PERMISSION_GRANTED
        }
    }
}
