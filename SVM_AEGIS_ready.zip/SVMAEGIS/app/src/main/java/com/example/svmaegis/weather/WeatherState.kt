package com.example.svmaegis.weather

/**
 * UI-ready weather information used by the SVM-AEGIS dashboard.
 * WeatherManager returns this exact type, so MainActivity can store it
 * directly without rebuilding or converting the object.
 */
data class WeatherState(
    val city: String = "Unknown Location",
    val temperature: Double = 0.0,
    val feelsLike: Double = 0.0,
    val windSpeed: Double = 0.0,
    val description: String = "Weather unavailable",
    val weatherCode: Int = -1,
    val isDay: Boolean = true
)
