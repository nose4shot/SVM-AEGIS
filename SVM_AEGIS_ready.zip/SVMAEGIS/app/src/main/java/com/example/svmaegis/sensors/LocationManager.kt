package com.example.svmaegis.sensors

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import androidx.core.content.ContextCompat

class AppLocationManager(
    private val context: Context,
    private val onLocation: (Location) -> Unit
) : LocationListener {

    private val locationManager =
        context.getSystemService(Context.LOCATION_SERVICE) as LocationManager

    fun hasPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        val coarse = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        return fine || coarse
    }

    fun start() {
        if (!hasPermission()) return

        requestProvider(LocationManager.GPS_PROVIDER)
        requestProvider(LocationManager.NETWORK_PROVIDER)

        val lastGps = try {
            locationManager.getLastKnownLocation(
                LocationManager.GPS_PROVIDER
            )
        } catch (_: SecurityException) {
            null
        }

        val lastNetwork = try {
            locationManager.getLastKnownLocation(
                LocationManager.NETWORK_PROVIDER
            )
        } catch (_: SecurityException) {
            null
        }

        lastGps?.let(onLocation)
        if (lastGps == null) lastNetwork?.let(onLocation)
    }

    private fun requestProvider(provider: String) {
        try {
            if (locationManager.isProviderEnabled(provider)) {
                locationManager.requestLocationUpdates(
                    provider,
                    1000L,
                    1f,
                    this
                )
            }
        } catch (_: Exception) {
        }
    }

    fun stop() {
        try {
            locationManager.removeUpdates(this)
        } catch (_: Exception) {
        }
    }

    override fun onLocationChanged(location: Location) {
        onLocation(location)
    }

    @Deprecated("Deprecated by Android")
    override fun onStatusChanged(
        provider: String?,
        status: Int,
        extras: Bundle?
    ) = Unit

    override fun onProviderEnabled(provider: String) = Unit
    override fun onProviderDisabled(provider: String) = Unit
}
