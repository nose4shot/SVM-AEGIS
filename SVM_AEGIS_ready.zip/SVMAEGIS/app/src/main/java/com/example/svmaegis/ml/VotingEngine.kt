package com.example.svmaegis.ml

enum class ModelDecision {
    CRASH,
    NORMAL
}

data class ModelVote(
    val modelName: String,
    val probability: Float,
    val decision: ModelDecision
)

data class VotingResult(
    val svm: ModelVote,
    val randomForest: ModelVote,
    val xgBoost: ModelVote,
    val crashVotes: Int,
    val normalVotes: Int,
    val decision: ModelDecision,
    val confidence: Float
) {
    val unanimousCrash: Boolean
        get() = crashVotes == 3

    val majorityCrash: Boolean
        get() = crashVotes >= 2

    val unanimousNormal: Boolean
        get() = normalVotes == 3
}

class VotingEngine {

    companion object {
        private const val CRASH_THRESHOLD = 0.50f
    }

    fun vote(
        svmProbability: Float,
        randomForestProbability: Float,
        xgBoostProbability: Float
    ): VotingResult {

        val svmVote = createVote(
            "SVM",
            svmProbability
        )

        val randomForestVote = createVote(
            "Random Forest",
            randomForestProbability
        )

        val xgBoostVote = createVote(
            "XGBoost",
            xgBoostProbability
        )

        val votes = listOf(
            svmVote,
            randomForestVote,
            xgBoostVote
        )

        val crashVotes = votes.count {
            it.decision == ModelDecision.CRASH
        }

        val normalVotes = votes.count {
            it.decision == ModelDecision.NORMAL
        }

        val decision =
            if (crashVotes >= 2) {
                ModelDecision.CRASH
            } else {
                ModelDecision.NORMAL
            }

        val confidence = calculateConfidence(
            svmProbability = svmProbability,
            randomForestProbability = randomForestProbability,
            xgBoostProbability = xgBoostProbability,
            decision = decision
        )

        return VotingResult(
            svm = svmVote,
            randomForest = randomForestVote,
            xgBoost = xgBoostVote,
            crashVotes = crashVotes,
            normalVotes = normalVotes,
            decision = decision,
            confidence = confidence
        )
    }

    private fun createVote(
        modelName: String,
        probability: Float
    ): ModelVote {

        val safeProbability =
            probability.coerceIn(0f, 1f)

        val decision =
            if (safeProbability >= CRASH_THRESHOLD) {
                ModelDecision.CRASH
            } else {
                ModelDecision.NORMAL
            }

        return ModelVote(
            modelName = modelName,
            probability = safeProbability,
            decision = decision
        )
    }

    private fun calculateConfidence(
        svmProbability: Float,
        randomForestProbability: Float,
        xgBoostProbability: Float,
        decision: ModelDecision
    ): Float {

        val probabilities = listOf(
            svmProbability.coerceIn(0f, 1f),
            randomForestProbability.coerceIn(0f, 1f),
            xgBoostProbability.coerceIn(0f, 1f)
        )

        val average =
            probabilities.average().toFloat()

        val agreement =
            when (decision) {

                ModelDecision.CRASH -> {
                    probabilities.count {
                        it >= CRASH_THRESHOLD
                    } / 3f
                }

                ModelDecision.NORMAL -> {
                    probabilities.count {
                        it < CRASH_THRESHOLD
                    } / 3f
                }
            }

        val spread =
            probabilities.maxOrNull()!! -
                    probabilities.minOrNull()!!

        val consistency =
            (1f - spread).coerceIn(0f, 1f)

        return (
                average * 0.50f +
                        agreement * 0.30f +
                        consistency * 0.20f
                ).coerceIn(0f, 1f)
    }
}