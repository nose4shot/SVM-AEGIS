package com.example.svmaegis.detection

import com.example.svmaegis.ml.AdvancedFeatures
import com.example.svmaegis.ml.ModelDecision
import com.example.svmaegis.ml.VotingResult
import kotlin.math.abs

enum class ValidationDecision {
    NORMAL,
    MONITORING,
    POSSIBLE_ACCIDENT,
    CONFIRMED_ACCIDENT
}

data class CrashValidationResult(
    val decision: ValidationDecision,
    val confidence: Float,
    val reason: String,
    val impactEvidence: Float,
    val motionEvidence: Float,
    val orientationEvidence: Float,
    val speedEvidence: Float,
    val pulseEvidence: Float,
    val sensorEvidence: Float,
    val stillnessRequired: Boolean
)

class CrashValidation {

    companion object {
        private const val ML_WEIGHT = 0.40f
        private const val IMPACT_WEIGHT = 0.20f
        private const val MOTION_WEIGHT = 0.15f
        private const val ORIENTATION_WEIGHT = 0.10f
        private const val SPEED_WEIGHT = 0.05f
        private const val PULSE_WEIGHT = 0.05f
        private const val SENSOR_WEIGHT = 0.05f

        private const val MONITORING_THRESHOLD = 0.35f
        private const val POSSIBLE_ACCIDENT_THRESHOLD = 0.55f
        private const val CONFIRMED_THRESHOLD = 0.80f
    }

    fun validate(
        votingResult: VotingResult,
        features: AdvancedFeatures,
        eventType: com.example.svmaegis.ml.EventType
    ): CrashValidationResult {

        val mlEvidence = calculateMlEvidence(votingResult)

        val impactEvidence = calculateImpactEvidence(features)

        val motionEvidence = calculateMotionEvidence(features)

        val orientationEvidence =
            calculateOrientationEvidence(features)

        val speedEvidence =
            calculateSpeedEvidence(features)

        val pulseEvidence =
            calculatePulseEvidence(features)

        val sensorEvidence =
            features.sensorConfidence.coerceIn(0f, 1f)

        val totalConfidence =
            (
                    mlEvidence * ML_WEIGHT +
                            impactEvidence * IMPACT_WEIGHT +
                            motionEvidence * MOTION_WEIGHT +
                            orientationEvidence * ORIENTATION_WEIGHT +
                            speedEvidence * SPEED_WEIGHT +
                            pulseEvidence * PULSE_WEIGHT +
                            sensorEvidence * SENSOR_WEIGHT
                    ).coerceIn(0f, 1f)

        val accidentLikeEvent =
            eventType == com.example.svmaegis.ml.EventType.POSSIBLE_ACCIDENT ||
                    eventType == com.example.svmaegis.ml.EventType.NEAR_MISS

        val decision = when {

            totalConfidence >= CONFIRMED_THRESHOLD &&
                    mlEvidence >= 0.66f &&
                    impactEvidence >= 0.60f -> {

                ValidationDecision.POSSIBLE_ACCIDENT
            }

            totalConfidence >= POSSIBLE_ACCIDENT_THRESHOLD ||
                    accidentLikeEvent -> {

                ValidationDecision.POSSIBLE_ACCIDENT
            }

            totalConfidence >= MONITORING_THRESHOLD -> {

                ValidationDecision.MONITORING
            }

            else -> {

                ValidationDecision.NORMAL
            }
        }

        val reason = buildReason(
            decision = decision,
            votingResult = votingResult,
            features = features,
            eventType = eventType
        )

        return CrashValidationResult(
            decision = decision,
            confidence = totalConfidence,
            reason = reason,
            impactEvidence = impactEvidence,
            motionEvidence = motionEvidence,
            orientationEvidence = orientationEvidence,
            speedEvidence = speedEvidence,
            pulseEvidence = pulseEvidence,
            sensorEvidence = sensorEvidence,
            stillnessRequired = decision == ValidationDecision.POSSIBLE_ACCIDENT
        )
    }

    private fun calculateMlEvidence(
        votingResult: VotingResult
    ): Float {

        val crashProbabilities = listOf(
            votingResult.svm.probability,
            votingResult.randomForest.probability,
            votingResult.xgBoost.probability
        )

        val average =
            crashProbabilities.average().toFloat()

        val agreement =
            votingResult.crashVotes / 3f

        val unanimousBonus =
            if (votingResult.unanimousCrash) {
                0.15f
            } else {
                0f
            }

        return (
                average * 0.65f +
                        agreement * 0.35f +
                        unanimousBonus
                ).coerceIn(0f, 1f)
    }

    private fun calculateImpactEvidence(
        features: AdvancedFeatures
    ): Float {

        val accelerationEvidence =
            normalize(
                features.accelerationChange,
                0f,
                8f
            )

        val jerkEvidence =
            normalize(
                features.jerk,
                0f,
                30f
            )

        val vibrationEvidence =
            normalize(
                features.vibration,
                0f,
                5f
            )

        return (
                accelerationEvidence * 0.50f +
                        jerkEvidence * 0.35f +
                        vibrationEvidence * 0.15f
                ).coerceIn(0f, 1f)
    }

    private fun calculateMotionEvidence(
        features: AdvancedFeatures
    ): Float {

        val acceleration =
            normalize(
                features.accelerationChange,
                0f,
                6f
            )

        val gyro =
            normalize(
                features.gyroChange,
                0f,
                3f
            )

        return (
                acceleration * 0.55f +
                        gyro * 0.45f
                ).coerceIn(0f, 1f)
    }

    private fun calculateOrientationEvidence(
        features: AdvancedFeatures
    ): Float {

        return normalize(
            abs(features.orientationChange),
            0f,
            45f
        )
    }

    private fun calculateSpeedEvidence(
        features: AdvancedFeatures
    ): Float {

        return normalize(
            features.speedChange,
            0f,
            30f
        )
    }

    private fun calculatePulseEvidence(
        features: AdvancedFeatures
    ): Float {

        val pulse = features.pulseRate
            ?: return 0f

        val pulseChange =
            features.pulseChange ?: 0f

        if (pulse <= 0f) {
            return 0f
        }

        return when {
            pulseChange >= 30f -> 1.0f
            pulseChange >= 20f -> 0.75f
            pulseChange >= 10f -> 0.50f
            else -> 0.20f
        }
    }

    private fun buildReason(
        decision: ValidationDecision,
        votingResult: VotingResult,
        features: AdvancedFeatures,
        eventType: com.example.svmaegis.ml.EventType
    ): String {

        val voteText =
            "${votingResult.crashVotes}/3 ML models indicate crash"

        return when (decision) {

            ValidationDecision.NORMAL ->
                "Sensor pattern appears normal"

            ValidationDecision.MONITORING ->
                "$voteText; monitoring sensor behavior"

            ValidationDecision.POSSIBLE_ACCIDENT ->
                "$voteText; event=${eventType.name}, " +
                        "impact=${format(features.accelerationChange)}, " +
                        "gyro=${format(features.gyroChange)}, " +
                        "orientation=${format(features.orientationChange)}"

            ValidationDecision.CONFIRMED_ACCIDENT ->
                "Accident evidence confirmed"
        }
    }

    private fun normalize(
        value: Float,
        minimum: Float,
        maximum: Float
    ): Float {

        if (maximum <= minimum) {
            return 0f
        }

        return (
                (value - minimum) /
                        (maximum - minimum)
                ).coerceIn(0f, 1f)
    }

    private fun format(
        value: Float
    ): String {

        return String.format(
            "%.2f",
            value
        )
    }
}