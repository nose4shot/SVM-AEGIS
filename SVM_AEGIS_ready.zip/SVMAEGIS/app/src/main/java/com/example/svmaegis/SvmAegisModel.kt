package com.example.svmaegis.ml

import android.content.Context
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import java.nio.FloatBuffer

data class SvmPrediction(
    val label: String,
    val crashProbability: Float
)

class SvmAegisModel(context: Context) {

    private val environment = OrtEnvironment.getEnvironment()
    private val session: OrtSession

    init {
        val modelBytes = context.assets
            .open("svm_aegis_final.onnx")
            .use { it.readBytes() }

        session = environment.createSession(modelBytes)
    }

    fun predict(features: FloatArray): SvmPrediction {
        require(features.size == 8)

        val inputName =
            session.inputNames.firstOrNull() ?: "float_input"

        val tensor = OnnxTensor.createTensor(
            environment,
            FloatBuffer.wrap(features),
            longArrayOf(1, 8)
        )

        tensor.use {
            session.run(mapOf(inputName to tensor)).use { result ->
                val probability = extractProbability(
                    result[1] ?: result[0]
                )

                return SvmPrediction(
                    label = if (probability >= 0.5f) "CRASH" else "NORMAL",
                    crashProbability = probability
                )
            }
        }
    }

    private fun extractProbability(value: Any?): Float {
        if (value == null) return 0f

        return when (value) {
            is FloatArray ->
                if (value.size == 1) value[0] else value.last()

            is Array<*> ->
                value.lastOrNull()
                    ?.toString()
                    ?.toFloatOrNull()
                    ?: 0f

            else ->
                value.toString()
                    .toFloatOrNull()
                    ?: 0f
        }.coerceIn(0f, 1f)
    }

    fun close() {
        session.close()
    }
}
