package com.example.svmaegis.sensors

import com.example.svmaegis.bluetooth.ExternalSensorPacket
import com.example.svmaegis.data.SensorFrame
import com.example.svmaegis.data.SensorSource

class ExternalSensorManager(
    private val onFrame: (SensorFrame) -> Unit,
    private val externalTimeoutMillis: Long = 2_000L
) {

    private var latestPacket: ExternalSensorPacket? = null

    var connected: Boolean = false
        private set

    val lastPacketMillis: Long?
        get() = latestPacket?.timestampMillis

    fun setConnected(value: Boolean) {
        connected = value

        if (!value) {
            latestPacket = null
        }
    }

    fun updatePacket(packet: ExternalSensorPacket) {

        latestPacket = packet
        connected = true

        if (
            !packet.hasAccelerometer &&
            !packet.hasGyroscope &&
            !packet.hasGps
        ) {
            return
        }

        val frame = SensorFrame(
            timestampMillis = packet.timestampMillis,

            accX = packet.accX ?: 0f,
            accY = packet.accY ?: 0f,
            accZ = packet.accZ ?: 0f,

            gyroX = packet.gyroX ?: 0f,
            gyroY = packet.gyroY ?: 0f,
            gyroZ = packet.gyroZ ?: 0f,

            speedKmh = packet.speedKmh ?: 0f,

            latitude = packet.latitude ?: 0.0,
            longitude = packet.longitude ?: 0.0,

            vibration = packet.vibration,
            temperatureCelsius = packet.temperatureCelsius,

            source = SensorSource.EXTERNAL
        )

        onFrame(frame)
    }

    fun isFresh(
        nowMillis: Long = System.currentTimeMillis()
    ): Boolean {

        val timestamp = latestPacket?.timestampMillis
            ?: return false

        return connected &&
                nowMillis - timestamp <= externalTimeoutMillis
    }

    fun latest(): ExternalSensorPacket? {
        return latestPacket
    }

    fun clear() {
        latestPacket = null
        connected = false
    }
}