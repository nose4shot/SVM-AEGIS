package com.example.svmaegis.detection

import android.content.Context
import android.util.Log
import com.example.svmaegis.data.SensorFrame
import com.example.svmaegis.ml.AdvancedFeatureExtractor
import com.example.svmaegis.ml.AdvancedFeatures
import com.example.svmaegis.ml.EventClassifier
import com.example.svmaegis.ml.EventClassificationResult
import com.example.svmaegis.ml.VotingEngine
import com.example.svmaegis.ml.VotingResult

class DetectionEngine(context: Context) {

    private val crashDetector =
        CrashDetector(context)

    private val advancedFeatureExtractor =
        AdvancedFeatureExtractor()

    private val eventClassifier =
        EventClassifier()

    private val crashValidation =
        CrashValidation()

    private val votingEngine =
        VotingEngine()

    private var latestAdvancedFeatures:
            AdvancedFeatures? = null

    private var latestEventClassification:
            EventClassificationResult? = null

    private var latestValidation:
            CrashValidationResult? = null

    private var latestVotingResult:
            VotingResult? = null

    fun process(
        frame: SensorFrame
    ): CrashDetectionResult {

        return processInternal(
            frame = frame,
            pulseRate = null
        )
    }

    fun process(
        frame: SensorFrame,
        pulseRate: Float?
    ): CrashDetectionResult {

        return processInternal(
            frame = frame,
            pulseRate = pulseRate
        )
    }

    private fun processInternal(
        frame: SensorFrame,
        pulseRate: Float?
    ): CrashDetectionResult {

        /*
         * STEP 1
         * ADVANCED FEATURE EXTRACTION
         */

        val features =
            advancedFeatureExtractor.extract(
                frame = frame,
                pulseRate = pulseRate
            )

        latestAdvancedFeatures =
            features

        /*
         * STEP 2
         * SVM + RANDOM FOREST + XGBOOST
         */

        val crashResult =
            crashDetector.detectCrashWithTemporal(
                accX = frame.accX,
                accY = frame.accY,
                accZ = frame.accZ,
                gyroX = frame.gyroX,
                gyroY = frame.gyroY,
                gyroZ = frame.gyroZ,
                speedKmh = frame.speedKmh,
                advancedFeatures = features
            )

        /*
         * STEP 3
         * THREE-MODEL VOTING
         */

        val prediction =
            crashResult.ensemblePrediction

        val votingResult =
            votingEngine.vote(
                svmProbability =
                    prediction.svmProbability,

                randomForestProbability =
                    prediction.randomForestProbability,

                xgBoostProbability =
                    prediction.xgBoostProbability
            )

        latestVotingResult =
            votingResult

        /*
         * STEP 4
         * EVENT CLASSIFICATION
         */

        val eventResult =
            eventClassifier.classify(
                features = features,
                mlProbability =
                    prediction.ensembleCrashProbability
            )

        latestEventClassification =
            eventResult

        /*
         * STEP 5
         * CRASH VALIDATION
         */

        val validationResult =
            crashValidation.validate(
                votingResult = votingResult,
                features = features,
                eventType = eventResult.eventType
            )

        latestValidation =
            validationResult

        /*
         * DEBUG INFORMATION
         */

        Log.d(
            "SVM_AEGIS",
            "EVENT=${eventResult.eventType}"
        )

        Log.d(
            "SVM_AEGIS",
            "SVM=${prediction.svmProbability}"
        )

        Log.d(
            "SVM_AEGIS",
            "RF=${prediction.randomForestProbability}"
        )

        Log.d(
            "SVM_AEGIS",
            "XGB=${prediction.xgBoostProbability}"
        )

        Log.d(
            "SVM_AEGIS",
            "VOTES=${votingResult.crashVotes}/3"
        )

        Log.d(
            "SVM_AEGIS",
            "ML_DECISION=${votingResult.decision}"
        )

        Log.d(
            "SVM_AEGIS",
            "ML_CONFIDENCE=${votingResult.confidence}"
        )

        Log.d(
            "SVM_AEGIS",
            "VALIDATION=${validationResult.decision}"
        )

        Log.d(
            "SVM_AEGIS",
            "VALIDATION_CONFIDENCE=${validationResult.confidence}"
        )

        Log.d(
            "SVM_AEGIS",
            "TEMPORAL=${crashResult.status}"
        )

        Log.d(
            "SVM_AEGIS",
            "CRASH_CONFIRMED=${crashResult.crashConfirmed}"
        )

        /*
         * IMPORTANT:
         *
         * CrashDetector remains responsible for the final
         * temporal confirmation.
         *
         * Event classification and validation provide
         * additional evidence but do not directly trigger
         * the emergency system.
         */

        return crashResult
    }

    fun getLatestAdvancedFeatures():
            AdvancedFeatures? {

        return latestAdvancedFeatures
    }

    fun getLatestEventClassification():
            EventClassificationResult? {

        return latestEventClassification
    }

    fun getLatestValidation():
            CrashValidationResult? {

        return latestValidation
    }

    fun getLatestVotingResult():
            VotingResult? {

        return latestVotingResult
    }

    fun isCrashConfirmed(): Boolean {

        return latestValidation != null &&
                latestValidation!!.decision ==
                ValidationDecision.POSSIBLE_ACCIDENT &&
                latestAdvancedFeatures != null
    }

    fun processAndConfirm(
        frame: SensorFrame,
        pulseRate: Float? = null
    ): CrashDetectionResult {

        return processInternal(
            frame = frame,
            pulseRate = pulseRate
        )
    }

    fun reset() {

        advancedFeatureExtractor.reset()

        latestAdvancedFeatures =
            null

        latestEventClassification =
            null

        latestValidation =
            null

        latestVotingResult =
            null

        crashDetector.reset()

        Log.i(
            "SVM_AEGIS",
            "DETECTION ENGINE RESET"
        )
    }

    fun simulateCrash():
            CrashDetectionResult {

        return crashDetector.simulateCrash()
    }

    fun close() {

        crashDetector.close()

        Log.i(
            "SVM_AEGIS",
            "DETECTION ENGINE CLOSED"
        )
    }
}