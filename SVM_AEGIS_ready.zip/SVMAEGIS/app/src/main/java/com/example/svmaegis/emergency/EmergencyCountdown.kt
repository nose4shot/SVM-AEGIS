package com.example.svmaegis.emergency

import android.os.CountDownTimer
import android.util.Log

class EmergencyCountdown(
    private val durationMillis: Long = 10_000L,
    private val onTick: (secondsRemaining: Int) -> Unit,
    private val onFinished: () -> Unit,
    private val onCancelled: () -> Unit
) {

    private var timer: CountDownTimer? = null
    private var running = false

    fun start() {

        if (running) {
            return
        }

        running = true

        Log.i(
            TAG,
            "Emergency countdown started"
        )

        timer = object : CountDownTimer(
            durationMillis,
            1000L
        ) {

            override fun onTick(
                millisUntilFinished: Long
            ) {

                val seconds =
                    ((millisUntilFinished + 999L) / 1000L)
                        .toInt()

                onTick(seconds)

                Log.d(
                    TAG,
                    "Countdown: $seconds"
                )
            }

            override fun onFinish() {

                running = false
                timer = null

                Log.i(
                    TAG,
                    "Emergency countdown expired"
                )

                onFinished()
            }
        }.start()
    }

    fun cancel() {

        if (!running) {
            return
        }

        timer?.cancel()

        timer = null
        running = false

        Log.i(
            TAG,
            "Emergency countdown cancelled"
        )

        onCancelled()
    }

    fun isRunning(): Boolean {
        return running
    }

    fun stopSilently() {

        timer?.cancel()

        timer = null
        running = false

        Log.i(
            TAG,
            "Emergency countdown stopped silently"
        )
    }

    companion object {

        private const val TAG =
            "SVM_AEGIS"
    }
}