package com.example.svmaegis

data class PersonalProfile(
    val name: String = "",
    val phone: String = "",
    val bloodGroup: String = "",
    val emergencyName: String = "",
    val emergencyPhone: String = "",
    val address: String = ""
)
