package com.example.svmaegis.emergency

import android.content.Context
import android.util.Log
import com.example.svmaegis.data.SensorFrame
import com.example.svmaegis.detection.CrashDetectionResult

class EmergencyController(
    context: Context,
    private val emergencyPhoneNumber: String
) {

    private val emergencyManager =
        EmergencyManager(context)

    private var countdown: EmergencyCountdown? = null

    private var latestFrame: SensorFrame? = null

    private var latestCrashResult: CrashDetectionResult? = null

    private var emergencyTriggered = false

    private var secondsRemaining = 0

    fun updateSensorFrame(frame: SensorFrame) {
        latestFrame = frame
    }

    fun triggerCrashAlert(
        crashResult: CrashDetectionResult
    ) {

        if (emergencyTriggered) {
            return
        }

        if (!crashResult.crashConfirmed) {
            Log.d(
                TAG,
                "Emergency alert ignored: crash not confirmed"
            )
            return
        }

        if (emergencyPhoneNumber.isBlank()) {

            Log.w(
                TAG,
                "Emergency alert cannot start: emergency phone number is empty"
            )

            return
        }

        latestCrashResult = crashResult

        emergencyTriggered = true

        secondsRemaining =
            (COUNTDOWN_DURATION / 1000L).toInt()

        emergencyManager.startEmergencyCountdown()

        countdown =
            EmergencyCountdown(

                durationMillis =
                    COUNTDOWN_DURATION,

                onTick = { seconds ->

                    secondsRemaining =
                        seconds

                    onCountdownTick(
                        seconds
                    )
                },

                onFinished = {

                    secondsRemaining = 0

                    executeEmergencyActions()
                },

                onCancelled = {

                    secondsRemaining = 0

                    emergencyManager.cancelEmergency()

                    emergencyTriggered = false

                    Log.i(
                        TAG,
                        "Emergency sequence cancelled"
                    )
                }
            )

        countdown?.start()

        Log.i(
            TAG,
            "Crash confirmed - emergency countdown active"
        )
    }

    fun cancelEmergency() {

        countdown?.cancel()

        countdown = null

        secondsRemaining = 0

        emergencyTriggered = false

        Log.i(
            TAG,
            "Emergency cancelled manually"
        )
    }

    fun isCountdownRunning(): Boolean =
        countdown?.isRunning() == true

    fun getSecondsRemaining(): Int =
        secondsRemaining

    private fun onCountdownTick(
        seconds: Int
    ) {

        Log.d(
            TAG,
            "Emergency countdown: $seconds"
        )
    }

    private fun executeEmergencyActions() {

        val frame =
            latestFrame

        if (frame == null) {

            Log.e(
                TAG,
                "Emergency aborted: sensor frame unavailable"
            )

            emergencyTriggered = false

            return
        }

        val eventType =
            "POSSIBLE_ACCIDENT"

        val impactIntensity =
            frame.accelerationMagnitude

        val speed =
            frame.speedKmh

        emergencyManager.speak(
            "Emergency alert activated. " +
                    "An accident has been detected. " +
                    "Your emergency contact is being notified."
        )

        emergencyManager.sendEmergencyMessage(

            phoneNumber =
                emergencyPhoneNumber,

            latitude =
                frame.latitude,

            longitude =
                frame.longitude,

            speedKmh =
                speed,

            impactIntensity =
                impactIntensity,

            eventType =
                eventType
        )

        emergencyManager.makeEmergencyCall(
            emergencyPhoneNumber
        )

        Log.i(
            TAG,
            "Emergency actions executed"
        )

        emergencyTriggered = false
    }

    fun release() {

        countdown?.stopSilently()

        countdown = null

        emergencyManager.release()

        latestFrame = null

        latestCrashResult = null

        secondsRemaining = 0

        emergencyTriggered = false

        Log.i(
            TAG,
            "Emergency controller released"
        )
    }

    companion object {

        private const val TAG =
            "SVM_AEGIS"

        private const val COUNTDOWN_DURATION =
            10_000L
    }
}