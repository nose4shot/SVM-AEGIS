package com.example.svmaegis.ui.theme

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

private data class Aegis3DPoint(
    val x: Float,
    val y: Float,
    val z: Float
)

private data class Aegis2DPoint(
    val x: Float,
    val y: Float
)

private fun aegisRotateX(p: Aegis3DPoint, degrees: Float): Aegis3DPoint {
    val r = Math.toRadians(degrees.toDouble())
    val c = cos(r).toFloat()
    val s = sin(r).toFloat()
    return Aegis3DPoint(
        p.x,
        p.y * c - p.z * s,
        p.y * s + p.z * c
    )
}

private fun aegisRotateY(p: Aegis3DPoint, degrees: Float): Aegis3DPoint {
    val r = Math.toRadians(degrees.toDouble())
    val c = cos(r).toFloat()
    val s = sin(r).toFloat()
    return Aegis3DPoint(
        p.x * c + p.z * s,
        p.y,
        -p.x * s + p.z * c
    )
}

private fun aegisRotateZ(p: Aegis3DPoint, degrees: Float): Aegis3DPoint {
    val r = Math.toRadians(degrees.toDouble())
    val c = cos(r).toFloat()
    val s = sin(r).toFloat()
    return Aegis3DPoint(
        p.x * c - p.y * s,
        p.x * s + p.y * c,
        p.z
    )
}

private fun aegisRotate(
    p: Aegis3DPoint,
    rx: Float,
    ry: Float,
    rz: Float
): Aegis3DPoint {
    return aegisRotateZ(
        aegisRotateY(
            aegisRotateX(p, rx),
            ry
        ),
        rz
    )
}

private fun aegisProject(
    p: Aegis3DPoint,
    cx: Float,
    cy: Float,
    scale: Float
): Aegis2DPoint {
    val camera = 900f
    val depth = (camera - p.z).coerceAtLeast(180f)
    val perspective = camera / depth
    return Aegis2DPoint(
        cx + p.x * scale * perspective,
        cy + p.y * scale * perspective
    )
}

@Composable
fun SvmAegis3DViewport(
    xRotation: Float,
    yRotation: Float,
    zRotation: Float,
    modifier: Modifier = Modifier
) {
    var manualX by remember { mutableFloatStateOf(0f) }
    var manualY by remember { mutableFloatStateOf(0f) }
    var zoom by remember { mutableFloatStateOf(1f) }

    Box(
        modifier = modifier
            .background(
                Brush.radialGradient(
                    listOf(
                        Color(0xFF123E4D),
                        Color(0xFF071E28),
                        Color(0xFF02080C)
                    )
                )
            )
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, gestureZoom, _ ->
                    manualY += pan.x * 0.45f
                    manualX -= pan.y * 0.45f
                    zoom = (zoom * gestureZoom).coerceIn(0.65f, 1.7f)
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f

            for (i in -8..8) {
                val x = cx + i * 42f
                val y = cy + i * 42f
                drawLine(
                    Color(0x2238D5F5),
                    Offset(x, 0f),
                    Offset(x, size.height),
                    1f
                )
                drawLine(
                    Color(0x2238D5F5),
                    Offset(0f, y),
                    Offset(size.width, y),
                    1f
                )
            }

            val rx = xRotation + manualX
            val ry = yRotation + manualY
            val rz = zRotation

            val s = 115f
            val points = listOf(
                Aegis3DPoint(-s, -s, s),
                Aegis3DPoint(s, -s, s),
                Aegis3DPoint(s, s, s),
                Aegis3DPoint(-s, s, s),
                Aegis3DPoint(-s, -s, -s),
                Aegis3DPoint(s, -s, -s),
                Aegis3DPoint(s, s, -s),
                Aegis3DPoint(-s, s, -s)
            )

            val edges = listOf(
                0 to 1, 1 to 2, 2 to 3, 3 to 0,
                4 to 5, 5 to 6, 6 to 7, 7 to 4,
                0 to 4, 1 to 5, 2 to 6, 3 to 7
            )

            drawCircle(
                Color(0x1838E8FF),
                190f,
                Offset(cx, cy)
            )

            edges.forEachIndexed { index, edge ->
                val a = aegisProject(
                    aegisRotate(points[edge.first], rx, ry, rz),
                    cx, cy, zoom
                )
                val b = aegisProject(
                    aegisRotate(points[edge.second], rx, ry, rz),
                    cx, cy, zoom
                )

                drawLine(
                    color = if (index < 4) {
                        Color(0xFF55D9FF)
                    } else {
                        Color(0xFF28748A)
                    },
                    start = Offset(a.x, a.y),
                    end = Offset(b.x, b.y),
                    strokeWidth = if (index < 4) 6f else 3f
                )
            }

            fun drawAxis(
                end: Aegis3DPoint,
                color: Color
            ) {
                val start = aegisProject(
                    aegisRotate(
                        Aegis3DPoint(0f, 0f, 0f),
                        rx, ry, rz
                    ),
                    cx, cy, zoom
                )
                val finish = aegisProject(
                    aegisRotate(end, rx, ry, rz),
                    cx, cy, zoom
                )
                drawLine(
                    color,
                    Offset(start.x, start.y),
                    Offset(finish.x, finish.y),
                    5f
                )
            }

            drawAxis(
                Aegis3DPoint(270f, 0f, 0f),
                Color(0xFFFF4D5A)
            )
            drawAxis(
                Aegis3DPoint(0f, -270f, 0f),
                Color(0xFF4DFF88)
            )
            drawAxis(
                Aegis3DPoint(0f, 0f, 270f),
                Color(0xFF4DB8FF)
            )

            val chip = aegisProject(
                aegisRotate(
                    Aegis3DPoint(0f, 0f, s + 20f),
                    rx, ry, rz
                ),
                cx, cy, zoom
            )

            drawCircle(
                Color(0x6638E8FF),
                28f,
                Offset(chip.x, chip.y)
            )
            drawCircle(
                Color(0xFF55E8FF),
                13f,
                Offset(chip.x, chip.y)
            )
            drawCircle(
                Color.White,
                4f,
                Offset(chip.x, chip.y)
            )
        }
    }
}

@Composable
fun SvmAegisAccelerometer3DDialog(
    ax: Float,
    ay: Float,
    az: Float,
    onClose: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Color(0xFF09242C),
        shape = RoundedCornerShape(26.dp),
        title = {
            Text(
                "3D ACCELEROMETER",
                color = Color.White,
                fontSize = 21.sp
            )
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                SvmAegis3DViewport(
                    xRotation = ay * 12f,
                    yRotation = -ax * 12f,
                    zRotation = az * 5f,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(330.dp)
                        .border(
                            1.dp,
                            Color(0x4455E8FF),
                            RoundedCornerShape(22.dp)
                        )
                )

                Spacer(Modifier.height(12.dp))

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AegisValue("AX", ax, Color(0xFFFF4D5A), Modifier.weight(1f))
                    AegisValue("AY", ay, Color(0xFF4DFF88), Modifier.weight(1f))
                    AegisValue("AZ", az, Color(0xFF4DB8FF), Modifier.weight(1f))
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onClose) {
                Text("CLOSE", color = Color(0xFF55D9FF))
            }
        }
    )
}

@Composable
fun SvmAegisGyroscope3DDialog(
    gx: Float,
    gy: Float,
    gz: Float,
    onClose: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Color(0xFF111D3A),
        shape = RoundedCornerShape(26.dp),
        title = {
            Text(
                "3D GYROSCOPE",
                color = Color.White,
                fontSize = 21.sp
            )
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                SvmAegis3DViewport(
                    xRotation = gx * 18f,
                    yRotation = gy * 18f,
                    zRotation = gz * 18f,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(330.dp)
                        .border(
                            1.dp,
                            Color(0x4455B7FF),
                            RoundedCornerShape(22.dp)
                        )
                )

                Spacer(Modifier.height(12.dp))

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AegisValue("GX", gx, Color(0xFFFF4D5A), Modifier.weight(1f))
                    AegisValue("GY", gy, Color(0xFF4DFF88), Modifier.weight(1f))
                    AegisValue("GZ", gz, Color(0xFF4DB8FF), Modifier.weight(1f))
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onClose) {
                Text("CLOSE", color = Color(0xFF55B7FF))
            }
        }
    )
}

@Composable
private fun AegisValue(
    title: String,
    value: Float,
    color: Color,
    modifier: Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = Color.White.copy(alpha = 0.08f)
        ),
        shape = RoundedCornerShape(13.dp)
    ) {
        Column(
            Modifier.padding(9.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, color = color, fontSize = 11.sp)
            Text(
                "%.3f".format(value),
                color = Color.White,
                fontSize = 13.sp
            )
        }
    }
}

@Composable
fun SvmAegisCrashAlertCard(
    countdown: Int,
    alertSent: Boolean,
    emergencyName: String,
    emergencyPhone: String,
    onCancelCrash: () -> Unit
) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.70f)),
        contentAlignment = Alignment.Center
    ) {
        Card(
            Modifier
                .fillMaxWidth(0.90f)
                .padding(8.dp),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF34171D)
            ),
            border = androidx.compose.foundation.BorderStroke(
                2.dp,
                Color(0xFFFF4D5A)
            ),
            elevation = CardDefaults.cardElevation(
                defaultElevation = 18.dp
            )
        ) {
            Column(
                Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier
                        .size(82.dp)
                        .border(
                            3.dp,
                            Color(0xFFFF4D5A),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text("🚨", fontSize = 43.sp)
                }

                Spacer(Modifier.height(12.dp))

                Text(
                    "CRASH DETECTED",
                    color = Color(0xFFFF6472),
                    fontSize = 25.sp
                )

                Text(
                    if (alertSent)
                        "Emergency alert is ready"
                    else
                        "Please cancel if you are safe",
                    color = Color.White.copy(alpha = 0.72f),
                    fontSize = 13.sp
                )

                if (!alertSent) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "${countdown}s",
                        color = Color(0xFFFF6472),
                        fontSize = 56.sp
                    )
                }

                if (
                    emergencyName.isNotBlank() ||
                    emergencyPhone.isNotBlank()
                ) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Emergency contact",
                        color = Color.White.copy(alpha = 0.55f),
                        fontSize = 10.sp
                    )
                    if (emergencyName.isNotBlank()) {
                        Text(
                            emergencyName,
                            color = Color.White,
                            fontSize = 16.sp
                        )
                    }
                    if (emergencyPhone.isNotBlank()) {
                        Text(
                            emergencyPhone,
                            color = Color.White.copy(alpha = 0.70f),
                            fontSize = 12.sp
                        )
                    }
                }

                Spacer(Modifier.height(18.dp))

                Button(
                    onClick = onCancelCrash,
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF702731)
                    )
                ) {
                    Text(
                        "I'M OKAY — CANCEL ALERT",
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}
